```python

```

<div style="text-align: center; font-size: 18px;">
<b>Exploring the Relationship Between Food Consumption Patterns and Diabetes Prevalence in South Africa: A Provincial-Level Predictive Modeling Approach</b><br>
Author: <a href="https://www.linkedin.com/in/nicholus-mathibe-a302b218a" target="_blank">Nicholus Mathibe</a>
</div>



## 1. INTRODUCTION ##

<div style="text-align: justify;font-size:18px;" > Diabetes mellitus is a growing public health concern in South Africa, with increasing prevalence attributed torapid urbanisation, lifestyle changes, and dietary transitions. The South African population is experiencing anutrition shift from traditional diets to more processed and calorie-dense foods, which may be contributing tothe rising burden of non-communicable diseases, particularly Type 2 Diabetes Mellitus (T2DM). Understandinghow food consumption patterns vary by province and how these patterns are associated with diabetes prevalence can provide critical insights for targeted health interventions and public awareness campaigns.Despite the availability of national surveys capturing health and dietary data, relatively few studies have integrated  these datasets to examine provincial-level associations between dietary behaviours and diabetes prevalence. Moreover,  there is a lack of predictive tools that can estimate diabetes risk across regions using food consumption indicators  and socio-demographic factors.This study aims to fill this gap by integrating multiple datasets from national surveys and administrative sources, and applying statistical and machine learning techniques to build a predictive model of 
 diabetes prevalence at the provincial (and optionally district) level. The findings will guide targeted regional awareness campaigns, resource allocation, and prevention strategies.</div>

## 2. RESEARCH AIM ##

<div style="text-align: justify;font-size:18px;" > To investigate the relationship between provincial food consumption patterns and diabetes prevalence in South
Africa and to develop a predictive model that identifies regions at higher risk for diabetes, thereby
supporting targeted public health interventions.</div>

## 3. RESEARCH OBJECTIVES ##


<div style="font-size:18px; line-height:1.6;">
3.1. To collect and preprocess relevant datasets on food consumption, diabetes prevalence, and sociodemographic factors at the provincial level in South Africa.<br>
3.2. To quantify provincial food consumption/expenditure patterns by category (e.g., sugary beverages, refined carbohydrates, fruits & vegetables, fats/oils) and link them to diabetes prevalence.<br>
3.3. To analyze the statistical association between food categories and diabetes prevalence while adjusting for key confounders (age, sex, obesity, physical inactivity, income, urbanisation).<br>
3.4. To build and validate predictive models (e.g., GLM/beta regression, Random Forest/XGBoost, and spatial Bayesian CAR/BYM models) to estimate provincial diabetes risk.<br>
3.5. To visualize spatial patterns and predicted risk zones using choropleth maps and risk scores.<br>
3.6. To translate findings into actionable, province-specific awareness and prevention strategies.
</div>


## 4. METHODS ##

### 4.1 Study Design ###

<div style= "text-align: justify;font-size:18px;"> Cross-sectional and repeated cross-sectional ecological analysis at the provincial level (optionally extended
to districts) using pooled national survey data (2022 -2024 or latest available) and administrative health
indicators.</div>

### 4.2 Data Sources ###

<div style="text-align: justify;font-size:18px;"> Data used is focused on South African population in a provincial and district level</div> 
<div style="font-size:18px; line-height:1.6;">
4.2.1. Income & Expenditure Survey (IES 202223).<br>
4.2.2. District Health Barometer (DHB 202324).<br>
4.2.3. General Household Survey (GHS 2023).<br>
</div>

### 4.3 calibration/validation ###

<div style="font-size:18px;">
4.3.1. Income & Expenditure Survey (IES) 2022/23 (and earlier rounds) household food expenditure shares by
category, by province.</br>
4.3.2. District Health Barometer (DHB) district/provincial diabetes-related indicators (validation/finer spatial
scale).</br>
</div>

### 4.4 Key Predictor Variables ###

<div style="font-size:18px;">
4.3.1. Adults overweight or obese .</br>
4.3.2. Diabetes prevelence.</br>
4.4.3. Hypertension percentages </br>
4.4.4. Population </br>
4.4.5. Age and sex </br>
</div>

### 4.5 Data Cleaning & Preprocessing ###

<div style="font-size:18px">
4.5.1. Harmonise provincial codes and names across datasets.</br>
4.5.2. Compute survey-weighted provincial prevalence (GHS, IES 202223, DHB 202324).</br>
4.5.3. Convert IES food expenditure to proportional shares by category per province and per capita if needed.</br>
4.5.4. Create a master panel dataset:  province as unit (if
cross-sectional).</br>
4.5.5. Address missingness via multiple imputation or complete-case analysis.</br>
4.5.6. Standardise/normalise predictors as needed; check multicollinearity (VIF).</br></div>

### 4.6 Exploratory Data Analysis (EDA) Plan ###

<div style="font-size:18px">
4.6.1. Summary stats: prevalence of diabetes by province, distribution of food expenditure shares.</br>
4.6.2. Correlations (Spearman/Pearson) between food categories and diabetes prevalence.</br>
4.6.3. Scatter plots with linear smoothers: e.g., sugary beverages share vs diabetes prevalence.</br>
4.6.4. Choropleth maps of diabetes prevalence and key food categories to visualise spatial overlap.</br>
4.6.5. Moran s I / Geary s C to assess spatial autocorrelation in residuals.</br>
4.6.6. Partial dependence / SHAP plots (for ML models) to interpret variable importance.</br>
</div>

### 4.7 Modeling Strategy ###

<div style ="font-size:18px">
4.7.1.	Feature Engineering </br>
4.7.2.	Feature Selection </br>
4.7.3.	Separating Training Features From Target Feature </br>
4.7.4.	Fitting The Features </br>
4.7.5.	Training The Models  </br>
4.7.6.	Linear Regression</br>
4.7.7.	Baseline OLS With Clustered Ses</br>
4.7.8.	Baseline OLS With Clustered Ses</br>
4.7.9.	Random Forest / Xgboost With Groupkfold</br>
4.7.10.	Model Evaluation </br>
4.7.11.	Model Validation /Cross Validation </br>
4.7.12.	Feature Importance </br>
4.7.13.	Predictions From Trained Model </br>
4.7.14.	Model Deployment </br>
</div>

### 4.8 Ethics & Data Use ###

<div style ="font-size:18px">
- All datasets are de-identified public microdata; adhere to data use agreements (e.g., DataFirst/HSRC/Stats
SA). No individual re-identification attempts.
- Ensure transparent reporting of limitations and potential ecological fallacy (province-level inference may
not hold at individual level).</div>

### 4.9 Limitations ###

<div style="font-size:18px">
- Ecological design limits causal inference.</br>
- Self-reported diabetes underestimates true prevalence; calibration using biomarker surveys is critical.</br>
- Food expenditure actual consumption; however, it s a reasonable proxy at population level.</br>
- Temporal misalignment between surveys may introduce bias; handle via sensitivity analyses.</br>
</div>

## 5. DATA COLLECTION AND LOADING ##


```python
#Will install needed libraries 
!pip install pandas 
!pip install numpy
!pip install openpyxl xlrd pyxlsb
!pip install matplotlib seaborn
!pip install missingno
!pip install pdfplumber pandas
```

    Requirement already satisfied: pandas in c:\users\cash\anaconda3\lib\site-packages (2.2.2)
    Requirement already satisfied: numpy>=1.26.0 in c:\users\cash\anaconda3\lib\site-packages (from pandas) (1.26.4)
    Requirement already satisfied: python-dateutil>=2.8.2 in c:\users\cash\anaconda3\lib\site-packages (from pandas) (2.9.0.post0)
    Requirement already satisfied: pytz>=2020.1 in c:\users\cash\anaconda3\lib\site-packages (from pandas) (2024.1)
    Requirement already satisfied: tzdata>=2022.7 in c:\users\cash\anaconda3\lib\site-packages (from pandas) (2023.3)
    Requirement already satisfied: six>=1.5 in c:\users\cash\anaconda3\lib\site-packages (from python-dateutil>=2.8.2->pandas) (1.16.0)
    Requirement already satisfied: numpy in c:\users\cash\anaconda3\lib\site-packages (1.26.4)
    Requirement already satisfied: openpyxl in c:\users\cash\anaconda3\lib\site-packages (3.1.5)
    Requirement already satisfied: xlrd in c:\users\cash\anaconda3\lib\site-packages (2.0.2)
    Requirement already satisfied: pyxlsb in c:\users\cash\anaconda3\lib\site-packages (1.0.10)
    Requirement already satisfied: et-xmlfile in c:\users\cash\anaconda3\lib\site-packages (from openpyxl) (1.1.0)
    Requirement already satisfied: matplotlib in c:\users\cash\anaconda3\lib\site-packages (3.9.2)
    Requirement already satisfied: seaborn in c:\users\cash\anaconda3\lib\site-packages (0.13.2)
    Requirement already satisfied: contourpy>=1.0.1 in c:\users\cash\anaconda3\lib\site-packages (from matplotlib) (1.2.0)
    Requirement already satisfied: cycler>=0.10 in c:\users\cash\anaconda3\lib\site-packages (from matplotlib) (0.11.0)
    Requirement already satisfied: fonttools>=4.22.0 in c:\users\cash\anaconda3\lib\site-packages (from matplotlib) (4.51.0)
    Requirement already satisfied: kiwisolver>=1.3.1 in c:\users\cash\anaconda3\lib\site-packages (from matplotlib) (1.4.4)
    Requirement already satisfied: numpy>=1.23 in c:\users\cash\anaconda3\lib\site-packages (from matplotlib) (1.26.4)
    Requirement already satisfied: packaging>=20.0 in c:\users\cash\anaconda3\lib\site-packages (from matplotlib) (24.1)
    Requirement already satisfied: pillow>=8 in c:\users\cash\anaconda3\lib\site-packages (from matplotlib) (10.4.0)
    Requirement already satisfied: pyparsing>=2.3.1 in c:\users\cash\anaconda3\lib\site-packages (from matplotlib) (3.1.2)
    Requirement already satisfied: python-dateutil>=2.7 in c:\users\cash\anaconda3\lib\site-packages (from matplotlib) (2.9.0.post0)
    Requirement already satisfied: pandas>=1.2 in c:\users\cash\anaconda3\lib\site-packages (from seaborn) (2.2.2)
    Requirement already satisfied: pytz>=2020.1 in c:\users\cash\anaconda3\lib\site-packages (from pandas>=1.2->seaborn) (2024.1)
    Requirement already satisfied: tzdata>=2022.7 in c:\users\cash\anaconda3\lib\site-packages (from pandas>=1.2->seaborn) (2023.3)
    Requirement already satisfied: six>=1.5 in c:\users\cash\anaconda3\lib\site-packages (from python-dateutil>=2.7->matplotlib) (1.16.0)
    Requirement already satisfied: missingno in c:\users\cash\anaconda3\lib\site-packages (0.5.2)
    Requirement already satisfied: numpy in c:\users\cash\anaconda3\lib\site-packages (from missingno) (1.26.4)
    Requirement already satisfied: matplotlib in c:\users\cash\anaconda3\lib\site-packages (from missingno) (3.9.2)
    Requirement already satisfied: scipy in c:\users\cash\anaconda3\lib\site-packages (from missingno) (1.13.1)
    Requirement already satisfied: seaborn in c:\users\cash\anaconda3\lib\site-packages (from missingno) (0.13.2)
    Requirement already satisfied: contourpy>=1.0.1 in c:\users\cash\anaconda3\lib\site-packages (from matplotlib->missingno) (1.2.0)
    Requirement already satisfied: cycler>=0.10 in c:\users\cash\anaconda3\lib\site-packages (from matplotlib->missingno) (0.11.0)
    Requirement already satisfied: fonttools>=4.22.0 in c:\users\cash\anaconda3\lib\site-packages (from matplotlib->missingno) (4.51.0)
    Requirement already satisfied: kiwisolver>=1.3.1 in c:\users\cash\anaconda3\lib\site-packages (from matplotlib->missingno) (1.4.4)
    Requirement already satisfied: packaging>=20.0 in c:\users\cash\anaconda3\lib\site-packages (from matplotlib->missingno) (24.1)
    Requirement already satisfied: pillow>=8 in c:\users\cash\anaconda3\lib\site-packages (from matplotlib->missingno) (10.4.0)
    Requirement already satisfied: pyparsing>=2.3.1 in c:\users\cash\anaconda3\lib\site-packages (from matplotlib->missingno) (3.1.2)
    Requirement already satisfied: python-dateutil>=2.7 in c:\users\cash\anaconda3\lib\site-packages (from matplotlib->missingno) (2.9.0.post0)
    Requirement already satisfied: pandas>=1.2 in c:\users\cash\anaconda3\lib\site-packages (from seaborn->missingno) (2.2.2)
    Requirement already satisfied: pytz>=2020.1 in c:\users\cash\anaconda3\lib\site-packages (from pandas>=1.2->seaborn->missingno) (2024.1)
    Requirement already satisfied: tzdata>=2022.7 in c:\users\cash\anaconda3\lib\site-packages (from pandas>=1.2->seaborn->missingno) (2023.3)
    Requirement already satisfied: six>=1.5 in c:\users\cash\anaconda3\lib\site-packages (from python-dateutil>=2.7->matplotlib->missingno) (1.16.0)
    Requirement already satisfied: pdfplumber in c:\users\cash\anaconda3\lib\site-packages (0.11.7)
    Requirement already satisfied: pandas in c:\users\cash\anaconda3\lib\site-packages (2.2.2)
    Requirement already satisfied: pdfminer.six==20250506 in c:\users\cash\anaconda3\lib\site-packages (from pdfplumber) (20250506)
    Requirement already satisfied: Pillow>=9.1 in c:\users\cash\anaconda3\lib\site-packages (from pdfplumber) (10.4.0)
    Requirement already satisfied: pypdfium2>=4.18.0 in c:\users\cash\anaconda3\lib\site-packages (from pdfplumber) (4.30.0)
    Requirement already satisfied: charset-normalizer>=2.0.0 in c:\users\cash\anaconda3\lib\site-packages (from pdfminer.six==20250506->pdfplumber) (3.3.2)
    Requirement already satisfied: cryptography>=36.0.0 in c:\users\cash\anaconda3\lib\site-packages (from pdfminer.six==20250506->pdfplumber) (43.0.0)
    Requirement already satisfied: numpy>=1.26.0 in c:\users\cash\anaconda3\lib\site-packages (from pandas) (1.26.4)
    Requirement already satisfied: python-dateutil>=2.8.2 in c:\users\cash\anaconda3\lib\site-packages (from pandas) (2.9.0.post0)
    Requirement already satisfied: pytz>=2020.1 in c:\users\cash\anaconda3\lib\site-packages (from pandas) (2024.1)
    Requirement already satisfied: tzdata>=2022.7 in c:\users\cash\anaconda3\lib\site-packages (from pandas) (2023.3)
    Requirement already satisfied: six>=1.5 in c:\users\cash\anaconda3\lib\site-packages (from python-dateutil>=2.8.2->pandas) (1.16.0)
    Requirement already satisfied: cffi>=1.12 in c:\users\cash\anaconda3\lib\site-packages (from cryptography>=36.0.0->pdfminer.six==20250506->pdfplumber) (1.17.1)
    Requirement already satisfied: pycparser in c:\users\cash\anaconda3\lib\site-packages (from cffi>=1.12->cryptography>=36.0.0->pdfminer.six==20250506->pdfplumber) (2.21)
    


```python
!pip install adjustText
!pip install --upgrade scikit-learn

```

    Requirement already satisfied: adjustText in c:\users\cash\anaconda3\lib\site-packages (1.3.0)
    Requirement already satisfied: numpy in c:\users\cash\anaconda3\lib\site-packages (from adjustText) (1.26.4)
    Requirement already satisfied: matplotlib in c:\users\cash\anaconda3\lib\site-packages (from adjustText) (3.9.2)
    Requirement already satisfied: scipy in c:\users\cash\anaconda3\lib\site-packages (from adjustText) (1.13.1)
    Requirement already satisfied: contourpy>=1.0.1 in c:\users\cash\anaconda3\lib\site-packages (from matplotlib->adjustText) (1.2.0)
    Requirement already satisfied: cycler>=0.10 in c:\users\cash\anaconda3\lib\site-packages (from matplotlib->adjustText) (0.11.0)
    Requirement already satisfied: fonttools>=4.22.0 in c:\users\cash\anaconda3\lib\site-packages (from matplotlib->adjustText) (4.51.0)
    Requirement already satisfied: kiwisolver>=1.3.1 in c:\users\cash\anaconda3\lib\site-packages (from matplotlib->adjustText) (1.4.4)
    Requirement already satisfied: packaging>=20.0 in c:\users\cash\anaconda3\lib\site-packages (from matplotlib->adjustText) (24.1)
    Requirement already satisfied: pillow>=8 in c:\users\cash\anaconda3\lib\site-packages (from matplotlib->adjustText) (10.4.0)
    Requirement already satisfied: pyparsing>=2.3.1 in c:\users\cash\anaconda3\lib\site-packages (from matplotlib->adjustText) (3.1.2)
    Requirement already satisfied: python-dateutil>=2.7 in c:\users\cash\anaconda3\lib\site-packages (from matplotlib->adjustText) (2.9.0.post0)
    Requirement already satisfied: six>=1.5 in c:\users\cash\anaconda3\lib\site-packages (from python-dateutil>=2.7->matplotlib->adjustText) (1.16.0)
    Requirement already satisfied: scikit-learn in c:\users\cash\anaconda3\lib\site-packages (1.7.1)
    Requirement already satisfied: numpy>=1.22.0 in c:\users\cash\anaconda3\lib\site-packages (from scikit-learn) (1.26.4)
    Requirement already satisfied: scipy>=1.8.0 in c:\users\cash\anaconda3\lib\site-packages (from scikit-learn) (1.13.1)
    Requirement already satisfied: joblib>=1.2.0 in c:\users\cash\anaconda3\lib\site-packages (from scikit-learn) (1.4.2)
    Requirement already satisfied: threadpoolctl>=3.1.0 in c:\users\cash\anaconda3\lib\site-packages (from scikit-learn) (3.5.0)
    


```python
#Now we will import libraries 
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import missingno as msno
import pdfplumber
import pandas as pd
```

# 5.1. Step 1: Data collection and import for Income & Expenditure Survey (IES 202223) #

## 5.1.1. Code for Table 1 (Male, Female, Total) EXPENDITURE ##
In this collection i had to manually extract expanditure tables from Income & Expenditure Survey (IES 202223).
1.Table 8.2.12: Percentage distribution of annual household consumption expenditure by class expenditure and expenditure deciles.
2.Table 8.2.18: Percentage distribution of annual household consumption expenditure by class expenditure and province Class expenditure 
group Western Cape Eastern Cape Northern Cape Free State KwaZulu- Natal North West Gauteng Mpumalanga Limpopo


```python
import pandas as pd
import re

text1 = """
Food and non-alcoholic beverages 14,7 19,1 16,3
Alcoholic beverages, tobacco and narcotics 1,7 1,0 1,4
Clothing and footwear 4,8 5,4 5,0
Housing, water, electricity, gas and other fuels 33,5 36,6 34,7
Furnishings, household equipment and routine household maintenance 4,3 3,9 4,1
Health 1,0 1,0 1,0
Transport 16,8 12,6 15,3
Information and communication 4,6 4,4 4,5
Recreation, sport and culture 1,4 1,1 1,3
Education services 1,6 1,1 1,4
Restaurants and accommodation services 2,8 2,5 2,7
Insurance and financial services 10,1 8,1 9,3
Personal care, social protection and miscellaneous goods 2,8 3,1 2,9
Narcotics 0,2 0,1 0,0
Tobacco 1,4 0,8 0,3
Alcohol production services 0,0 0,0 0,0
Other alcoholic beverages 0,0 0,0 0,0
Beer 1,4 1,3 0,5
Wine 0,2 0,3 0,3
Spirits and liquors 0,1 0,2 0,2
Services for processing primary goods for food and non-alcoholic beverages 0,0 0,0 0,0
Other non-alcoholic beverages 0,1 0,1 0,1
Soft drinks 1,5 1,3 0,5
Water 0,0 0,0 0,1
Cocoa drinks 0,0 0,0 0,0
Tea, mate and other plant products for infusion 0,3 0,3 0,1
Coffee and coffee substitutes 0,2 0,1 0,2
Fruit and vegetable juices 0,2 0,3 0,2
Ready-made food and other food products n.e.c. 1,7 1,8 1,1
Sugar, confectionery and desserts 1,6 1,5 0,9
Vegetables, tubers, plantains, cooking bananas and pulses 3,7 3,3 1,6
Fruit and nuts 0,6 0,6 0,5
Oils and fats 1,7 1,6 0,8
Milk, other dairy products and eggs 2,6 2,6 1,6
Fish and other seafood 0,8 0,7 0,4
Live animals, meat and other parts of slaughtered land animals 6,1 7,1 4,4
Cereal and cereal products 10,9 10,1 3,9
"""

# Fix decimal commas to points for floats
text1 = re.sub(r'(\d),(\d)', r'\1.\2', text1)

data = []
for line in text1.strip().split('\n'):
    parts = line.split()
    category = ' '.join(parts[:-3])
    male, female, total = map(float, parts[-3:])
    data.append([category, male, female, total])

df1 = pd.DataFrame(data, columns=['Category', 'Male', 'Female', 'Total'])

# Save to Excel
df1.to_excel("Table1_Male_Female_Total.xlsx", index=False)

print("Saved Table1_Male_Female_Total.xlsx")

```

    Saved Table1_Male_Female_Total.xlsx
    

## 5.1.2. Code for Table 2 (Provinces + Total) ##


```python
import pandas as pd
import re

text2 = """
Food and non-alcoholic beverages 13,4 20,2 19,5 18,7 19,6 20,7 13,4 18,4 21,6 16,3
Alcoholic beverages, tobacco and narcotics 1,0 1,4 2,2 2,1 1,3 1,9 1,5 1,3 1,2 1,4
Narcotics 0,0 0,0 0,0 0,1 0,0 0,0 0,0 0,1 0,0 0,0
Tobacco 0,3 0,3 0,6 0,6 0,2 0,4 0,4 0,3 0,3 0,3
Alcohol production services 0,0 0,0 0,0 0,0 0,0 0,0 0,0 0,0 0,0 0,0
Other alcoholic beverages 0,0 0,0 0,0 0,0 0,0 0,0 0,0 0,0 0,0 0,0
Beer 0,3 0,4 0,8 0,9 0,5 0,9 0,6 0,5 0,6 0,5
Wine 0,2 0,3 0,3 0,3 0,3 0,4 0,3 0,2 0,1 0,3
Spirits and liquors 0,2 0,4 0,4 0,1 0,3 0,2 0,2 0,2 0,1 0,2
Services for processing primary goods for food and non-alcoholic beverages 0,0 0,0 0,0 0,0 0,0 0,0 0,0 0,0 0,0 0,0
Other non-alcoholic beverages 0,1 0,0 0,1 0,0 0,1 0,0 0,1 0,1 0,0 0,1
Soft drinks 0,4 0,4 0,8 0,6 0,5 0,9 0,5 0,6 1,0 0,5
Water 0,1 0,0 0,1 0,1 0,0 0,1 0,1 0,0 0,1 0,1
Cocoa drinks 0,0 0,0 0,0 0,0 0,0 0,0 0,0 0,0 0,0 0,0
Tea, mate and other plant products for infusion 0,1 0,2 0,1 0,2 0,1 0,2 0,1 0,2 0,2 0,1
Coffee and coffee substitutes 0,3 0,2 0,4 0,2 0,1 0,2 0,2 0,1 0,1 0,2
Fruit and vegetable juices 0,2 0,2 0,2 0,2 0,3 0,3 0,2 0,2 0,3 0,2
Ready-made food and other food products n.e.c. 1,0 1,9 2,5 1,9 1,2 1,6 0,8 1,0 1,0 1,1
Sugar, confectionery and desserts 0,8 1,3 1,2 0,9 1,0 1,2 0,6 0,8 1,0 0,9
Vegetables, tubers, plantains, cooking bananas and pulses 1,4 2,1 1,7 1,7 2,3 1,8 1,1 1,6 2,0 1,6
Fruit and nuts 0,6 0,4 0,4 0,5 0,5 0,6 0,5 0,4 0,7 0,5
Oils and fats 0,5 1,1 0,7 0,8 1,2 1,0 0,6 0,8 1,0 0,8
Milk, other dairy products and eggs 1,6 1,9 1,5 1,9 1,7 1,7 1,4 1,6 1,7 1,6
Fish and other seafood 0,3 0,3 0,4 0,3 0,4 0,5 0,3 0,5 0,6 0,4
Live animals, meat and other parts of slaughtered land animals 3,6 4,6 5,8 5,7 4,8 5,7 3,9 5,6 5,3 4,4
Cereal and cereal products 2,3 5,4 3,6 3,8 5,3 4,9 3,0 4,8 6,6 3,9
"""

# Fix decimal commas to points for floats
text2 = re.sub(r'(\d),(\d)', r'\1.\2', text2)

data = []
for line in text2.strip().split('\n'):
    parts = line.split()
    category = ' '.join(parts[:-10])
    values = list(map(float, parts[-10:]))
    data.append([category] + values)

province_cols = ['Western Cape', 'Eastern Cape', 'Northern Cape', 'Free State', 'KwaZulu-Natal',
                 'North West', 'Gauteng', 'Mpumalanga', 'Limpopo', 'Total']

df2 = pd.DataFrame(data, columns=['Category'] + province_cols)

# Save to Excel
df2.to_excel("Table2_Provinces_Total.xlsx", index=False)

print("Saved Table2_Provinces_Total.xlsx")

```

    Saved Table2_Provinces_Total.xlsx
    


```python

df='Table1_Male_Female_Total'
Table1_Male_Female_Total = pd.read_excel('Table1_Male_Female_Total.xlsx')
print(Table1_Male_Female_Total.head())

df='Table2_Provinces_Total'
Table2_Provinces_Total = pd.read_excel('Table2_Provinces_Total.xlsx')
print(Table2_Provinces_Total.head())
```

                                                Category  Male  Female  Total
    0                   Food and non-alcoholic beverages  14.7    19.1   16.3
    1         Alcoholic beverages, tobacco and narcotics   1.7     1.0    1.4
    2                              Clothing and footwear   4.8     5.4    5.0
    3   Housing, water, electricity, gas and other fuels  33.5    36.6   34.7
    4  Furnishings, household equipment and routine h...   4.3     3.9    4.1
                                         Category  Western Cape  Eastern Cape  \
    0            Food and non-alcoholic beverages          13.4          20.2   
    1  Alcoholic beverages, tobacco and narcotics           1.0           1.4   
    2                                   Narcotics           0.0           0.0   
    3                                     Tobacco           0.3           0.3   
    4                 Alcohol production services           0.0           0.0   
    
       Northern Cape  Free State  KwaZulu-Natal  North West  Gauteng  Mpumalanga  \
    0           19.5        18.7           19.6        20.7     13.4        18.4   
    1            2.2         2.1            1.3         1.9      1.5         1.3   
    2            0.0         0.1            0.0         0.0      0.0         0.1   
    3            0.6         0.6            0.2         0.4      0.4         0.3   
    4            0.0         0.0            0.0         0.0      0.0         0.0   
    
       Limpopo  Total  
    0     21.6   16.3  
    1      1.2    1.4  
    2      0.0    0.0  
    3      0.3    0.3  
    4      0.0    0.0  
    


```python
print(Table1_Male_Female_Total.tail())
print(Table2_Provinces_Total.tail())
```

                                                 Category  Male  Female  Total
    32                                      Oils and fats   1.7     1.6    0.8
    33                Milk, other dairy products and eggs   2.6     2.6    1.6
    34                             Fish and other seafood   0.8     0.7    0.4
    35  Live animals, meat and other parts of slaughte...   6.1     7.1    4.4
    36                         Cereal and cereal products  10.9    10.1    3.9
                                                 Category  Western Cape  \
    21                                      Oils and fats           0.5   
    22                Milk, other dairy products and eggs           1.6   
    23                             Fish and other seafood           0.3   
    24  Live animals, meat and other parts of slaughte...           3.6   
    25                         Cereal and cereal products           2.3   
    
        Eastern Cape  Northern Cape  Free State  KwaZulu-Natal  North West  \
    21           1.1            0.7         0.8            1.2         1.0   
    22           1.9            1.5         1.9            1.7         1.7   
    23           0.3            0.4         0.3            0.4         0.5   
    24           4.6            5.8         5.7            4.8         5.7   
    25           5.4            3.6         3.8            5.3         4.9   
    
        Gauteng  Mpumalanga  Limpopo  Total  
    21      0.6         0.8      1.0    0.8  
    22      1.4         1.6      1.7    1.6  
    23      0.3         0.5      0.6    0.4  
    24      3.9         5.6      5.3    4.4  
    25      3.0         4.8      6.6    3.9  
    


```python
print(Table1_Male_Female_Total.info())
print(Table2_Provinces_Total.info())
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 37 entries, 0 to 36
    Data columns (total 4 columns):
     #   Column    Non-Null Count  Dtype  
    ---  ------    --------------  -----  
     0   Category  37 non-null     object 
     1   Male      37 non-null     float64
     2   Female    37 non-null     float64
     3   Total     37 non-null     float64
    dtypes: float64(3), object(1)
    memory usage: 1.3+ KB
    None
    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 26 entries, 0 to 25
    Data columns (total 11 columns):
     #   Column         Non-Null Count  Dtype  
    ---  ------         --------------  -----  
     0   Category       26 non-null     object 
     1   Western Cape   26 non-null     float64
     2   Eastern Cape   26 non-null     float64
     3   Northern Cape  26 non-null     float64
     4   Free State     26 non-null     float64
     5   KwaZulu-Natal  26 non-null     float64
     6   North West     26 non-null     float64
     7   Gauteng        26 non-null     float64
     8   Mpumalanga     26 non-null     float64
     9   Limpopo        26 non-null     float64
     10  Total          26 non-null     float64
    dtypes: float64(10), object(1)
    memory usage: 2.4+ KB
    None
    


```python
print(Table1_Male_Female_Total.describe())
print(Table2_Provinces_Total.describe())
```

                Male     Female      Total
    count  37.000000  37.000000  37.000000
    mean    3.659459   3.621622   3.178378
    std     6.468147   6.893602   6.550112
    min     0.000000   0.000000   0.000000
    25%     0.200000   0.300000   0.200000
    50%     1.500000   1.100000   0.900000
    75%     3.700000   3.300000   2.900000
    max    33.500000  36.600000  34.700000
           Western Cape  Eastern Cape  Northern Cape  Free State  KwaZulu-Natal  \
    count     26.000000     26.000000      26.000000   26.000000      26.000000   
    mean       1.103846      1.653846       1.665385    1.600000       1.603846   
    std        2.642496      4.023753       3.874733    3.731702       3.916170   
    min        0.000000      0.000000       0.000000    0.000000       0.000000   
    25%        0.100000      0.050000       0.100000    0.100000       0.100000   
    50%        0.300000      0.350000       0.400000    0.400000       0.350000   
    75%        0.950000      1.375000       1.425000    1.500000       1.200000   
    max       13.400000     20.200000      19.500000   18.700000      19.600000   
    
           North West    Gauteng  Mpumalanga    Limpopo      Total  
    count   26.000000  26.000000   26.000000  26.000000  26.000000  
    mean     1.738462   1.146154    1.511538   1.750000   1.361538  
    std      4.117871   2.666418    3.709159   4.346884   3.243711  
    min      0.000000   0.000000    0.000000   0.000000   0.000000  
    25%      0.125000   0.100000    0.100000   0.100000   0.100000  
    50%      0.450000   0.350000    0.350000   0.450000   0.350000  
    75%      1.500000   0.750000    0.950000   1.000000   1.050000  
    max     20.700000  13.400000   18.400000  21.600000  16.300000  
    


```python
print(Table1_Male_Female_Total.replace("?", np.nan).head(5))
print(Table2_Provinces_Total.replace("?", np.nan).head(5))

```

                                                Category  Male  Female  Total
    0                   Food and non-alcoholic beverages  14.7    19.1   16.3
    1         Alcoholic beverages, tobacco and narcotics   1.7     1.0    1.4
    2                              Clothing and footwear   4.8     5.4    5.0
    3   Housing, water, electricity, gas and other fuels  33.5    36.6   34.7
    4  Furnishings, household equipment and routine h...   4.3     3.9    4.1
                                         Category  Western Cape  Eastern Cape  \
    0            Food and non-alcoholic beverages          13.4          20.2   
    1  Alcoholic beverages, tobacco and narcotics           1.0           1.4   
    2                                   Narcotics           0.0           0.0   
    3                                     Tobacco           0.3           0.3   
    4                 Alcohol production services           0.0           0.0   
    
       Northern Cape  Free State  KwaZulu-Natal  North West  Gauteng  Mpumalanga  \
    0           19.5        18.7           19.6        20.7     13.4        18.4   
    1            2.2         2.1            1.3         1.9      1.5         1.3   
    2            0.0         0.1            0.0         0.0      0.0         0.1   
    3            0.6         0.6            0.2         0.4      0.4         0.3   
    4            0.0         0.0            0.0         0.0      0.0         0.0   
    
       Limpopo  Total  
    0     21.6   16.3  
    1      1.2    1.4  
    2      0.0    0.0  
    3      0.3    0.3  
    4      0.0    0.0  
    


```python

merged_df = pd.merge(Table1_Male_Female_Total, Table2_Provinces_Total, on='Category', how='outer')

```

The merged dataframe will be assigned Male_Female_Total_vs_Provinces_Total_Expenditur for tracking purposes.
Then will print data heads to see the preview of the data.


```python
Male_Female_Total_vs_Provinces_Total_Expenditure = merged_df
print(Male_Female_Total_vs_Provinces_Total_Expenditure.head())
```

                                         Category  Male  Female  Total_x  \
    0                 Alcohol production services   0.0     0.0      0.0   
    1  Alcoholic beverages, tobacco and narcotics   1.7     1.0      1.4   
    2                                        Beer   1.4     1.3      0.5   
    3                  Cereal and cereal products  10.9    10.1      3.9   
    4                       Clothing and footwear   4.8     5.4      5.0   
    
       Western Cape  Eastern Cape  Northern Cape  Free State  KwaZulu-Natal  \
    0           0.0           0.0            0.0         0.0            0.0   
    1           1.0           1.4            2.2         2.1            1.3   
    2           0.3           0.4            0.8         0.9            0.5   
    3           2.3           5.4            3.6         3.8            5.3   
    4           NaN           NaN            NaN         NaN            NaN   
    
       North West  Gauteng  Mpumalanga  Limpopo  Total_y  
    0         0.0      0.0         0.0      0.0      0.0  
    1         1.9      1.5         1.3      1.2      1.4  
    2         0.9      0.6         0.5      0.6      0.5  
    3         4.9      3.0         4.8      6.6      3.9  
    4         NaN      NaN         NaN      NaN      NaN  
    

df.info() is used to see the structure of the data.Number of rows,columns,Column names and data types.
How many non-null values each column has.


```python
Male_Female_Total_vs_Provinces_Total_Expenditure.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 37 entries, 0 to 36
    Data columns (total 14 columns):
     #   Column         Non-Null Count  Dtype  
    ---  ------         --------------  -----  
     0   Category       37 non-null     object 
     1   Male           37 non-null     float64
     2   Female         37 non-null     float64
     3   Total_x        37 non-null     float64
     4   Western Cape   26 non-null     float64
     5   Eastern Cape   26 non-null     float64
     6   Northern Cape  26 non-null     float64
     7   Free State     26 non-null     float64
     8   KwaZulu-Natal  26 non-null     float64
     9   North West     26 non-null     float64
     10  Gauteng        26 non-null     float64
     11  Mpumalanga     26 non-null     float64
     12  Limpopo        26 non-null     float64
     13  Total_y        26 non-null     float64
    dtypes: float64(13), object(1)
    memory usage: 4.2+ KB
    


```python
Male_Female_Total_vs_Provinces_Total_Expenditure.tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Category</th>
      <th>Male</th>
      <th>Female</th>
      <th>Total_x</th>
      <th>Western Cape</th>
      <th>Eastern Cape</th>
      <th>Northern Cape</th>
      <th>Free State</th>
      <th>KwaZulu-Natal</th>
      <th>North West</th>
      <th>Gauteng</th>
      <th>Mpumalanga</th>
      <th>Limpopo</th>
      <th>Total_y</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>32</th>
      <td>Tobacco</td>
      <td>1.4</td>
      <td>0.8</td>
      <td>0.3</td>
      <td>0.3</td>
      <td>0.3</td>
      <td>0.6</td>
      <td>0.6</td>
      <td>0.2</td>
      <td>0.4</td>
      <td>0.4</td>
      <td>0.3</td>
      <td>0.3</td>
      <td>0.3</td>
    </tr>
    <tr>
      <th>33</th>
      <td>Transport</td>
      <td>16.8</td>
      <td>12.6</td>
      <td>15.3</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>34</th>
      <td>Vegetables, tubers, plantains, cooking bananas...</td>
      <td>3.7</td>
      <td>3.3</td>
      <td>1.6</td>
      <td>1.4</td>
      <td>2.1</td>
      <td>1.7</td>
      <td>1.7</td>
      <td>2.3</td>
      <td>1.8</td>
      <td>1.1</td>
      <td>1.6</td>
      <td>2.0</td>
      <td>1.6</td>
    </tr>
    <tr>
      <th>35</th>
      <td>Water</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.1</td>
      <td>0.1</td>
      <td>0.0</td>
      <td>0.1</td>
      <td>0.1</td>
      <td>0.0</td>
      <td>0.1</td>
      <td>0.1</td>
      <td>0.0</td>
      <td>0.1</td>
      <td>0.1</td>
    </tr>
    <tr>
      <th>36</th>
      <td>Wine</td>
      <td>0.2</td>
      <td>0.3</td>
      <td>0.3</td>
      <td>0.2</td>
      <td>0.3</td>
      <td>0.3</td>
      <td>0.3</td>
      <td>0.3</td>
      <td>0.4</td>
      <td>0.3</td>
      <td>0.2</td>
      <td>0.1</td>
      <td>0.3</td>
    </tr>
  </tbody>
</table>
</div>




```python
province_cols = ['Western Cape', 'Eastern Cape', 'Northern Cape', 'Free State',
                 'KwaZulu-Natal', 'North West', 'Gauteng', 'Mpumalanga', 'Limpopo']

df_clean = Male_Female_Total_vs_Provinces_Total_Expenditure.dropna(subset=province_cols, how='all')

# Rename columns for clarity
df_clean = df_clean.rename(columns={
    'Total_x': 'Total_by_Gender',
    'Total_y': 'Total_by_Province'
})

# Reshape to long format
df_long = df_clean.melt(
    id_vars=['Category', 'Male', 'Female', 'Total_by_Gender', 'Total_by_Province'],
    value_vars=province_cols,
    var_name='Province',
    value_name='Value'
)

Male_Female_Total_vs_Provinces_Total_Expenditure = df_long

print(Male_Female_Total_vs_Provinces_Total_Expenditure.head())

```

                                         Category  Male  Female  Total_by_Gender  \
    0                 Alcohol production services   0.0     0.0              0.0   
    1  Alcoholic beverages, tobacco and narcotics   1.7     1.0              1.4   
    2                                        Beer   1.4     1.3              0.5   
    3                  Cereal and cereal products  10.9    10.1              3.9   
    4                                Cocoa drinks   0.0     0.0              0.0   
    
       Total_by_Province      Province  Value  
    0                0.0  Western Cape    0.0  
    1                1.4  Western Cape    1.0  
    2                0.5  Western Cape    0.3  
    3                3.9  Western Cape    2.3  
    4                0.0  Western Cape    0.0  
    


```python
Male_Female_Total_vs_Provinces_Total_Expenditure.shape

```




    (234, 7)




```python
Male_Female_Total_vs_Provinces_Total_Expenditure.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 234 entries, 0 to 233
    Data columns (total 7 columns):
     #   Column             Non-Null Count  Dtype  
    ---  ------             --------------  -----  
     0   Category           234 non-null    object 
     1   Male               234 non-null    float64
     2   Female             234 non-null    float64
     3   Total_by_Gender    234 non-null    float64
     4   Total_by_Province  234 non-null    float64
     5   Province           234 non-null    object 
     6   Value              234 non-null    float64
    dtypes: float64(5), object(2)
    memory usage: 12.9+ KB
    


```python
Male_Female_Total_vs_Provinces_Total_Expenditure.isnull().sum()
```




    Category             0
    Male                 0
    Female               0
    Total_by_Gender      0
    Total_by_Province    0
    Province             0
    Value                0
    dtype: int64




```python
import missingno as msno
msno.bar(Male_Female_Total_vs_Provinces_Total_Expenditure)
```




    <Axes: >




    
![png](output_51_1.png)
    



```python
Male_Female_Total_vs_Provinces_Total_Expenditure.columns
```




    Index(['Category', 'Male', 'Female', 'Total_by_Gender', 'Total_by_Province',
           'Province', 'Value'],
          dtype='object')




```python
Male_Female_Total_vs_Provinces_Total_Expenditure.dropna(inplace=True)
```


```python
Male_Female_Total_vs_Provinces_Total_Expenditure.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Category</th>
      <th>Male</th>
      <th>Female</th>
      <th>Total_by_Gender</th>
      <th>Total_by_Province</th>
      <th>Province</th>
      <th>Value</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Alcohol production services</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>Western Cape</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Alcoholic beverages, tobacco and narcotics</td>
      <td>1.7</td>
      <td>1.0</td>
      <td>1.4</td>
      <td>1.4</td>
      <td>Western Cape</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Beer</td>
      <td>1.4</td>
      <td>1.3</td>
      <td>0.5</td>
      <td>0.5</td>
      <td>Western Cape</td>
      <td>0.3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Cereal and cereal products</td>
      <td>10.9</td>
      <td>10.1</td>
      <td>3.9</td>
      <td>3.9</td>
      <td>Western Cape</td>
      <td>2.3</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Cocoa drinks</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>Western Cape</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
Male_Female_Total_vs_Provinces_Total_Expenditure.shape
```




    (234, 7)




```python
Male_Female_Total_vs_Provinces_Total_Expenditure.to_csv('Merged_Expenditure.csv', index=False)
```

# 5.2 Step 2: Data collection and import for District Health Barometer (DHB 202324) #


```python
file_path = r'C:\Users\cash\Desktop\Diabetes_Food_RSA_Protocol\data\District Health Barometer (DHB 202324)\DHB 2024 FY Datafile\AllDistricts_ranks.csv'
AllDistricts_ranks = file_path
AllDistricts_ranks = pd.read_csv(r'C:\Users\cash\Desktop\Diabetes_Food_RSA_Protocol\data\District Health Barometer (DHB 202324)\DHB 2024 FY Datafile\AllDistricts_ranks.csv', header = None )

file_path = r'C:\Users\cash\Desktop\Diabetes_Food_RSA_Protocol\data\District Health Barometer (DHB 202324)\DHB 2024 FY Datafile\District_ranks.csv'
District_ranks = file_path
District_ranks = pd.read_csv(r'C:\Users\cash\Desktop\Diabetes_Food_RSA_Protocol\data\District Health Barometer (DHB 202324)\DHB 2024 FY Datafile\District_ranks.csv', header = None )

file_path = r'C:\Users\cash\Desktop\Diabetes_Food_RSA_Protocol\data\District Health Barometer (DHB 202324)\DHB 2024 FY Datafile\Prov.csv'
Prov = file_path
Prov = pd.read_csv(r'C:\Users\cash\Desktop\Diabetes_Food_RSA_Protocol\data\District Health Barometer (DHB 202324)\DHB 2024 FY Datafile\Prov.csv', header = None )

file_path = r'C:\Users\cash\Desktop\Diabetes_Food_RSA_Protocol\data\District Health Barometer (DHB 202324)\DHB 2024 FY Datafile\ZA.csv'
ZA = file_path
ZA = pd.read_csv(r'C:\Users\cash\Desktop\Diabetes_Food_RSA_Protocol\data\District Health Barometer (DHB 202324)\DHB 2024 FY Datafile\ZA.csv', header = None )

file_path = r'C:\Users\cash\Desktop\Diabetes_Food_RSA_Protocol\data\District Health Barometer (DHB 202324)\DHB 2024 FY Datafile\Defn.csv'
Defn= file_path
Defn = pd.read_csv(r'C:\Users\cash\Desktop\Diabetes_Food_RSA_Protocol\data\District Health Barometer (DHB 202324)\DHB 2024 FY Datafile\Defn.csv', header = None )

```


```python
df = pd.read_excel(r'C:\Users\cash\Desktop\Diabetes_Food_RSA_Protocol\data\District Health Barometer (DHB 202324)\DHB 2024 FY Datafilez.xlsb', sheet_name='AllDistricts_ranks')
```


```python
District_ranks = df
District_ranks.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>geo_level</th>
      <th>(All)</th>
      <th>Unnamed: 2</th>
      <th>Unnamed: 3</th>
      <th>Unnamed: 4</th>
      <th>Unnamed: 5</th>
      <th>Unnamed: 6</th>
      <th>Unnamed: 7</th>
      <th>Unnamed: 8</th>
      <th>Unnamed: 9</th>
      <th>...</th>
      <th>Unnamed: 47</th>
      <th>Unnamed: 48</th>
      <th>Unnamed: 49</th>
      <th>Unnamed: 50</th>
      <th>Unnamed: 51</th>
      <th>Unnamed: 52</th>
      <th>Unnamed: 53</th>
      <th>Unnamed: 54</th>
      <th>Unnamed: 55</th>
      <th>Unnamed: 56</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>recentyear</td>
      <td>(All)</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>data_series</td>
      <td>(All)</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Source</td>
      <td>(All)</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Average of rank</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>geo_district</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 57 columns</p>
</div>




```python
District_ranks = District_ranks.iloc[5:].reset_index(drop=True)
```


```python
District_ranks.columns = District_ranks.iloc[0]
District_ranks = District_ranks.drop(0).reset_index(drop=True)
```


```python
print(District_ranks.head())
```

    0             ind_dhbA                     ind_name data_period (blank)   ETH  \
    0  1_1_Family planning  Couple year protection rate     2011/12     4.6    47   
    1                  NaN                          NaN     2012/13     4.6    46   
    2                  NaN                          NaN     2013/14     4.6    40   
    3                  NaN                          NaN     2014/15     4.5    33   
    4                  NaN                          NaN     2015/16     4.6  80.5   
    
    0  Unk BUF  DC16  DC48    DC5  ...       DC36        DC31 DC44      TSH  \
    0  NaN  39    11    25      7  ...          6          35   45       51   
    1  NaN  47    13    21     11  ...         14          45   49       51   
    2  NaN  43    35    28     10  ...         17          36   52       51   
    3  NaN  25    25    23      5  ...         20          49   52       34   
    4  NaN  40  92.5  60.5  31.75  ...  75.666667  150.142857  170  182.625   
    
    0       DC13         DC7    DC30   DC39   DC10       DC15  
    0         12          21      23     40     13         32  
    1         17          40      44     29     26         39  
    2         19          48      21     16     31         39  
    3         30          51      16     45     44         37  
    4  71.714286  173.444444  147.25  151.5  134.5  63.166667  
    
    [5 rows x 57 columns]
    


```python
# Mapping of district/metro codes to actual names
column_map = {
    'DC48': 'West Rand', 'DC16': 'Eden', 'DC32': 'Ugu', 'DC28': 'Amathole',
    'DC25': 'Mopani', 'DC26': 'Vhembe', 'DC27': 'Waterberg', 'DC42': 'ZF Mgcawu',
    'DC40': 'Pixley Ka Seme', 'DC22': 'Ehlanzeni', 'DC3': 'City of Tshwane',
    'TSH': 'City of Tshwane', 'DC10': 'Johannesburg Metro', 'ETH': 'Ekurhuleni Metro',
    'DC5': 'Cape Town Metro', 'DC4': 'Johannesburg Metro', 'JHB': 'Johannesburg Metro',
    'DC24': 'Overberg', 'DC23': 'Cape Winelands', 'DC43': 'Frances Baard',
    'DC36': 'Sekhukhune', 'EKU': 'Ekurhuleni Metro', 'DC29': 'Mopani', 'DC39': 'John Taolo Gaetsewe',
    'DC35': 'Waterberg', 'DC2': 'Tshwane Metro', 'NMA': 'Namakwa', 'DC21': 'Joe Gqabi',
    'DC30': 'Capricorn', 'DC38': 'Vhembe', 'DC6': 'Tshwane Metro', 'DC12': 'Eastern Cape',
    'DC34': 'Capricorn', 'DC37': 'Mopani', 'DC1': 'Tshwane Metro', 'DC33': 'Waterberg',
    'DC31': 'Mopani', 'CPT': 'Cape Town Metro', 'DC7': 'Tshwane Metro', 'DC19': 'Tshwane Metro',
    'BUF': 'Buffalo City Metro', 'MAN': 'Mangaung Metro', 'DC14': 'Tshwane Metro', 'DC44': 'Tshwane Metro',
    'DC13': 'Tshwane Metro', 'DC9': 'Tshwane Metro', 'DC20': 'Tshwane Metro', 'DC47': 'Tshwane Metro',
    'DC18': 'Tshwane Metro', 'DC15': 'Tshwane Metro', 'DC45': 'Tshwane Metro', 'DC8': 'Tshwane Metro'
}

# Rename the columns
District_ranks = District_ranks.rename(columns=column_map)

# Check the renamed columns
print(District_ranks.columns)
```

    Index(['ind_dhbA', 'ind_name', 'data_period', '(blank)', 'Ekurhuleni Metro',
           'Unk', 'Buffalo City Metro', 'Eden', 'West Rand', 'Cape Town Metro',
           'City of Tshwane', 'Mopani', 'ZF Mgcawu', 'Waterberg', 'Cape Winelands',
           'Mopani', 'Johannesburg Metro', 'Overberg', 'Joe Gqabi',
           'Pixley Ka Seme', 'Mangaung Metro', 'Namakwa', 'Ehlanzeni',
           'Frances Baard', 'Tshwane Metro', 'Ugu', 'Tshwane Metro', 'Vhembe',
           'Amathole', 'Tshwane Metro', 'Tshwane Metro', 'Capricorn', 'Waterberg',
           'Tshwane Metro', 'Tshwane Metro', 'Tshwane Metro', 'Vhembe',
           'Waterberg', 'Tshwane Metro', 'Tshwane Metro', 'Tshwane Metro',
           'Mopani', 'Tshwane Metro', 'Cape Town Metro', 'Ekurhuleni Metro',
           'Eastern Cape', 'Johannesburg Metro', 'Sekhukhune', 'Mopani',
           'Tshwane Metro', 'City of Tshwane', 'Tshwane Metro', 'Tshwane Metro',
           'Capricorn', 'John Taolo Gaetsewe', 'Johannesburg Metro',
           'Tshwane Metro'],
          dtype='object', name=0)
    


```python
District_ranks.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ind_dhbA</th>
      <th>ind_name</th>
      <th>data_period</th>
      <th>(blank)</th>
      <th>Ekurhuleni Metro</th>
      <th>Unk</th>
      <th>Buffalo City Metro</th>
      <th>Eden</th>
      <th>West Rand</th>
      <th>Cape Town Metro</th>
      <th>...</th>
      <th>Sekhukhune</th>
      <th>Mopani</th>
      <th>Tshwane Metro</th>
      <th>City of Tshwane</th>
      <th>Tshwane Metro</th>
      <th>Tshwane Metro</th>
      <th>Capricorn</th>
      <th>John Taolo Gaetsewe</th>
      <th>Johannesburg Metro</th>
      <th>Tshwane Metro</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1_1_Family planning</td>
      <td>Couple year protection rate</td>
      <td>2011/12</td>
      <td>4.6</td>
      <td>47</td>
      <td>NaN</td>
      <td>39</td>
      <td>11</td>
      <td>25</td>
      <td>7</td>
      <td>...</td>
      <td>6</td>
      <td>35</td>
      <td>45</td>
      <td>51</td>
      <td>12</td>
      <td>21</td>
      <td>23</td>
      <td>40</td>
      <td>13</td>
      <td>32</td>
    </tr>
    <tr>
      <th>1</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>2012/13</td>
      <td>4.6</td>
      <td>46</td>
      <td>NaN</td>
      <td>47</td>
      <td>13</td>
      <td>21</td>
      <td>11</td>
      <td>...</td>
      <td>14</td>
      <td>45</td>
      <td>49</td>
      <td>51</td>
      <td>17</td>
      <td>40</td>
      <td>44</td>
      <td>29</td>
      <td>26</td>
      <td>39</td>
    </tr>
    <tr>
      <th>2</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>2013/14</td>
      <td>4.6</td>
      <td>40</td>
      <td>NaN</td>
      <td>43</td>
      <td>35</td>
      <td>28</td>
      <td>10</td>
      <td>...</td>
      <td>17</td>
      <td>36</td>
      <td>52</td>
      <td>51</td>
      <td>19</td>
      <td>48</td>
      <td>21</td>
      <td>16</td>
      <td>31</td>
      <td>39</td>
    </tr>
    <tr>
      <th>3</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>2014/15</td>
      <td>4.5</td>
      <td>33</td>
      <td>NaN</td>
      <td>25</td>
      <td>25</td>
      <td>23</td>
      <td>5</td>
      <td>...</td>
      <td>20</td>
      <td>49</td>
      <td>52</td>
      <td>34</td>
      <td>30</td>
      <td>51</td>
      <td>16</td>
      <td>45</td>
      <td>44</td>
      <td>37</td>
    </tr>
    <tr>
      <th>4</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>2015/16</td>
      <td>4.6</td>
      <td>80.5</td>
      <td>NaN</td>
      <td>40</td>
      <td>92.5</td>
      <td>60.5</td>
      <td>31.75</td>
      <td>...</td>
      <td>75.666667</td>
      <td>150.142857</td>
      <td>170</td>
      <td>182.625</td>
      <td>71.714286</td>
      <td>173.444444</td>
      <td>147.25</td>
      <td>151.5</td>
      <td>134.5</td>
      <td>63.166667</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 57 columns</p>
</div>




```python
# selects all rows from index 407 to the end.and resets the row index to start from 0 and drops the old index column.
District_ranks = District_ranks.iloc[407:].reset_index(drop=True)
```


```python
# preview table for changes 
District_ranks.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ind_dhbA</th>
      <th>ind_name</th>
      <th>data_period</th>
      <th>(blank)</th>
      <th>Ekurhuleni Metro</th>
      <th>Unk</th>
      <th>Buffalo City Metro</th>
      <th>Eden</th>
      <th>West Rand</th>
      <th>Cape Town Metro</th>
      <th>...</th>
      <th>Sekhukhune</th>
      <th>Mopani</th>
      <th>Tshwane Metro</th>
      <th>City of Tshwane</th>
      <th>Tshwane Metro</th>
      <th>Tshwane Metro</th>
      <th>Capricorn</th>
      <th>John Taolo Gaetsewe</th>
      <th>Johannesburg Metro</th>
      <th>Tshwane Metro</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>2017</td>
      <td>4.5</td>
      <td>34</td>
      <td>NaN</td>
      <td>31</td>
      <td>45</td>
      <td>22</td>
      <td>43</td>
      <td>...</td>
      <td>22</td>
      <td>9</td>
      <td>6</td>
      <td>15</td>
      <td>20</td>
      <td>44</td>
      <td>4</td>
      <td>30</td>
      <td>38</td>
      <td>7</td>
    </tr>
    <tr>
      <th>1</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>2008</td>
      <td>4.5</td>
      <td>8</td>
      <td>NaN</td>
      <td>48</td>
      <td>36</td>
      <td>36</td>
      <td>49</td>
      <td>...</td>
      <td>1</td>
      <td>16</td>
      <td>14</td>
      <td>17</td>
      <td>44</td>
      <td>52</td>
      <td>18</td>
      <td>36</td>
      <td>11</td>
      <td>8</td>
    </tr>
    <tr>
      <th>2</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>2010-2011</td>
      <td>4.6</td>
      <td>27</td>
      <td>NaN</td>
      <td>16</td>
      <td>41</td>
      <td>42</td>
      <td>47</td>
      <td>...</td>
      <td>7</td>
      <td>8</td>
      <td>2</td>
      <td>12</td>
      <td>26</td>
      <td>31</td>
      <td>6</td>
      <td>3</td>
      <td>52</td>
      <td>39</td>
    </tr>
    <tr>
      <th>3</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>2014-2015</td>
      <td>4.5</td>
      <td>7</td>
      <td>NaN</td>
      <td>41</td>
      <td>21</td>
      <td>47</td>
      <td>49</td>
      <td>...</td>
      <td>4</td>
      <td>13</td>
      <td>24</td>
      <td>5</td>
      <td>32</td>
      <td>46</td>
      <td>15</td>
      <td>26</td>
      <td>50</td>
      <td>12</td>
    </tr>
    <tr>
      <th>4</th>
      <td>3_2_Diabetes management</td>
      <td>Percentage of adults overweight or obese</td>
      <td>2012</td>
      <td>4.6</td>
      <td>37</td>
      <td>NaN</td>
      <td>17</td>
      <td>9</td>
      <td>46</td>
      <td>7</td>
      <td>...</td>
      <td>32</td>
      <td>23</td>
      <td>34</td>
      <td>29</td>
      <td>10</td>
      <td>5</td>
      <td>39</td>
      <td>4</td>
      <td>6</td>
      <td>14</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 57 columns</p>
</div>




```python
# Keep only rows 4 to 27 (inclusive of index 4, exclusive of 28)
District_ranks = District_ranks.iloc[4:28].reset_index(drop=True)

# Preview
print(District_ranks.head())
```

    0                 ind_dhbA                                  ind_name  \
    0  3_2_Diabetes management  Percentage of adults overweight or obese   
    1                      NaN                                       NaN   
    2                      NaN                                       NaN   
    3                      NaN                                       NaN   
    4                      NaN                                       NaN   
    
    0 data_period (blank) Ekurhuleni Metro  Unk Buffalo City Metro Eden West Rand  \
    0        2012     4.6               37  NaN                 17    9        46   
    1        2017     4.5               27  NaN                 44    3        32   
    2        2018       1              NaN  NaN                NaN  NaN       NaN   
    3        2019       1              NaN  NaN                NaN  NaN       NaN   
    4        2020       1              NaN  NaN                NaN  NaN       NaN   
    
    0 Cape Town Metro  ... Sekhukhune Mopani Tshwane Metro City of Tshwane  \
    0               7  ...         32     23            34              29   
    1              16  ...         31     11            17              39   
    2             NaN  ...        NaN    NaN           NaN             NaN   
    3             NaN  ...        NaN    NaN           NaN             NaN   
    4             NaN  ...        NaN    NaN           NaN             NaN   
    
    0 Tshwane Metro Tshwane Metro Capricorn John Taolo Gaetsewe  \
    0            10             5        39                   4   
    1            19            45        29                   4   
    2           NaN           NaN       NaN                 NaN   
    3           NaN           NaN       NaN                 NaN   
    4           NaN           NaN       NaN                 NaN   
    
    0 Johannesburg Metro Tshwane Metro  
    0                  6            14  
    1                 40            15  
    2                NaN           NaN  
    3                NaN           NaN  
    4                NaN           NaN  
    
    [5 rows x 57 columns]
    


```python
District_ranks.columns
```




    Index(['ind_dhbA', 'ind_name', 'data_period', '(blank)', 'Ekurhuleni Metro',
           'Unk', 'Buffalo City Metro', 'Eden', 'West Rand', 'Cape Town Metro',
           'City of Tshwane', 'Mopani', 'ZF Mgcawu', 'Waterberg', 'Cape Winelands',
           'Mopani', 'Johannesburg Metro', 'Overberg', 'Joe Gqabi',
           'Pixley Ka Seme', 'Mangaung Metro', 'Namakwa', 'Ehlanzeni',
           'Frances Baard', 'Tshwane Metro', 'Ugu', 'Tshwane Metro', 'Vhembe',
           'Amathole', 'Tshwane Metro', 'Tshwane Metro', 'Capricorn', 'Waterberg',
           'Tshwane Metro', 'Tshwane Metro', 'Tshwane Metro', 'Vhembe',
           'Waterberg', 'Tshwane Metro', 'Tshwane Metro', 'Tshwane Metro',
           'Mopani', 'Tshwane Metro', 'Cape Town Metro', 'Ekurhuleni Metro',
           'Eastern Cape', 'Johannesburg Metro', 'Sekhukhune', 'Mopani',
           'Tshwane Metro', 'City of Tshwane', 'Tshwane Metro', 'Tshwane Metro',
           'Capricorn', 'John Taolo Gaetsewe', 'Johannesburg Metro',
           'Tshwane Metro'],
          dtype='object', name=0)




```python
# Replace NaN values in ind_name for rows 0–8 (Python indexing)
District_ranks.loc[0:8, 'ind_name'] = 'Percentage of adults overweight or obese'

# Replace NaN values in ind_name for rows 9–22
District_ranks.loc[9:22, 'ind_name'] = 'Diabetes prevalence'
```


```python
District_ranks.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ind_dhbA</th>
      <th>ind_name</th>
      <th>data_period</th>
      <th>(blank)</th>
      <th>Ekurhuleni Metro</th>
      <th>Unk</th>
      <th>Buffalo City Metro</th>
      <th>Eden</th>
      <th>West Rand</th>
      <th>Cape Town Metro</th>
      <th>...</th>
      <th>Sekhukhune</th>
      <th>Mopani</th>
      <th>Tshwane Metro</th>
      <th>City of Tshwane</th>
      <th>Tshwane Metro</th>
      <th>Tshwane Metro</th>
      <th>Capricorn</th>
      <th>John Taolo Gaetsewe</th>
      <th>Johannesburg Metro</th>
      <th>Tshwane Metro</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>3_2_Diabetes management</td>
      <td>Percentage of adults overweight or obese</td>
      <td>2012</td>
      <td>4.6</td>
      <td>37</td>
      <td>NaN</td>
      <td>17</td>
      <td>9</td>
      <td>46</td>
      <td>7</td>
      <td>...</td>
      <td>32</td>
      <td>23</td>
      <td>34</td>
      <td>29</td>
      <td>10</td>
      <td>5</td>
      <td>39</td>
      <td>4</td>
      <td>6</td>
      <td>14</td>
    </tr>
    <tr>
      <th>1</th>
      <td>NaN</td>
      <td>Percentage of adults overweight or obese</td>
      <td>2017</td>
      <td>4.5</td>
      <td>27</td>
      <td>NaN</td>
      <td>44</td>
      <td>3</td>
      <td>32</td>
      <td>16</td>
      <td>...</td>
      <td>31</td>
      <td>11</td>
      <td>17</td>
      <td>39</td>
      <td>19</td>
      <td>45</td>
      <td>29</td>
      <td>4</td>
      <td>40</td>
      <td>15</td>
    </tr>
    <tr>
      <th>2</th>
      <td>NaN</td>
      <td>Percentage of adults overweight or obese</td>
      <td>2018</td>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>NaN</td>
      <td>Percentage of adults overweight or obese</td>
      <td>2019</td>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>NaN</td>
      <td>Percentage of adults overweight or obese</td>
      <td>2020</td>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 57 columns</p>
</div>




```python
# lets look at the outliers 

import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Strip column names
District_ranks.columns = District_ranks.columns.str.strip()

# Use only the district columns (your list)
district_cols = [
    'Ekurhuleni Metro', 'Unk', 'Buffalo City Metro', 'Eden', 'West Rand', 'Cape Town Metro',
    'City of Tshwane', 'Mopani', 'ZF Mgcawu', 'Waterberg', 'Cape Winelands', 'Mopani',
    'Johannesburg Metro', 'Overberg', 'Joe Gqabi', 'Pixley Ka Seme', 'Mangaung Metro', 
    'Namakwa', 'Ehlanzeni', 'Frances Baard', 'Tshwane Metro', 'Ugu', 'Tshwane Metro', 
    'Vhembe', 'Amathole', 'Tshwane Metro', 'Tshwane Metro', 'Capricorn', 'Waterberg', 
    'Tshwane Metro', 'Tshwane Metro', 'Tshwane Metro', 'Vhembe', 'Waterberg', 'Tshwane Metro',
    'Tshwane Metro', 'Tshwane Metro', 'Mopani', 'Tshwane Metro', 'Cape Town Metro', 
    'Ekurhuleni Metro', 'Eastern Cape', 'Johannesburg Metro', 'Sekhukhune', 'Mopani',
    'Tshwane Metro', 'City of Tshwane', 'Tshwane Metro', 'Tshwane Metro', 'Capricorn',
    'John Taolo Gaetsewe', 'Johannesburg Metro', 'Tshwane Metro'
]

# Keep only these columns
df_districts = District_ranks[district_cols]

# Convert all columns to numeric
df_districts = df_districts.apply(pd.to_numeric, errors='coerce')

# Reshape to long format for plotting
df_long = df_districts.melt(var_name='district', value_name='value').dropna()

# Boxplot
plt.figure(figsize=(18,6))
sns.boxplot(x='district', y='value', data=df_long)
plt.xticks(rotation=90)
plt.title('Boxplot of Values by District')
plt.tight_layout()
plt.show()

# Optional: detect outliers
outliers = df_long.groupby('district').apply(
    lambda x: x[(x['value'] < (x['value'].quantile(0.25) - 1.5*(x['value'].quantile(0.75)-x['value'].quantile(0.25)))) |
                (x['value'] > (x['value'].quantile(0.75) + 1.5*(x['value'].quantile(0.75)-x['value'].quantile(0.25)))) ]
).reset_index(drop=True)

print("Detected outliers:")
print(outliers)

```


    
![png](output_72_0.png)
    


    Detected outliers:
                   district  value
    0                  Eden    9.0
    1                  Eden    3.0
    2             Ehlanzeni   38.0
    3             Ehlanzeni   50.0
    4             Ehlanzeni   43.0
    5             Joe Gqabi   42.0
    6             Joe Gqabi   42.0
    7             Joe Gqabi   51.0
    8   John Taolo Gaetsewe   31.0
    9        Mangaung Metro   42.0
    10           Sekhukhune   32.0
    11           Sekhukhune   31.0
    12           Sekhukhune   39.0
    13                  Ugu   33.0
    14                  Ugu   13.0
    15                  Ugu   21.0
    16                  Ugu   20.0
    17            Waterberg   35.0
    18            Waterberg   35.0
    19            Waterberg   35.0
    

    C:\Users\cash\AppData\Local\Temp\ipykernel_2824\3059890818.py:42: DeprecationWarning: DataFrameGroupBy.apply operated on the grouping columns. This behavior is deprecated, and in a future version of pandas the grouping columns will be excluded from the operation. Either pass `include_groups=False` to exclude the groupings or explicitly select the grouping columns after groupby to silence this warning.
      outliers = df_long.groupby('district').apply(
    


```python
District_ranks.to_csv('District_ranks.csv', index=False)

```

# 5.3. Step 3 : collection of General Household Survey (GHS 2023)


```python
# Household dataset
file_path_hhold = r'C:\Users\cash\Desktop\Diabetes_Food_RSA_Protocol\data\General Household Survey (GHS 2023)\ghs-2023-v1\ghs-2023-hhold-v1.csv'
ghs_2023_hhold_v1 = pd.read_csv(file_path_hhold, encoding='cp1252')

# Person dataset
file_path_person = r'C:\Users\cash\Desktop\Diabetes_Food_RSA_Protocol\data\General Household Survey (GHS 2023)\ghs-2023-v1\ghs-2023-person-v1.csv'
ghs_2023_person_v1 = pd.read_csv(file_path_person, encoding='cp1252')
```


```python
ghs_2023_hhold_v1.head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>uqnr</th>
      <th>personnr</th>
      <th>psu</th>
      <th>prov</th>
      <th>head_popgrp</th>
      <th>head_sex</th>
      <th>head_age</th>
      <th>hsg_maind</th>
      <th>hsg_walls</th>
      <th>hsg_roof</th>
      <th>...</th>
      <th>disab_hh</th>
      <th>sevdisab_hh</th>
      <th>econact_hh</th>
      <th>totmhinc</th>
      <th>stratum</th>
      <th>geotype</th>
      <th>metro</th>
      <th>metro_code</th>
      <th>rotation</th>
      <th>house_wgt</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>160100090000003901</td>
      <td>1</td>
      <td>16010009000</td>
      <td>1. Western Cape</td>
      <td>2. Coloured</td>
      <td>1. Male</td>
      <td>80. 80</td>
      <td>1. Dwelling/house or brick/concrete block stru...</td>
      <td>7. Mud and cement mix</td>
      <td>2. Corrugated iron/zinc</td>
      <td>...</td>
      <td>0. 0</td>
      <td>0. 0</td>
      <td>1. 1</td>
      <td>9475. 9475</td>
      <td>10301</td>
      <td>3</td>
      <td>2. Non-metro</td>
      <td>1. WC - Non-metro</td>
      <td>3. Quarter 3</td>
      <td>697.943521</td>
    </tr>
    <tr>
      <th>1</th>
      <td>160100090000007201</td>
      <td>1</td>
      <td>16010009000</td>
      <td>1. Western Cape</td>
      <td>2. Coloured</td>
      <td>1. Male</td>
      <td>51. 51</td>
      <td>5. Townhouse (semi-detached house in complex)</td>
      <td>1. Bricks</td>
      <td>2. Corrugated iron/zinc</td>
      <td>...</td>
      <td>0. 0</td>
      <td>0. 0</td>
      <td>1. 1</td>
      <td>2008. 2008</td>
      <td>10301</td>
      <td>3</td>
      <td>2. Non-metro</td>
      <td>1. WC - Non-metro</td>
      <td>3. Quarter 3</td>
      <td>954.777641</td>
    </tr>
    <tr>
      <th>2</th>
      <td>160100090000007202</td>
      <td>1</td>
      <td>16010009000</td>
      <td>1. Western Cape</td>
      <td>1. African/Black</td>
      <td>1. Male</td>
      <td>25. 25</td>
      <td>5. Townhouse (semi-detached house in complex)</td>
      <td>1. Bricks</td>
      <td>2. Corrugated iron/zinc</td>
      <td>...</td>
      <td>0. 0</td>
      <td>0. 0</td>
      <td>2. 2</td>
      <td>6926. 6926</td>
      <td>10301</td>
      <td>3</td>
      <td>2. Non-metro</td>
      <td>1. WC - Non-metro</td>
      <td>3. Quarter 3</td>
      <td>1814.933335</td>
    </tr>
    <tr>
      <th>3</th>
      <td>160100090000013801</td>
      <td>1</td>
      <td>16010009000</td>
      <td>1. Western Cape</td>
      <td>2. Coloured</td>
      <td>1. Male</td>
      <td>51. 51</td>
      <td>1. Dwelling/house or brick/concrete block stru...</td>
      <td>1. Bricks</td>
      <td>11. Asbestos</td>
      <td>...</td>
      <td>0. 0</td>
      <td>0. 0</td>
      <td>2. 2</td>
      <td>6205. 6205</td>
      <td>10301</td>
      <td>3</td>
      <td>2. Non-metro</td>
      <td>1. WC - Non-metro</td>
      <td>3. Quarter 3</td>
      <td>954.777641</td>
    </tr>
    <tr>
      <th>4</th>
      <td>160100330000001101</td>
      <td>1</td>
      <td>16010033000</td>
      <td>1. Western Cape</td>
      <td>2. Coloured</td>
      <td>1. Male</td>
      <td>57. 57</td>
      <td>1. Dwelling/house or brick/concrete block stru...</td>
      <td>1. Bricks</td>
      <td>2. Corrugated iron/zinc</td>
      <td>...</td>
      <td>0. 0</td>
      <td>0. 0</td>
      <td>4. 4</td>
      <td>48560. 48560</td>
      <td>10107</td>
      <td>1</td>
      <td>2. Non-metro</td>
      <td>1. WC - Non-metro</td>
      <td>4. Quarter 4</td>
      <td>711.090181</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 188 columns</p>
</div>




```python
ghs_2023_person_v1.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>uqnr</th>
      <th>personnr</th>
      <th>psu</th>
      <th>prov</th>
      <th>Four_by_Four</th>
      <th>Sex</th>
      <th>age</th>
      <th>age_grp1</th>
      <th>Population</th>
      <th>Languages</th>
      <th>...</th>
      <th>sevdisab</th>
      <th>geotype</th>
      <th>metro_code</th>
      <th>metro</th>
      <th>stratum</th>
      <th>lab_salary</th>
      <th>employ_Status1</th>
      <th>employ_Status2</th>
      <th>rotation</th>
      <th>person_wgt</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>160100090000003901</td>
      <td>1</td>
      <td>16010009000</td>
      <td>1. Western Cape</td>
      <td>1. Yes</td>
      <td>1. Male</td>
      <td>80. 80</td>
      <td>16. 75+</td>
      <td>2. Coloured</td>
      <td>1. Afrikaans</td>
      <td>...</td>
      <td>0. Not disabled</td>
      <td>3</td>
      <td>1. WC - Non-metro</td>
      <td>2. Non-metro</td>
      <td>10301</td>
      <td>9475. 9475</td>
      <td>1. Employed</td>
      <td>1. Employed</td>
      <td>3. Quarter 3</td>
      <td>646.795630</td>
    </tr>
    <tr>
      <th>1</th>
      <td>160100090000003901</td>
      <td>2</td>
      <td>16010009000</td>
      <td>1. Western Cape</td>
      <td>1. Yes</td>
      <td>2. Female</td>
      <td>77. 77</td>
      <td>16. 75+</td>
      <td>2. Coloured</td>
      <td>1. Afrikaans</td>
      <td>...</td>
      <td>0. Not disabled</td>
      <td>3</td>
      <td>1. WC - Non-metro</td>
      <td>2. Non-metro</td>
      <td>10301</td>
      <td>888888888. Not applicable</td>
      <td>9. Unspecified</td>
      <td>3. Not economically active</td>
      <td>3. Quarter 3</td>
      <td>646.795630</td>
    </tr>
    <tr>
      <th>2</th>
      <td>160100090000007201</td>
      <td>1</td>
      <td>16010009000</td>
      <td>1. Western Cape</td>
      <td>1. Yes</td>
      <td>1. Male</td>
      <td>51. 51</td>
      <td>11. 50-54</td>
      <td>2. Coloured</td>
      <td>1. Afrikaans</td>
      <td>...</td>
      <td>0. Not disabled</td>
      <td>3</td>
      <td>1. WC - Non-metro</td>
      <td>2. Non-metro</td>
      <td>10301</td>
      <td>2008. 2008</td>
      <td>1. Employed</td>
      <td>1. Employed</td>
      <td>3. Quarter 3</td>
      <td>907.023646</td>
    </tr>
    <tr>
      <th>3</th>
      <td>160100090000007202</td>
      <td>1</td>
      <td>16010009000</td>
      <td>1. Western Cape</td>
      <td>1. Yes</td>
      <td>1. Male</td>
      <td>25. 25</td>
      <td>6. 25-29</td>
      <td>1. African/Black</td>
      <td>14. Other language not specified</td>
      <td>...</td>
      <td>0. Not disabled</td>
      <td>3</td>
      <td>1. WC - Non-metro</td>
      <td>2. Non-metro</td>
      <td>10301</td>
      <td>3929. 3929</td>
      <td>1. Employed</td>
      <td>1. Employed</td>
      <td>3. Quarter 3</td>
      <td>1566.659927</td>
    </tr>
    <tr>
      <th>4</th>
      <td>160100090000007202</td>
      <td>2</td>
      <td>16010009000</td>
      <td>1. Western Cape</td>
      <td>1. Yes</td>
      <td>2. Female</td>
      <td>23. 23</td>
      <td>5. 20-24</td>
      <td>1. African/Black</td>
      <td>14. Other language not specified</td>
      <td>...</td>
      <td>0. Not disabled</td>
      <td>3</td>
      <td>1. WC - Non-metro</td>
      <td>2. Non-metro</td>
      <td>10301</td>
      <td>2997. 2997</td>
      <td>1. Employed</td>
      <td>1. Employed</td>
      <td>3. Quarter 3</td>
      <td>1566.659927</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 112 columns</p>
</div>




```python
# preview information and shape of the data(rows column)
ghs_2023_hhold_v1.info()
ghs_2023_hhold_v1.shape
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 20927 entries, 0 to 20926
    Columns: 188 entries, uqnr to house_wgt
    dtypes: float64(1), int64(5), object(182)
    memory usage: 30.0+ MB
    




    (20927, 188)




```python
# preview columns of the data  ghs_2023_hhold_v1 and ghs_2023_person_v1
print("Household columns:", ghs_2023_hhold_v1.columns.tolist())
print("Person columns:", ghs_2023_person_v1.columns.tolist())
```

    Household columns: ['uqnr', 'personnr', 'psu', 'prov', 'head_popgrp', 'head_sex', 'head_age', 'hsg_maind', 'hsg_walls', 'hsg_roof', 'hsg_floor', 'hsg_cond_wall', 'hsg_cond_roof', 'hsg_cond_floor', 'hsg_rm_tot', 'hsg_tenure', 'hsg_rent', 'hsg_rdp', 'hsg_subsidy', 'wat_drinkwat', 'wat_dist', 'wat_time', 'wat_pipe', 'wat_treat', 'wat_mun_source', 'wat_meter', 'wat_pay', 'wat_inte_12mth', 'wat_inte_2days', 'wat_inte_altsource', 'wat_inte_15days', 'wat_bottle', 'san_toil', 'san_share', 'san_location', 'san_distance', 'san_washfac', 'san_wash', 'eng_access', 'eng_mainelect', 'eng_mains', 'eng_supply', 'eng_cook', 'eng_light', 'eng_wheat', 'eng_sheat', 'eng_loadshed_freq', 'eng_light_alt', 'eng_cook_alt', 'eng_pay', 'swr_rub', 'swr_sepwaste', 'swr_env_rub', 'swr_env_lit', 'swr_env_wat', 'swr_env_air', 'swr_env_lan', 'swr_env_noi', 'com_phone', 'com_cell', 'com_cell_total', 'com_int_fixed', 'com_int_mobile', 'com_int_pubwifi', 'com_int_stud', 'com_int_work', 'com_int_libr', 'com_int_cafe', 'com_mail_post', 'com_mail_Pbag', 'com_mail_Postnet', 'com_mail_Other', 'tra_taxi', 'tra_bus', 'tra_train', 'tra_taxi_trips', 'tra_taxi_cost', 'tra_taxi_dist', 'tra_bus_trips', 'tra_bus_cost', 'tra_bus_dist', 'tra_train_trips', 'tra_train_cost', 'tra_train_dist', 'hhw_hltfac', 'hhw_transp', 'hhw_time', 'fsd_hung_adult', 'fsd_hung_child', 'fsd_worried', 'fsd_healthy', 'fsd_fewfoods', 'fsd_fewfoods_days', 'fsd_skipped', 'fsd_skipped_days', 'fsd_ateless', 'fsd_ateless_days', 'fsd_ranout', 'fsd_ranout_days', 'fsd_hungry', 'fsd_whlday', 'agr_agri', 'agr_agrino', 'agr_agrdecmaker', 'agr_agri_type_live', 'agr_agri_type_poul', 'agr_agri_type_grai', 'agr_agri_type_indus', 'agr_agri_type_fruit', 'agr_agri_type_fod', 'agr_agri_type_fish', 'agr_agri_type_for', 'agr_agri_type_game', 'agr_mainuse', 'agr_plant_farm', 'agr_plant_back', 'agr_plant_schl', 'agr_plant_comm', 'agr_plant_vrd', 'agr_plant_oth', 'fin_inc_sal', 'fin_inc_buss', 'fin_inc_rem', 'fin_inc_pen', 'fin_inc_grant', 'fin_inc_agric', 'fin_inc_none', 'fin_inc_oth', 'fin_inc_main', 'fin_rem', 'fin_pen', 'fin_reqinc', 'fin_compinc', 'fin_exp', 'hwl_vehicle', 'hwl_totveh', 'hwl_domw', 'hwl_status', 'hwl_happy', 'hwl_assets_tv', 'hwl_assets_pool', 'hwl_assets_dvd', 'hwl_assets_paytv', 'hwl_assets_ac', 'hwl_assets_comp', 'hwl_assets_vac', 'hwl_assets_dishw', 'hwl_assets_washm', 'HWL_Assets_tumd', 'hwl_assets_freezer', 'hwl_assets_fridge', 'hwl_assets_estove', 'hwl_assets_microw', 'hwl_assets_sink', 'hwl_assets_secure', 'hwl_assets_hometh', 'hwl_assets_geyser', 'hwl_assets_solarg', 'hwl_assets_solarp', 'hwl_assets_rainwtnk', 'hwl_assets_borehole', 'hwl_assets_piano', 'hwl_assets_radio', 'hwl_assets_Gstove', 'hwl_res_name', 'Q1ntLanguage', 'Q2Dwelling', 'hholdsz', 'mobphon_hh', 'smartphone_hh', 'onemed_hh', 'chld5yr_hh', 'chld17yr_hh', 'ad60plusyr_hh', 'lab_salary_hh', 'soc_grant_hh', 'totalgrnt_hh', 'undisab_hh', 'disab_hh', 'sevdisab_hh', 'econact_hh', 'totmhinc', 'stratum', 'geotype', 'metro', 'metro_code', 'rotation', 'house_wgt']
    Person columns: ['uqnr', 'personnr', 'psu', 'prov', 'Four_by_Four', 'Sex', 'age', 'age_grp1', 'Population', 'Languages', 'hhc_relationship', 'hhc_marital', 'spouse', 'spouse_name', 'hhc_fath_alive', 'hhc_fath_parthh', 'hhc_fath_name', 'hhc_moth_alive', 'hhc_moth_parthh', 'hhc_moth_name', 'education', 'ecd_chldatt', 'ecd_notatt', 'ecd_notatt_rsn', 'ecd_fees', 'ecd_read', 'ecd_sing', 'ecd_colour', 'ecd_object', 'ecd_count', 'ecd_play', 'edu_attend', 'edu_rsnn', 'edu_edui', 'edu_ppriv', 'edu_corr', 'edu_mode_tr', 'edu_time', 'edu_burs', 'edu_totfees', 'edu_nofees', 'edu_grde', 'edu_same', 'edu_food', 'edu_eatfood', 'edu_vlnc', 'edu_vlnc_corp', 'edu_vlnc_phyt', 'edu_vlnc_vert', 'edu_vlnc_verl', 'edu_vlnc_phyl', 'edu_abs', 'edu_abs_days', 'edu_abs_rsn', 'hlt_medi', 'hlt_genhealth', 'hlt_chronic_asm', 'hlt_chronic_dbt', 'hlt_chronic_can', 'hlt_chronic_HIV', 'hlt_chronic_hbp', 'hlt_chronic_arth', 'hlt_chronic_strk', 'hlt_chronic_tb', 'hlt_chronic_broncho', 'hlt_preg', 'hlt_pregstat', 'dsb_see', 'dsb_hea', 'dsb_wal', 'dsb_rem', 'dsb_sel', 'dsb_com', 'soc_grant', 'soc_grant_oag', 'soc_grant_dis', 'soc_grant_csg', 'soc_grant_csg_topup', 'soc_grant_car', 'soc_grant_fos', 'soc_grant_grn', 'soc_grant_srd', 'Itp_cell', 'Itp_cell_sphone', 'lab_wge', 'lab_bus', 'lab_vol', 'lab_ret', 'lab_amount', 'lab_sto', 'lab_salper', 'lab_salc', 'lab_transp', 'lab_mins', 'lab_sector', 'lab_look', 'lab_start', 'lab_rnsw', 'lab_accjob', 'lab_res_name', 'undisab', 'disab', 'sevdisab', 'geotype', 'metro_code', 'metro', 'stratum', 'lab_salary', 'employ_Status1', 'employ_Status2', 'rotation', 'person_wgt']
    


```python
# Merge household info onto person records using uqnr
merged_df = pd.merge(
    ghs_2023_person_v1,
    ghs_2023_hhold_v1,
    how="left",
    on="uqnr"
)

print("Merged shape:", merged_df.shape)
print(merged_df.head())

```

    Merged shape: (71174, 299)
                     uqnr  personnr_x        psu_x           prov_x Four_by_Four  \
    0  160100090000003901           1  16010009000  1. Western Cape       1. Yes   
    1  160100090000003901           2  16010009000  1. Western Cape       1. Yes   
    2  160100090000007201           1  16010009000  1. Western Cape       1. Yes   
    3  160100090000007202           1  16010009000  1. Western Cape       1. Yes   
    4  160100090000007202           2  16010009000  1. Western Cape       1. Yes   
    
             Sex     age   age_grp1        Population  \
    0    1. Male  80. 80    16. 75+       2. Coloured   
    1  2. Female  77. 77    16. 75+       2. Coloured   
    2    1. Male  51. 51  11. 50-54       2. Coloured   
    3    1. Male  25. 25   6. 25-29  1. African/Black   
    4  2. Female  23. 23   5. 20-24  1. African/Black   
    
                              Languages  ... disab_hh sevdisab_hh econact_hh  \
    0                      1. Afrikaans  ...     0. 0        0. 0       1. 1   
    1                      1. Afrikaans  ...     0. 0        0. 0       1. 1   
    2                      1. Afrikaans  ...     0. 0        0. 0       1. 1   
    3  14. Other language not specified  ...     0. 0        0. 0       2. 2   
    4  14. Other language not specified  ...     0. 0        0. 0       2. 2   
    
         totmhinc stratum_y geotype_y       metro_y       metro_code_y  \
    0  9475. 9475     10301         3  2. Non-metro  1. WC - Non-metro   
    1  9475. 9475     10301         3  2. Non-metro  1. WC - Non-metro   
    2  2008. 2008     10301         3  2. Non-metro  1. WC - Non-metro   
    3  6926. 6926     10301         3  2. Non-metro  1. WC - Non-metro   
    4  6926. 6926     10301         3  2. Non-metro  1. WC - Non-metro   
    
         rotation_y    house_wgt  
    0  3. Quarter 3   697.943521  
    1  3. Quarter 3   697.943521  
    2  3. Quarter 3   954.777641  
    3  3. Quarter 3  1814.933335  
    4  3. Quarter 3  1814.933335  
    
    [5 rows x 299 columns]
    


```python
# preview statistical summary of merged table
hhold_person=merged_df
hhold_person.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>uqnr</th>
      <th>personnr_x</th>
      <th>psu_x</th>
      <th>geotype_x</th>
      <th>stratum_x</th>
      <th>person_wgt</th>
      <th>personnr_y</th>
      <th>psu_y</th>
      <th>stratum_y</th>
      <th>geotype_y</th>
      <th>house_wgt</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>7.117400e+04</td>
      <td>71174.000000</td>
      <td>7.117400e+04</td>
      <td>71174.000000</td>
      <td>71174.000000</td>
      <td>71174.000000</td>
      <td>71174.0</td>
      <td>7.117400e+04</td>
      <td>71174.000000</td>
      <td>71174.000000</td>
      <td>71174.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>6.137849e+17</td>
      <td>3.013038</td>
      <td>6.137849e+10</td>
      <td>1.424495</td>
      <td>55312.920111</td>
      <td>875.084424</td>
      <td>1.0</td>
      <td>6.137849e+10</td>
      <td>55312.920111</td>
      <td>1.424495</td>
      <td>855.915887</td>
    </tr>
    <tr>
      <th>std</th>
      <td>2.499323e+17</td>
      <td>2.201355</td>
      <td>2.499323e+10</td>
      <td>0.555565</td>
      <td>25887.920582</td>
      <td>449.307958</td>
      <td>0.0</td>
      <td>2.499323e+10</td>
      <td>25887.920582</td>
      <td>0.555565</td>
      <td>381.676271</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.601001e+17</td>
      <td>1.000000</td>
      <td>1.601001e+10</td>
      <td>1.000000</td>
      <td>10101.000000</td>
      <td>50.000000</td>
      <td>1.0</td>
      <td>1.601001e+10</td>
      <td>10101.000000</td>
      <td>1.000000</td>
      <td>229.835524</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>3.811009e+17</td>
      <td>1.000000</td>
      <td>3.811008e+10</td>
      <td>1.000000</td>
      <td>30103.000000</td>
      <td>586.837194</td>
      <td>1.0</td>
      <td>3.811008e+10</td>
      <td>30103.000000</td>
      <td>1.000000</td>
      <td>587.142802</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>5.991477e+17</td>
      <td>2.000000</td>
      <td>5.991477e+10</td>
      <td>1.000000</td>
      <td>55201.000000</td>
      <td>805.468336</td>
      <td>1.0</td>
      <td>5.991477e+10</td>
      <td>55201.000000</td>
      <td>1.000000</td>
      <td>796.181878</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>7.981645e+17</td>
      <td>4.000000</td>
      <td>7.981645e+10</td>
      <td>2.000000</td>
      <td>77116.000000</td>
      <td>1071.302535</td>
      <td>1.0</td>
      <td>7.981645e+10</td>
      <td>77116.000000</td>
      <td>2.000000</td>
      <td>1025.737154</td>
    </tr>
    <tr>
      <th>max</th>
      <td>9.871069e+17</td>
      <td>24.000000</td>
      <td>9.871069e+10</td>
      <td>3.000000</td>
      <td>90401.000000</td>
      <td>6132.389694</td>
      <td>1.0</td>
      <td>9.871069e+10</td>
      <td>90401.000000</td>
      <td>3.000000</td>
      <td>4246.689111</td>
    </tr>
  </tbody>
</table>
</div>




```python
# display few rows of the data
hhold_person.head(5)

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>uqnr</th>
      <th>personnr_x</th>
      <th>psu_x</th>
      <th>prov_x</th>
      <th>Four_by_Four</th>
      <th>Sex</th>
      <th>age</th>
      <th>age_grp1</th>
      <th>Population</th>
      <th>Languages</th>
      <th>...</th>
      <th>disab_hh</th>
      <th>sevdisab_hh</th>
      <th>econact_hh</th>
      <th>totmhinc</th>
      <th>stratum_y</th>
      <th>geotype_y</th>
      <th>metro_y</th>
      <th>metro_code_y</th>
      <th>rotation_y</th>
      <th>house_wgt</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>160100090000003901</td>
      <td>1</td>
      <td>16010009000</td>
      <td>1. Western Cape</td>
      <td>1. Yes</td>
      <td>1. Male</td>
      <td>80. 80</td>
      <td>16. 75+</td>
      <td>2. Coloured</td>
      <td>1. Afrikaans</td>
      <td>...</td>
      <td>0. 0</td>
      <td>0. 0</td>
      <td>1. 1</td>
      <td>9475. 9475</td>
      <td>10301</td>
      <td>3</td>
      <td>2. Non-metro</td>
      <td>1. WC - Non-metro</td>
      <td>3. Quarter 3</td>
      <td>697.943521</td>
    </tr>
    <tr>
      <th>1</th>
      <td>160100090000003901</td>
      <td>2</td>
      <td>16010009000</td>
      <td>1. Western Cape</td>
      <td>1. Yes</td>
      <td>2. Female</td>
      <td>77. 77</td>
      <td>16. 75+</td>
      <td>2. Coloured</td>
      <td>1. Afrikaans</td>
      <td>...</td>
      <td>0. 0</td>
      <td>0. 0</td>
      <td>1. 1</td>
      <td>9475. 9475</td>
      <td>10301</td>
      <td>3</td>
      <td>2. Non-metro</td>
      <td>1. WC - Non-metro</td>
      <td>3. Quarter 3</td>
      <td>697.943521</td>
    </tr>
    <tr>
      <th>2</th>
      <td>160100090000007201</td>
      <td>1</td>
      <td>16010009000</td>
      <td>1. Western Cape</td>
      <td>1. Yes</td>
      <td>1. Male</td>
      <td>51. 51</td>
      <td>11. 50-54</td>
      <td>2. Coloured</td>
      <td>1. Afrikaans</td>
      <td>...</td>
      <td>0. 0</td>
      <td>0. 0</td>
      <td>1. 1</td>
      <td>2008. 2008</td>
      <td>10301</td>
      <td>3</td>
      <td>2. Non-metro</td>
      <td>1. WC - Non-metro</td>
      <td>3. Quarter 3</td>
      <td>954.777641</td>
    </tr>
    <tr>
      <th>3</th>
      <td>160100090000007202</td>
      <td>1</td>
      <td>16010009000</td>
      <td>1. Western Cape</td>
      <td>1. Yes</td>
      <td>1. Male</td>
      <td>25. 25</td>
      <td>6. 25-29</td>
      <td>1. African/Black</td>
      <td>14. Other language not specified</td>
      <td>...</td>
      <td>0. 0</td>
      <td>0. 0</td>
      <td>2. 2</td>
      <td>6926. 6926</td>
      <td>10301</td>
      <td>3</td>
      <td>2. Non-metro</td>
      <td>1. WC - Non-metro</td>
      <td>3. Quarter 3</td>
      <td>1814.933335</td>
    </tr>
    <tr>
      <th>4</th>
      <td>160100090000007202</td>
      <td>2</td>
      <td>16010009000</td>
      <td>1. Western Cape</td>
      <td>1. Yes</td>
      <td>2. Female</td>
      <td>23. 23</td>
      <td>5. 20-24</td>
      <td>1. African/Black</td>
      <td>14. Other language not specified</td>
      <td>...</td>
      <td>0. 0</td>
      <td>0. 0</td>
      <td>2. 2</td>
      <td>6926. 6926</td>
      <td>10301</td>
      <td>3</td>
      <td>2. Non-metro</td>
      <td>1. WC - Non-metro</td>
      <td>3. Quarter 3</td>
      <td>1814.933335</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 299 columns</p>
</div>




```python
# Remove prefixes like 1. Yes, 80. 80, 2. Non-metro and convert into proper values and charecters 
import pandas as pd

for col in hhold_person.columns:
    if hhold_person[col].dtype == 'object':
        # Remove prefixes like "1. ", "2. " and strip extra spaces
        cleaned = hhold_person[col].astype(str).str.split('.').str[-1].str.strip()
        
        # Convert to numeric where possible, leave text as text
        try:
            hhold_person[col] = pd.to_numeric(cleaned)
        except ValueError:
            hhold_person[col] = cleaned

# Preview cleaned data
print(hhold_person.head())

```

                     uqnr  personnr_x        psu_x        prov_x Four_by_Four  \
    0  160100090000003901           1  16010009000  Western Cape          Yes   
    1  160100090000003901           2  16010009000  Western Cape          Yes   
    2  160100090000007201           1  16010009000  Western Cape          Yes   
    3  160100090000007202           1  16010009000  Western Cape          Yes   
    4  160100090000007202           2  16010009000  Western Cape          Yes   
    
          Sex  age age_grp1     Population                     Languages  ...  \
    0    Male   80      75+       Coloured                     Afrikaans  ...   
    1  Female   77      75+       Coloured                     Afrikaans  ...   
    2    Male   51    50-54       Coloured                     Afrikaans  ...   
    3    Male   25    25-29  African/Black  Other language not specified  ...   
    4  Female   23    20-24  African/Black  Other language not specified  ...   
    
      disab_hh sevdisab_hh econact_hh totmhinc stratum_y geotype_y    metro_y  \
    0        0           0          1     9475     10301         3  Non-metro   
    1        0           0          1     9475     10301         3  Non-metro   
    2        0           0          1     2008     10301         3  Non-metro   
    3        0           0          2     6926     10301         3  Non-metro   
    4        0           0          2     6926     10301         3  Non-metro   
    
         metro_code_y rotation_y    house_wgt  
    0  WC - Non-metro  Quarter 3   697.943521  
    1  WC - Non-metro  Quarter 3   697.943521  
    2  WC - Non-metro  Quarter 3   954.777641  
    3  WC - Non-metro  Quarter 3  1814.933335  
    4  WC - Non-metro  Quarter 3  1814.933335  
    
    [5 rows x 299 columns]
    


```python
# Retrieve data types
hhold_person.dtypes
```




    uqnr              int64
    personnr_x        int64
    psu_x             int64
    prov_x           object
    Four_by_Four     object
                     ...   
    geotype_y         int64
    metro_y          object
    metro_code_y     object
    rotation_y       object
    house_wgt       float64
    Length: 299, dtype: object




```python
# looking at the changes 
hhold_person.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>uqnr</th>
      <th>personnr_x</th>
      <th>psu_x</th>
      <th>prov_x</th>
      <th>Four_by_Four</th>
      <th>Sex</th>
      <th>age</th>
      <th>age_grp1</th>
      <th>Population</th>
      <th>Languages</th>
      <th>...</th>
      <th>disab_hh</th>
      <th>sevdisab_hh</th>
      <th>econact_hh</th>
      <th>totmhinc</th>
      <th>stratum_y</th>
      <th>geotype_y</th>
      <th>metro_y</th>
      <th>metro_code_y</th>
      <th>rotation_y</th>
      <th>house_wgt</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>160100090000003901</td>
      <td>1</td>
      <td>16010009000</td>
      <td>Western Cape</td>
      <td>Yes</td>
      <td>Male</td>
      <td>80</td>
      <td>75+</td>
      <td>Coloured</td>
      <td>Afrikaans</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9475</td>
      <td>10301</td>
      <td>3</td>
      <td>Non-metro</td>
      <td>WC - Non-metro</td>
      <td>Quarter 3</td>
      <td>697.943521</td>
    </tr>
    <tr>
      <th>1</th>
      <td>160100090000003901</td>
      <td>2</td>
      <td>16010009000</td>
      <td>Western Cape</td>
      <td>Yes</td>
      <td>Female</td>
      <td>77</td>
      <td>75+</td>
      <td>Coloured</td>
      <td>Afrikaans</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9475</td>
      <td>10301</td>
      <td>3</td>
      <td>Non-metro</td>
      <td>WC - Non-metro</td>
      <td>Quarter 3</td>
      <td>697.943521</td>
    </tr>
    <tr>
      <th>2</th>
      <td>160100090000007201</td>
      <td>1</td>
      <td>16010009000</td>
      <td>Western Cape</td>
      <td>Yes</td>
      <td>Male</td>
      <td>51</td>
      <td>50-54</td>
      <td>Coloured</td>
      <td>Afrikaans</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2008</td>
      <td>10301</td>
      <td>3</td>
      <td>Non-metro</td>
      <td>WC - Non-metro</td>
      <td>Quarter 3</td>
      <td>954.777641</td>
    </tr>
    <tr>
      <th>3</th>
      <td>160100090000007202</td>
      <td>1</td>
      <td>16010009000</td>
      <td>Western Cape</td>
      <td>Yes</td>
      <td>Male</td>
      <td>25</td>
      <td>25-29</td>
      <td>African/Black</td>
      <td>Other language not specified</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>6926</td>
      <td>10301</td>
      <td>3</td>
      <td>Non-metro</td>
      <td>WC - Non-metro</td>
      <td>Quarter 3</td>
      <td>1814.933335</td>
    </tr>
    <tr>
      <th>4</th>
      <td>160100090000007202</td>
      <td>2</td>
      <td>16010009000</td>
      <td>Western Cape</td>
      <td>Yes</td>
      <td>Female</td>
      <td>23</td>
      <td>20-24</td>
      <td>African/Black</td>
      <td>Other language not specified</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>6926</td>
      <td>10301</td>
      <td>3</td>
      <td>Non-metro</td>
      <td>WC - Non-metro</td>
      <td>Quarter 3</td>
      <td>1814.933335</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 299 columns</p>
</div>




```python
hhold_person.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>uqnr</th>
      <th>personnr_x</th>
      <th>psu_x</th>
      <th>age</th>
      <th>geotype_x</th>
      <th>stratum_x</th>
      <th>person_wgt</th>
      <th>personnr_y</th>
      <th>psu_y</th>
      <th>head_age</th>
      <th>...</th>
      <th>chld17yr_hh</th>
      <th>ad60plusyr_hh</th>
      <th>totalgrnt_hh</th>
      <th>undisab_hh</th>
      <th>disab_hh</th>
      <th>sevdisab_hh</th>
      <th>econact_hh</th>
      <th>stratum_y</th>
      <th>geotype_y</th>
      <th>house_wgt</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>7.117400e+04</td>
      <td>71174.000000</td>
      <td>7.117400e+04</td>
      <td>71174.000000</td>
      <td>71174.000000</td>
      <td>71174.000000</td>
      <td>71174.000000</td>
      <td>71174.0</td>
      <td>7.117400e+04</td>
      <td>71174.000000</td>
      <td>...</td>
      <td>71174.000000</td>
      <td>71174.000000</td>
      <td>71174.000000</td>
      <td>71174.000000</td>
      <td>71174.000000</td>
      <td>71174.000000</td>
      <td>71174.000000</td>
      <td>71174.000000</td>
      <td>71174.000000</td>
      <td>71174.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>6.137849e+17</td>
      <td>3.013038</td>
      <td>6.137849e+10</td>
      <td>30.203557</td>
      <td>1.424495</td>
      <td>55312.920111</td>
      <td>875.084424</td>
      <td>1.0</td>
      <td>6.137849e+10</td>
      <td>52.267275</td>
      <td>...</td>
      <td>2.083963</td>
      <td>0.448535</td>
      <td>1876.711580</td>
      <td>0.252859</td>
      <td>0.520626</td>
      <td>0.158948</td>
      <td>1.049527</td>
      <td>55312.920111</td>
      <td>1.424495</td>
      <td>855.915887</td>
    </tr>
    <tr>
      <th>std</th>
      <td>2.499323e+17</td>
      <td>2.201355</td>
      <td>2.499323e+10</td>
      <td>20.788712</td>
      <td>0.555565</td>
      <td>25887.920582</td>
      <td>449.307958</td>
      <td>0.0</td>
      <td>2.499323e+10</td>
      <td>15.004239</td>
      <td>...</td>
      <td>1.921456</td>
      <td>0.670204</td>
      <td>1931.764002</td>
      <td>0.580190</td>
      <td>0.868742</td>
      <td>0.456083</td>
      <td>0.978205</td>
      <td>25887.920582</td>
      <td>0.555565</td>
      <td>381.676271</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.601001e+17</td>
      <td>1.000000</td>
      <td>1.601001e+10</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>10101.000000</td>
      <td>50.000000</td>
      <td>1.0</td>
      <td>1.601001e+10</td>
      <td>10.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>10101.000000</td>
      <td>1.000000</td>
      <td>229.835524</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>3.811009e+17</td>
      <td>1.000000</td>
      <td>3.811008e+10</td>
      <td>13.000000</td>
      <td>1.000000</td>
      <td>30103.000000</td>
      <td>586.837194</td>
      <td>1.0</td>
      <td>3.811008e+10</td>
      <td>41.000000</td>
      <td>...</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>30103.000000</td>
      <td>1.000000</td>
      <td>587.142802</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>5.991477e+17</td>
      <td>2.000000</td>
      <td>5.991477e+10</td>
      <td>27.000000</td>
      <td>1.000000</td>
      <td>55201.000000</td>
      <td>805.468336</td>
      <td>1.0</td>
      <td>5.991477e+10</td>
      <td>52.000000</td>
      <td>...</td>
      <td>2.000000</td>
      <td>0.000000</td>
      <td>1440.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>55201.000000</td>
      <td>1.000000</td>
      <td>796.181878</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>7.981645e+17</td>
      <td>4.000000</td>
      <td>7.981645e+10</td>
      <td>45.000000</td>
      <td>2.000000</td>
      <td>77116.000000</td>
      <td>1071.302535</td>
      <td>1.0</td>
      <td>7.981645e+10</td>
      <td>63.000000</td>
      <td>...</td>
      <td>3.000000</td>
      <td>1.000000</td>
      <td>2950.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>2.000000</td>
      <td>77116.000000</td>
      <td>2.000000</td>
      <td>1025.737154</td>
    </tr>
    <tr>
      <th>max</th>
      <td>9.871069e+17</td>
      <td>24.000000</td>
      <td>9.871069e+10</td>
      <td>110.000000</td>
      <td>3.000000</td>
      <td>90401.000000</td>
      <td>6132.389694</td>
      <td>1.0</td>
      <td>9.871069e+10</td>
      <td>109.000000</td>
      <td>...</td>
      <td>12.000000</td>
      <td>4.000000</td>
      <td>12040.000000</td>
      <td>6.000000</td>
      <td>9.000000</td>
      <td>6.000000</td>
      <td>8.000000</td>
      <td>90401.000000</td>
      <td>3.000000</td>
      <td>4246.689111</td>
    </tr>
  </tbody>
</table>
<p>8 rows × 24 columns</p>
</div>




```python
hhold_person.to_csv('hhold_person',index=False)
```

# 6. DATA WRANGLING AND EXPLORATORY DATA ANALYSIS #

| Dataframs to be used |
|----------------------|
|1.hhold_person        |
|2.District_ranks      |
|3.Male_Female_Total_vs_Provinces_Total_Expenditure|

## 6.1. Aggregation & Grouping focusing on variables relating to Diabetes ##

| PREVIEW ROWS AND COLUMNS OF EACH DADAFRAM.|
|-------------------------------------------|


```python
hhold_person.head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>uqnr</th>
      <th>personnr_x</th>
      <th>psu_x</th>
      <th>prov_x</th>
      <th>Four_by_Four</th>
      <th>Sex</th>
      <th>age</th>
      <th>age_grp1</th>
      <th>Population</th>
      <th>Languages</th>
      <th>...</th>
      <th>disab_hh</th>
      <th>sevdisab_hh</th>
      <th>econact_hh</th>
      <th>totmhinc</th>
      <th>stratum_y</th>
      <th>geotype_y</th>
      <th>metro_y</th>
      <th>metro_code_y</th>
      <th>rotation_y</th>
      <th>house_wgt</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>160100090000003901</td>
      <td>1</td>
      <td>16010009000</td>
      <td>Western Cape</td>
      <td>Yes</td>
      <td>Male</td>
      <td>80</td>
      <td>75+</td>
      <td>Coloured</td>
      <td>Afrikaans</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9475</td>
      <td>10301</td>
      <td>3</td>
      <td>Non-metro</td>
      <td>WC - Non-metro</td>
      <td>Quarter 3</td>
      <td>697.943521</td>
    </tr>
    <tr>
      <th>1</th>
      <td>160100090000003901</td>
      <td>2</td>
      <td>16010009000</td>
      <td>Western Cape</td>
      <td>Yes</td>
      <td>Female</td>
      <td>77</td>
      <td>75+</td>
      <td>Coloured</td>
      <td>Afrikaans</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9475</td>
      <td>10301</td>
      <td>3</td>
      <td>Non-metro</td>
      <td>WC - Non-metro</td>
      <td>Quarter 3</td>
      <td>697.943521</td>
    </tr>
    <tr>
      <th>2</th>
      <td>160100090000007201</td>
      <td>1</td>
      <td>16010009000</td>
      <td>Western Cape</td>
      <td>Yes</td>
      <td>Male</td>
      <td>51</td>
      <td>50-54</td>
      <td>Coloured</td>
      <td>Afrikaans</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2008</td>
      <td>10301</td>
      <td>3</td>
      <td>Non-metro</td>
      <td>WC - Non-metro</td>
      <td>Quarter 3</td>
      <td>954.777641</td>
    </tr>
    <tr>
      <th>3</th>
      <td>160100090000007202</td>
      <td>1</td>
      <td>16010009000</td>
      <td>Western Cape</td>
      <td>Yes</td>
      <td>Male</td>
      <td>25</td>
      <td>25-29</td>
      <td>African/Black</td>
      <td>Other language not specified</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>6926</td>
      <td>10301</td>
      <td>3</td>
      <td>Non-metro</td>
      <td>WC - Non-metro</td>
      <td>Quarter 3</td>
      <td>1814.933335</td>
    </tr>
    <tr>
      <th>4</th>
      <td>160100090000007202</td>
      <td>2</td>
      <td>16010009000</td>
      <td>Western Cape</td>
      <td>Yes</td>
      <td>Female</td>
      <td>23</td>
      <td>20-24</td>
      <td>African/Black</td>
      <td>Other language not specified</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>6926</td>
      <td>10301</td>
      <td>3</td>
      <td>Non-metro</td>
      <td>WC - Non-metro</td>
      <td>Quarter 3</td>
      <td>1814.933335</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 299 columns</p>
</div>




```python
District_ranks.head(6)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ind_dhbA</th>
      <th>ind_name</th>
      <th>data_period</th>
      <th>(blank)</th>
      <th>Ekurhuleni Metro</th>
      <th>Unk</th>
      <th>Buffalo City Metro</th>
      <th>Eden</th>
      <th>West Rand</th>
      <th>Cape Town Metro</th>
      <th>...</th>
      <th>Sekhukhune</th>
      <th>Mopani</th>
      <th>Tshwane Metro</th>
      <th>City of Tshwane</th>
      <th>Tshwane Metro</th>
      <th>Tshwane Metro</th>
      <th>Capricorn</th>
      <th>John Taolo Gaetsewe</th>
      <th>Johannesburg Metro</th>
      <th>Tshwane Metro</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>3_2_Diabetes management</td>
      <td>Percentage of adults overweight or obese</td>
      <td>2012</td>
      <td>4.6</td>
      <td>37</td>
      <td>NaN</td>
      <td>17</td>
      <td>9</td>
      <td>46</td>
      <td>7</td>
      <td>...</td>
      <td>32</td>
      <td>23</td>
      <td>34</td>
      <td>29</td>
      <td>10</td>
      <td>5</td>
      <td>39</td>
      <td>4</td>
      <td>6</td>
      <td>14</td>
    </tr>
    <tr>
      <th>1</th>
      <td>NaN</td>
      <td>Percentage of adults overweight or obese</td>
      <td>2017</td>
      <td>4.5</td>
      <td>27</td>
      <td>NaN</td>
      <td>44</td>
      <td>3</td>
      <td>32</td>
      <td>16</td>
      <td>...</td>
      <td>31</td>
      <td>11</td>
      <td>17</td>
      <td>39</td>
      <td>19</td>
      <td>45</td>
      <td>29</td>
      <td>4</td>
      <td>40</td>
      <td>15</td>
    </tr>
    <tr>
      <th>2</th>
      <td>NaN</td>
      <td>Percentage of adults overweight or obese</td>
      <td>2018</td>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>NaN</td>
      <td>Percentage of adults overweight or obese</td>
      <td>2019</td>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>NaN</td>
      <td>Percentage of adults overweight or obese</td>
      <td>2020</td>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>5</th>
      <td>NaN</td>
      <td>Percentage of adults overweight or obese</td>
      <td>2008</td>
      <td>4.6</td>
      <td>28</td>
      <td>NaN</td>
      <td>34</td>
      <td>22</td>
      <td>40</td>
      <td>8</td>
      <td>...</td>
      <td>19</td>
      <td>7</td>
      <td>30</td>
      <td>39</td>
      <td>30</td>
      <td>1</td>
      <td>47</td>
      <td>2</td>
      <td>37</td>
      <td>33</td>
    </tr>
  </tbody>
</table>
<p>6 rows × 57 columns</p>
</div>




```python
Male_Female_Total_vs_Provinces_Total_Expenditure.head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Category</th>
      <th>Male</th>
      <th>Female</th>
      <th>Total_by_Gender</th>
      <th>Total_by_Province</th>
      <th>Province</th>
      <th>Value</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Alcohol production services</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>Western Cape</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Alcoholic beverages, tobacco and narcotics</td>
      <td>1.7</td>
      <td>1.0</td>
      <td>1.4</td>
      <td>1.4</td>
      <td>Western Cape</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Beer</td>
      <td>1.4</td>
      <td>1.3</td>
      <td>0.5</td>
      <td>0.5</td>
      <td>Western Cape</td>
      <td>0.3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Cereal and cereal products</td>
      <td>10.9</td>
      <td>10.1</td>
      <td>3.9</td>
      <td>3.9</td>
      <td>Western Cape</td>
      <td>2.3</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Cocoa drinks</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>Western Cape</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
</div>



## 6.2. Aggregate hhold_person ##


```python
# Remove numbering and extra spaces
hhold_person['Sex'] = hhold_person['Sex'].astype(str).str.split('.').str[-1].str.strip()

```


```python
# Convert 'totmhinc' to numeric, coerce errors to NaN
hhold_person['totmhinc'] = pd.to_numeric(hhold_person['totmhinc'], errors='coerce')

```


```python
province_summary = hhold_person.groupby('prov_x').agg({
    'personnr_x': 'count',                             # Population per province
    'totmhinc': 'mean',                                # Average income
    'hlt_chronic_dbt': lambda x: (x == 1).sum(),      # Diabetic cases
    'hlt_chronic_hbp': lambda x: (x == 1).sum()       # Hypertension cases
}).reset_index()

province_summary.rename(columns={
    'personnr_x': 'Population',
    'totmhinc': 'Avg_Income',
    'hlt_chronic_dbt': 'Diabetic_Cases',
    'hlt_chronic_hbp': 'Hypertension_Cases'
}, inplace=True)

print(province_summary)

```

              prov_x  Population    Avg_Income  Diabetic_Cases  Hypertension_Cases
    0   Eastern Cape        9677   9224.617687               0                   0
    1     Free State        4192   9537.846934               0                   0
    2        Gauteng       16443  15950.324468               0                   0
    3  KwaZulu-Natal       13162  12345.190583               0                   0
    4        Limpopo        8265  10094.563032               0                   0
    5     Mpumalanga        5817   9497.779465               0                   0
    6     North West        4285   9076.246056               0                   0
    7  Northern Cape        3160  11414.289726               0                   0
    8   Western Cape        6173  21596.026835               0                   0
    


```python
print(hhold_person['hlt_chronic_dbt'].unique())
print(hhold_person['hlt_chronic_hbp'].unique())

```

    ['No' 'Yes' 'Unspecified']
    ['Yes' 'No' 'Unspecified']
    


```python
summary = hhold_person.groupby('prov_x').agg(
    Population=('prov_x', 'count'),
    Avg_Income=('totmhinc', 'mean'),
    Diabetic_Cases=('hlt_chronic_dbt', lambda x: (x == 'Yes').sum()),
    Hypertension_Cases=('hlt_chronic_hbp', lambda x: (x == 'Yes').sum())
).reset_index()

print(summary)

```

              prov_x  Population    Avg_Income  Diabetic_Cases  Hypertension_Cases
    0   Eastern Cape        9677   9224.617687             401                1156
    1     Free State        4192   9537.846934             133                 502
    2        Gauteng       16443  15950.324468             409                1325
    3  KwaZulu-Natal       13162  12345.190583             414                 951
    4        Limpopo        8265  10094.563032             123                 481
    5     Mpumalanga        5817   9497.779465             121                 464
    6     North West        4285   9076.246056             109                 529
    7  Northern Cape        3160  11414.289726              99                 427
    8   Western Cape        6173  21596.026835             349                 826
    


```python
# calculate percentages of diabetic and hypertension cases relative to the population for each province

summary['Diabetes_%'] = (summary['Diabetic_Cases'] / summary['Population'] * 100).round(2)
summary['Hypertension_%'] = (summary['Hypertension_Cases'] / summary['Population'] * 100).round(2)

print(summary)

```

              prov_x  Population    Avg_Income  Diabetic_Cases  \
    0   Eastern Cape        9677   9224.617687             401   
    1     Free State        4192   9537.846934             133   
    2        Gauteng       16443  15950.324468             409   
    3  KwaZulu-Natal       13162  12345.190583             414   
    4        Limpopo        8265  10094.563032             123   
    5     Mpumalanga        5817   9497.779465             121   
    6     North West        4285   9076.246056             109   
    7  Northern Cape        3160  11414.289726              99   
    8   Western Cape        6173  21596.026835             349   
    
       Hypertension_Cases  Diabetes_%  Hypertension_%  
    0                1156        4.14           11.95  
    1                 502        3.17           11.98  
    2                1325        2.49            8.06  
    3                 951        3.15            7.23  
    4                 481        1.49            5.82  
    5                 464        2.08            7.98  
    6                 529        2.54           12.35  
    7                 427        3.13           13.51  
    8                 826        5.65           13.38  
    


```python
summary.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>prov_x</th>
      <th>Population</th>
      <th>Avg_Income</th>
      <th>Diabetic_Cases</th>
      <th>Hypertension_Cases</th>
      <th>Diabetes_%</th>
      <th>Hypertension_%</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Eastern Cape</td>
      <td>9677</td>
      <td>9224.617687</td>
      <td>401</td>
      <td>1156</td>
      <td>4.14</td>
      <td>11.95</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Free State</td>
      <td>4192</td>
      <td>9537.846934</td>
      <td>133</td>
      <td>502</td>
      <td>3.17</td>
      <td>11.98</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Gauteng</td>
      <td>16443</td>
      <td>15950.324468</td>
      <td>409</td>
      <td>1325</td>
      <td>2.49</td>
      <td>8.06</td>
    </tr>
    <tr>
      <th>3</th>
      <td>KwaZulu-Natal</td>
      <td>13162</td>
      <td>12345.190583</td>
      <td>414</td>
      <td>951</td>
      <td>3.15</td>
      <td>7.23</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Limpopo</td>
      <td>8265</td>
      <td>10094.563032</td>
      <td>123</td>
      <td>481</td>
      <td>1.49</td>
      <td>5.82</td>
    </tr>
  </tbody>
</table>
</div>



# 6.3 DATA VISUALIZATION OF hhold_person #

| Correlation Matrix of Diabetes Dataset |
|----------------------------------------|


```python
import matplotlib.pyplot as plt
import seaborn as sns

# Select only numeric columns
numeric_summary = summary.select_dtypes(include=['number'])

# Plot heatmap
plt.figure(figsize=(8,6))
sns.heatmap(numeric_summary.corr(), annot=True, cmap="coolwarm", fmt=".2f")
plt.title("Correlation Matrix of Diabetes Dataset")
plt.show()
```


    
![png](output_105_0.png)
    


| Boxplot to detect outliers |
|----------------------------|


```python
# Select numeric columns
numeric_summary = summary.select_dtypes(include=['number'])

# Boxplot for all numeric columns
plt.figure(figsize=(12,6))
sns.boxplot(data=numeric_summary)
plt.title("Boxplot of Numeric Variables (Outliers)")
plt.show()
```


    
![png](output_107_0.png)
    


|  Diabetes Cases by Province  |
|------------------------------|


```python
# Diabetes Cases by Province
plt.figure(figsize=(10,6))
sns.barplot(x='prov_x', y='Diabetic_Cases', data=summary, palette='Reds_r')
plt.xticks(rotation=45, ha='right')
plt.xlabel('Province')
plt.ylabel('Number of Diabetic Cases')
plt.title('Diabetes Cases by Province')
plt.show()
```

    C:\Users\cash\AppData\Local\Temp\ipykernel_2824\711753071.py:3: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `x` variable to `hue` and set `legend=False` for the same effect.
    
      sns.barplot(x='prov_x', y='Diabetic_Cases', data=summary, palette='Reds_r')
    


    
![png](output_109_1.png)
    


| Diabetes vs Hypertension Cases by Province with Regression Line |
|-----------------------------------------------------------------|


```python
import matplotlib.pyplot as plt
import seaborn as sns

plt.figure(figsize=(8,6))

# Scatter plot with regression line
sns.regplot(
    x='Diabetic_Cases', 
    y='Hypertension_Cases', 
    data=summary,
    scatter_kws={'s':100, 'color':'blue'},  # point size and color
    line_kws={'color':'red'}                 # regression line color
)

# Add province labels
for i, row in summary.iterrows():
    plt.text(row['Diabetic_Cases']+5, row['Hypertension_Cases']+5, row['prov_x'], fontsize=9)

plt.xlabel('Diabetes Cases')
plt.ylabel('Hypertension Cases')
plt.title('Diabetes vs Hypertension Cases by Province with Regression Line')
plt.grid(True)
plt.show()

```


    
![png](output_111_0.png)
    



```python
# Group by Age Group
age_summary = hhold_person.groupby('age_grp1').agg(
    Population=('personnr_x', 'count'),
    Diabetic_Cases=('hlt_chronic_dbt', lambda x: (x == 'Yes').sum()),
    Hypertension_Cases=('hlt_chronic_hbp', lambda x: (x == 'Yes').sum())
).reset_index()
age_summary.head(50)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age_grp1</th>
      <th>Population</th>
      <th>Diabetic_Cases</th>
      <th>Hypertension_Cases</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>00-04</td>
      <td>6390</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>05-09</td>
      <td>6632</td>
      <td>3</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>10-14</td>
      <td>7234</td>
      <td>3</td>
      <td>7</td>
    </tr>
    <tr>
      <th>3</th>
      <td>15-19</td>
      <td>6891</td>
      <td>4</td>
      <td>6</td>
    </tr>
    <tr>
      <th>4</th>
      <td>20-24</td>
      <td>5408</td>
      <td>7</td>
      <td>22</td>
    </tr>
    <tr>
      <th>5</th>
      <td>25-29</td>
      <td>5435</td>
      <td>12</td>
      <td>32</td>
    </tr>
    <tr>
      <th>6</th>
      <td>30-34</td>
      <td>5432</td>
      <td>31</td>
      <td>108</td>
    </tr>
    <tr>
      <th>7</th>
      <td>35-39</td>
      <td>5263</td>
      <td>58</td>
      <td>183</td>
    </tr>
    <tr>
      <th>8</th>
      <td>40-44</td>
      <td>4557</td>
      <td>78</td>
      <td>352</td>
    </tr>
    <tr>
      <th>9</th>
      <td>45-49</td>
      <td>3848</td>
      <td>128</td>
      <td>472</td>
    </tr>
    <tr>
      <th>10</th>
      <td>50-54</td>
      <td>3421</td>
      <td>228</td>
      <td>744</td>
    </tr>
    <tr>
      <th>11</th>
      <td>55-59</td>
      <td>2940</td>
      <td>307</td>
      <td>914</td>
    </tr>
    <tr>
      <th>12</th>
      <td>60-64</td>
      <td>2610</td>
      <td>367</td>
      <td>1083</td>
    </tr>
    <tr>
      <th>13</th>
      <td>65-69</td>
      <td>2001</td>
      <td>344</td>
      <td>970</td>
    </tr>
    <tr>
      <th>14</th>
      <td>70-74</td>
      <td>1344</td>
      <td>261</td>
      <td>747</td>
    </tr>
    <tr>
      <th>15</th>
      <td>75+</td>
      <td>1768</td>
      <td>327</td>
      <td>1019</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Diabetes vs Hypertension Cases by Age Group

plt.figure(figsize=(10,6))
sns.scatterplot(
    data=age_summary,
    x='Diabetic_Cases',
    y='Hypertension_Cases',
    hue='age_grp1',
    s=100 , 
    
)
plt.title('Diabetes vs Hypertension Cases by Age Group')
plt.xlabel('Diabetic Cases')
plt.ylabel('Hypertension Cases')
plt.legend(title='Age Group', bbox_to_anchor=(1.05, 1), loc='upper left')
plt.show()

```


    
![png](output_113_0.png)
    



```python
# province_age_summary
province_age_summary = hhold_person.groupby(['prov_x', 'age_grp1']).agg(
    Population=('personnr_x', 'count'),
    Diabetic_Cases=('hlt_chronic_dbt', lambda x: (x == 'Yes').sum()),
    Hypertension_Cases=('hlt_chronic_hbp', lambda x: (x == 'Yes').sum())
).reset_index()
province_age_summary.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>prov_x</th>
      <th>age_grp1</th>
      <th>Population</th>
      <th>Diabetic_Cases</th>
      <th>Hypertension_Cases</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Eastern Cape</td>
      <td>00-04</td>
      <td>930</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Eastern Cape</td>
      <td>05-09</td>
      <td>950</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Eastern Cape</td>
      <td>10-14</td>
      <td>1128</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Eastern Cape</td>
      <td>15-19</td>
      <td>995</td>
      <td>0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Eastern Cape</td>
      <td>20-24</td>
      <td>617</td>
      <td>0</td>
      <td>4</td>
    </tr>
  </tbody>
</table>
</div>




```python
import matplotlib.pyplot as plt
import seaborn as sns

plt.figure(figsize=(12,6))
sns.barplot(
    data= province_age_summary,
    x='age_grp1',
    y='Diabetic_Cases',
    hue='prov_x',      # separate bars by province
    palette='tab10'
)
plt.title('Diabetic Cases by Province and Age Group')
plt.xlabel('Age Group')
plt.ylabel('Number of Diabetic Cases')
plt.xticks(rotation=45)
plt.legend(title='Province', bbox_to_anchor=(1.05, 1))
plt.show()

```


    
![png](output_115_0.png)
    



```python
# Group by Gender (Corrected)
gender_summary = hhold_person.groupby('Sex').agg(
    Population=('personnr_x', 'count'),
    Diabetic_Cases=('hlt_chronic_dbt', lambda x: (x == 'Yes').sum()),
    Hypertension_Cases=('hlt_chronic_hbp', lambda x: (x == 'Yes').sum())
).reset_index()

gender_summary.head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Sex</th>
      <th>Population</th>
      <th>Diabetic_Cases</th>
      <th>Hypertension_Cases</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Female</td>
      <td>36827</td>
      <td>1460</td>
      <td>4638</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Male</td>
      <td>34347</td>
      <td>698</td>
      <td>2023</td>
    </tr>
  </tbody>
</table>
</div>




```python
plt.figure(figsize=(8,6))
sns.barplot(
    data=gender_summary,   # Replace with your DataFrame for sex summary
    x='Sex',
    y='Diabetic_Cases',
    palette='viridis'
)
plt.title('Diabetic Cases by Sex')
plt.xlabel('Sex')
plt.ylabel('Diabetic Cases')
plt.show()

```

    C:\Users\cash\AppData\Local\Temp\ipykernel_2824\4132891492.py:2: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `x` variable to `hue` and set `legend=False` for the same effect.
    
      sns.barplot(
    


    
![png](output_117_1.png)
    



```python
plt.figure(figsize=(8,6))
sns.barplot(
    data= gender_summary,   # Replace with your DataFrame for sex summary
    x='Sex',
    y='Hypertension_Cases',
    palette='magma'
)
plt.title('Hypertension Cases by Sex')
plt.xlabel('Sex')
plt.ylabel('Hypertension Cases')
plt.show()

```

    C:\Users\cash\AppData\Local\Temp\ipykernel_2824\1386744552.py:2: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `x` variable to `hue` and set `legend=False` for the same effect.
    
      sns.barplot(
    


    
![png](output_118_1.png)
    



```python
import folium

# Approximate lat/lon for South African provinces
province_coords = {
    'Eastern Cape': [-32.0, 26.0],
    'Free State': [-28.5, 26.5],
    'Gauteng': [-26.0, 28.0],
    'KwaZulu-Natal': [-29.0, 31.5],
    'Limpopo': [-23.5, 29.0],
    'Mpumalanga': [-25.5, 31.0],
    'North West': [-26.5, 25.5],
    'Northern Cape': [-29.5, 21.5],
    'Western Cape': [-33.0, 19.0]
}

# Example province summary (replace with your aggregated data)
province_summary = province_age_summary.groupby('prov_x').agg(
    Population=('Population', 'sum'),
    Diabetic_Cases=('Diabetic_Cases', 'sum'),
    Hypertension_Cases=('Hypertension_Cases', 'sum')
).reset_index()

# Create Folium map
m = folium.Map(location=[-30, 25], zoom_start=5)

# Add circle markers for diabetes and hypertension
for _, row in province_summary.iterrows():
    lat, lon = province_coords[row['prov_x']]
    
    # Diabetes cases (red)
    folium.CircleMarker(
        location=[lat, lon],
        radius=row['Diabetic_Cases']/100,  # scale for visibility
        color='red',
        fill=True,
        fill_color='red',
        fill_opacity=0.6,
        popup=f"{row['prov_x']}: {row['Diabetic_Cases']} Diabetic Cases"
    ).add_to(m)
    
    # Hypertension cases (blue)
    folium.CircleMarker(
        location=[lat, lon],
        radius=row['Hypertension_Cases']/100,
        color='blue',
        fill=True,
        fill_color='blue',
        fill_opacity=0.6,
        popup=f"{row['prov_x']}: {row['Hypertension_Cases']} Hypertension Cases"
    ).add_to(m)

# Display map
m

```




<div style="width:100%;"><div style="position:relative;width:100%;height:0;padding-bottom:60%;"><span style="color:#565656">Make this Notebook Trusted to load map: File -> Trust Notebook</span><iframe srcdoc="&lt;!DOCTYPE html&gt;
&lt;html&gt;
&lt;head&gt;

    &lt;meta http-equiv=&quot;content-type&quot; content=&quot;text/html; charset=UTF-8&quot; /&gt;
    &lt;script src=&quot;https://cdn.jsdelivr.net/npm/leaflet@1.9.3/dist/leaflet.js&quot;&gt;&lt;/script&gt;
    &lt;script src=&quot;https://code.jquery.com/jquery-3.7.1.min.js&quot;&gt;&lt;/script&gt;
    &lt;script src=&quot;https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js&quot;&gt;&lt;/script&gt;
    &lt;script src=&quot;https://cdnjs.cloudflare.com/ajax/libs/Leaflet.awesome-markers/2.0.2/leaflet.awesome-markers.js&quot;&gt;&lt;/script&gt;
    &lt;link rel=&quot;stylesheet&quot; href=&quot;https://cdn.jsdelivr.net/npm/leaflet@1.9.3/dist/leaflet.css&quot;/&gt;
    &lt;link rel=&quot;stylesheet&quot; href=&quot;https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css&quot;/&gt;
    &lt;link rel=&quot;stylesheet&quot; href=&quot;https://netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap-glyphicons.css&quot;/&gt;
    &lt;link rel=&quot;stylesheet&quot; href=&quot;https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.2.0/css/all.min.css&quot;/&gt;
    &lt;link rel=&quot;stylesheet&quot; href=&quot;https://cdnjs.cloudflare.com/ajax/libs/Leaflet.awesome-markers/2.0.2/leaflet.awesome-markers.css&quot;/&gt;
    &lt;link rel=&quot;stylesheet&quot; href=&quot;https://cdn.jsdelivr.net/gh/python-visualization/folium/folium/templates/leaflet.awesome.rotate.min.css&quot;/&gt;

            &lt;meta name=&quot;viewport&quot; content=&quot;width=device-width,
                initial-scale=1.0, maximum-scale=1.0, user-scalable=no&quot; /&gt;
            &lt;style&gt;
                #map_34d1d2e521e73e888c60d7167befa42b {
                    position: relative;
                    width: 100.0%;
                    height: 100.0%;
                    left: 0.0%;
                    top: 0.0%;
                }
                .leaflet-container { font-size: 1rem; }
            &lt;/style&gt;

            &lt;style&gt;html, body {
                width: 100%;
                height: 100%;
                margin: 0;
                padding: 0;
            }
            &lt;/style&gt;

            &lt;style&gt;#map {
                position:absolute;
                top:0;
                bottom:0;
                right:0;
                left:0;
                }
            &lt;/style&gt;

            &lt;script&gt;
                L_NO_TOUCH = false;
                L_DISABLE_3D = false;
            &lt;/script&gt;


&lt;/head&gt;
&lt;body&gt;


            &lt;div class=&quot;folium-map&quot; id=&quot;map_34d1d2e521e73e888c60d7167befa42b&quot; &gt;&lt;/div&gt;

&lt;/body&gt;
&lt;script&gt;


            var map_34d1d2e521e73e888c60d7167befa42b = L.map(
                &quot;map_34d1d2e521e73e888c60d7167befa42b&quot;,
                {
                    center: [-30.0, 25.0],
                    crs: L.CRS.EPSG3857,
                    ...{
  &quot;zoom&quot;: 5,
  &quot;zoomControl&quot;: true,
  &quot;preferCanvas&quot;: false,
}

                }
            );





            var tile_layer_b9d03e2502ff9b7b390cb84ef088762b = L.tileLayer(
                &quot;https://tile.openstreetmap.org/{z}/{x}/{y}.png&quot;,
                {
  &quot;minZoom&quot;: 0,
  &quot;maxZoom&quot;: 19,
  &quot;maxNativeZoom&quot;: 19,
  &quot;noWrap&quot;: false,
  &quot;attribution&quot;: &quot;\u0026copy; \u003ca href=\&quot;https://www.openstreetmap.org/copyright\&quot;\u003eOpenStreetMap\u003c/a\u003e contributors&quot;,
  &quot;subdomains&quot;: &quot;abc&quot;,
  &quot;detectRetina&quot;: false,
  &quot;tms&quot;: false,
  &quot;opacity&quot;: 1,
}

            );


            tile_layer_b9d03e2502ff9b7b390cb84ef088762b.addTo(map_34d1d2e521e73e888c60d7167befa42b);


            var circle_marker_467062f9c6d0a941c8efa44c74bd2ae0 = L.circleMarker(
                [-32.0, 26.0],
                {&quot;bubblingMouseEvents&quot;: true, &quot;color&quot;: &quot;red&quot;, &quot;dashArray&quot;: null, &quot;dashOffset&quot;: null, &quot;fill&quot;: true, &quot;fillColor&quot;: &quot;red&quot;, &quot;fillOpacity&quot;: 0.6, &quot;fillRule&quot;: &quot;evenodd&quot;, &quot;lineCap&quot;: &quot;round&quot;, &quot;lineJoin&quot;: &quot;round&quot;, &quot;opacity&quot;: 1.0, &quot;radius&quot;: 4.01, &quot;stroke&quot;: true, &quot;weight&quot;: 3}
            ).addTo(map_34d1d2e521e73e888c60d7167befa42b);


        var popup_619c3d606e93f0eb02d4b4f247a03ce1 = L.popup({
  &quot;maxWidth&quot;: &quot;100%&quot;,
});



                var html_a8e7576cd8927cd5179877e87a6b71e4 = $(`&lt;div id=&quot;html_a8e7576cd8927cd5179877e87a6b71e4&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Eastern Cape: 401 Diabetic Cases&lt;/div&gt;`)[0];
                popup_619c3d606e93f0eb02d4b4f247a03ce1.setContent(html_a8e7576cd8927cd5179877e87a6b71e4);



        circle_marker_467062f9c6d0a941c8efa44c74bd2ae0.bindPopup(popup_619c3d606e93f0eb02d4b4f247a03ce1)
        ;




            var circle_marker_cd9e3d10254dd3342264d3eae9be0216 = L.circleMarker(
                [-32.0, 26.0],
                {&quot;bubblingMouseEvents&quot;: true, &quot;color&quot;: &quot;blue&quot;, &quot;dashArray&quot;: null, &quot;dashOffset&quot;: null, &quot;fill&quot;: true, &quot;fillColor&quot;: &quot;blue&quot;, &quot;fillOpacity&quot;: 0.6, &quot;fillRule&quot;: &quot;evenodd&quot;, &quot;lineCap&quot;: &quot;round&quot;, &quot;lineJoin&quot;: &quot;round&quot;, &quot;opacity&quot;: 1.0, &quot;radius&quot;: 11.56, &quot;stroke&quot;: true, &quot;weight&quot;: 3}
            ).addTo(map_34d1d2e521e73e888c60d7167befa42b);


        var popup_24abba500d0588fb2182a73c2b1e9586 = L.popup({
  &quot;maxWidth&quot;: &quot;100%&quot;,
});



                var html_278b126adbf57cea1f51d6b4b6121f54 = $(`&lt;div id=&quot;html_278b126adbf57cea1f51d6b4b6121f54&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Eastern Cape: 1156 Hypertension Cases&lt;/div&gt;`)[0];
                popup_24abba500d0588fb2182a73c2b1e9586.setContent(html_278b126adbf57cea1f51d6b4b6121f54);



        circle_marker_cd9e3d10254dd3342264d3eae9be0216.bindPopup(popup_24abba500d0588fb2182a73c2b1e9586)
        ;




            var circle_marker_bb4fdbdad04f97420661a101cfa63ec9 = L.circleMarker(
                [-28.5, 26.5],
                {&quot;bubblingMouseEvents&quot;: true, &quot;color&quot;: &quot;red&quot;, &quot;dashArray&quot;: null, &quot;dashOffset&quot;: null, &quot;fill&quot;: true, &quot;fillColor&quot;: &quot;red&quot;, &quot;fillOpacity&quot;: 0.6, &quot;fillRule&quot;: &quot;evenodd&quot;, &quot;lineCap&quot;: &quot;round&quot;, &quot;lineJoin&quot;: &quot;round&quot;, &quot;opacity&quot;: 1.0, &quot;radius&quot;: 1.33, &quot;stroke&quot;: true, &quot;weight&quot;: 3}
            ).addTo(map_34d1d2e521e73e888c60d7167befa42b);


        var popup_f23c2cc4778b4fcb6ed48c8699c724d8 = L.popup({
  &quot;maxWidth&quot;: &quot;100%&quot;,
});



                var html_770eee56884cfda5697cfe6a4454850d = $(`&lt;div id=&quot;html_770eee56884cfda5697cfe6a4454850d&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Free State: 133 Diabetic Cases&lt;/div&gt;`)[0];
                popup_f23c2cc4778b4fcb6ed48c8699c724d8.setContent(html_770eee56884cfda5697cfe6a4454850d);



        circle_marker_bb4fdbdad04f97420661a101cfa63ec9.bindPopup(popup_f23c2cc4778b4fcb6ed48c8699c724d8)
        ;




            var circle_marker_8f2e7a9101ae7baf7d9e087fe5052f57 = L.circleMarker(
                [-28.5, 26.5],
                {&quot;bubblingMouseEvents&quot;: true, &quot;color&quot;: &quot;blue&quot;, &quot;dashArray&quot;: null, &quot;dashOffset&quot;: null, &quot;fill&quot;: true, &quot;fillColor&quot;: &quot;blue&quot;, &quot;fillOpacity&quot;: 0.6, &quot;fillRule&quot;: &quot;evenodd&quot;, &quot;lineCap&quot;: &quot;round&quot;, &quot;lineJoin&quot;: &quot;round&quot;, &quot;opacity&quot;: 1.0, &quot;radius&quot;: 5.02, &quot;stroke&quot;: true, &quot;weight&quot;: 3}
            ).addTo(map_34d1d2e521e73e888c60d7167befa42b);


        var popup_1020cb49e4b34c249e395748c103669c = L.popup({
  &quot;maxWidth&quot;: &quot;100%&quot;,
});



                var html_33705991069ec38f57984157418a5ba0 = $(`&lt;div id=&quot;html_33705991069ec38f57984157418a5ba0&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Free State: 502 Hypertension Cases&lt;/div&gt;`)[0];
                popup_1020cb49e4b34c249e395748c103669c.setContent(html_33705991069ec38f57984157418a5ba0);



        circle_marker_8f2e7a9101ae7baf7d9e087fe5052f57.bindPopup(popup_1020cb49e4b34c249e395748c103669c)
        ;




            var circle_marker_e6f01a13f28df2c4e231fa1fe50617be = L.circleMarker(
                [-26.0, 28.0],
                {&quot;bubblingMouseEvents&quot;: true, &quot;color&quot;: &quot;red&quot;, &quot;dashArray&quot;: null, &quot;dashOffset&quot;: null, &quot;fill&quot;: true, &quot;fillColor&quot;: &quot;red&quot;, &quot;fillOpacity&quot;: 0.6, &quot;fillRule&quot;: &quot;evenodd&quot;, &quot;lineCap&quot;: &quot;round&quot;, &quot;lineJoin&quot;: &quot;round&quot;, &quot;opacity&quot;: 1.0, &quot;radius&quot;: 4.09, &quot;stroke&quot;: true, &quot;weight&quot;: 3}
            ).addTo(map_34d1d2e521e73e888c60d7167befa42b);


        var popup_9b27f37233b49903817ca6c89eb37a6f = L.popup({
  &quot;maxWidth&quot;: &quot;100%&quot;,
});



                var html_cd2d78661882f54af2c75614070dae03 = $(`&lt;div id=&quot;html_cd2d78661882f54af2c75614070dae03&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Gauteng: 409 Diabetic Cases&lt;/div&gt;`)[0];
                popup_9b27f37233b49903817ca6c89eb37a6f.setContent(html_cd2d78661882f54af2c75614070dae03);



        circle_marker_e6f01a13f28df2c4e231fa1fe50617be.bindPopup(popup_9b27f37233b49903817ca6c89eb37a6f)
        ;




            var circle_marker_f244c918a284b2fd43ddd75db13b1951 = L.circleMarker(
                [-26.0, 28.0],
                {&quot;bubblingMouseEvents&quot;: true, &quot;color&quot;: &quot;blue&quot;, &quot;dashArray&quot;: null, &quot;dashOffset&quot;: null, &quot;fill&quot;: true, &quot;fillColor&quot;: &quot;blue&quot;, &quot;fillOpacity&quot;: 0.6, &quot;fillRule&quot;: &quot;evenodd&quot;, &quot;lineCap&quot;: &quot;round&quot;, &quot;lineJoin&quot;: &quot;round&quot;, &quot;opacity&quot;: 1.0, &quot;radius&quot;: 13.25, &quot;stroke&quot;: true, &quot;weight&quot;: 3}
            ).addTo(map_34d1d2e521e73e888c60d7167befa42b);


        var popup_feafbc50c400e92e72923f4e20837236 = L.popup({
  &quot;maxWidth&quot;: &quot;100%&quot;,
});



                var html_b772b381668815c8c3699d648c5aa7e5 = $(`&lt;div id=&quot;html_b772b381668815c8c3699d648c5aa7e5&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Gauteng: 1325 Hypertension Cases&lt;/div&gt;`)[0];
                popup_feafbc50c400e92e72923f4e20837236.setContent(html_b772b381668815c8c3699d648c5aa7e5);



        circle_marker_f244c918a284b2fd43ddd75db13b1951.bindPopup(popup_feafbc50c400e92e72923f4e20837236)
        ;




            var circle_marker_5fa88e778f709cc3c2532d16ca3fbfd8 = L.circleMarker(
                [-29.0, 31.5],
                {&quot;bubblingMouseEvents&quot;: true, &quot;color&quot;: &quot;red&quot;, &quot;dashArray&quot;: null, &quot;dashOffset&quot;: null, &quot;fill&quot;: true, &quot;fillColor&quot;: &quot;red&quot;, &quot;fillOpacity&quot;: 0.6, &quot;fillRule&quot;: &quot;evenodd&quot;, &quot;lineCap&quot;: &quot;round&quot;, &quot;lineJoin&quot;: &quot;round&quot;, &quot;opacity&quot;: 1.0, &quot;radius&quot;: 4.14, &quot;stroke&quot;: true, &quot;weight&quot;: 3}
            ).addTo(map_34d1d2e521e73e888c60d7167befa42b);


        var popup_a0ce23598898d7132c990fb2196a60fe = L.popup({
  &quot;maxWidth&quot;: &quot;100%&quot;,
});



                var html_c9a988894aa8f43641375b12b81234ab = $(`&lt;div id=&quot;html_c9a988894aa8f43641375b12b81234ab&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;KwaZulu-Natal: 414 Diabetic Cases&lt;/div&gt;`)[0];
                popup_a0ce23598898d7132c990fb2196a60fe.setContent(html_c9a988894aa8f43641375b12b81234ab);



        circle_marker_5fa88e778f709cc3c2532d16ca3fbfd8.bindPopup(popup_a0ce23598898d7132c990fb2196a60fe)
        ;




            var circle_marker_1ba6687d1fa4229553e587e44dabaae2 = L.circleMarker(
                [-29.0, 31.5],
                {&quot;bubblingMouseEvents&quot;: true, &quot;color&quot;: &quot;blue&quot;, &quot;dashArray&quot;: null, &quot;dashOffset&quot;: null, &quot;fill&quot;: true, &quot;fillColor&quot;: &quot;blue&quot;, &quot;fillOpacity&quot;: 0.6, &quot;fillRule&quot;: &quot;evenodd&quot;, &quot;lineCap&quot;: &quot;round&quot;, &quot;lineJoin&quot;: &quot;round&quot;, &quot;opacity&quot;: 1.0, &quot;radius&quot;: 9.51, &quot;stroke&quot;: true, &quot;weight&quot;: 3}
            ).addTo(map_34d1d2e521e73e888c60d7167befa42b);


        var popup_908902d8fe4e10a575297401a0e80ecc = L.popup({
  &quot;maxWidth&quot;: &quot;100%&quot;,
});



                var html_89a1bd970802258588107ed5c10e4b85 = $(`&lt;div id=&quot;html_89a1bd970802258588107ed5c10e4b85&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;KwaZulu-Natal: 951 Hypertension Cases&lt;/div&gt;`)[0];
                popup_908902d8fe4e10a575297401a0e80ecc.setContent(html_89a1bd970802258588107ed5c10e4b85);



        circle_marker_1ba6687d1fa4229553e587e44dabaae2.bindPopup(popup_908902d8fe4e10a575297401a0e80ecc)
        ;




            var circle_marker_f4cc13033f68f847032a28315d5f9c64 = L.circleMarker(
                [-23.5, 29.0],
                {&quot;bubblingMouseEvents&quot;: true, &quot;color&quot;: &quot;red&quot;, &quot;dashArray&quot;: null, &quot;dashOffset&quot;: null, &quot;fill&quot;: true, &quot;fillColor&quot;: &quot;red&quot;, &quot;fillOpacity&quot;: 0.6, &quot;fillRule&quot;: &quot;evenodd&quot;, &quot;lineCap&quot;: &quot;round&quot;, &quot;lineJoin&quot;: &quot;round&quot;, &quot;opacity&quot;: 1.0, &quot;radius&quot;: 1.23, &quot;stroke&quot;: true, &quot;weight&quot;: 3}
            ).addTo(map_34d1d2e521e73e888c60d7167befa42b);


        var popup_5e9ef66e06d2d347102209c0ecc46224 = L.popup({
  &quot;maxWidth&quot;: &quot;100%&quot;,
});



                var html_0646519c464d3bc8e58fed53ef31bd6c = $(`&lt;div id=&quot;html_0646519c464d3bc8e58fed53ef31bd6c&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Limpopo: 123 Diabetic Cases&lt;/div&gt;`)[0];
                popup_5e9ef66e06d2d347102209c0ecc46224.setContent(html_0646519c464d3bc8e58fed53ef31bd6c);



        circle_marker_f4cc13033f68f847032a28315d5f9c64.bindPopup(popup_5e9ef66e06d2d347102209c0ecc46224)
        ;




            var circle_marker_c87d8be4b4ed574741ef10e62bcc9b52 = L.circleMarker(
                [-23.5, 29.0],
                {&quot;bubblingMouseEvents&quot;: true, &quot;color&quot;: &quot;blue&quot;, &quot;dashArray&quot;: null, &quot;dashOffset&quot;: null, &quot;fill&quot;: true, &quot;fillColor&quot;: &quot;blue&quot;, &quot;fillOpacity&quot;: 0.6, &quot;fillRule&quot;: &quot;evenodd&quot;, &quot;lineCap&quot;: &quot;round&quot;, &quot;lineJoin&quot;: &quot;round&quot;, &quot;opacity&quot;: 1.0, &quot;radius&quot;: 4.81, &quot;stroke&quot;: true, &quot;weight&quot;: 3}
            ).addTo(map_34d1d2e521e73e888c60d7167befa42b);


        var popup_d041fa5f8f67b22d234f4a39382fb865 = L.popup({
  &quot;maxWidth&quot;: &quot;100%&quot;,
});



                var html_0c14ca01c9966b30e40b668e83b8f4ba = $(`&lt;div id=&quot;html_0c14ca01c9966b30e40b668e83b8f4ba&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Limpopo: 481 Hypertension Cases&lt;/div&gt;`)[0];
                popup_d041fa5f8f67b22d234f4a39382fb865.setContent(html_0c14ca01c9966b30e40b668e83b8f4ba);



        circle_marker_c87d8be4b4ed574741ef10e62bcc9b52.bindPopup(popup_d041fa5f8f67b22d234f4a39382fb865)
        ;




            var circle_marker_cdc4079da1aab620709e8c469f5865d5 = L.circleMarker(
                [-25.5, 31.0],
                {&quot;bubblingMouseEvents&quot;: true, &quot;color&quot;: &quot;red&quot;, &quot;dashArray&quot;: null, &quot;dashOffset&quot;: null, &quot;fill&quot;: true, &quot;fillColor&quot;: &quot;red&quot;, &quot;fillOpacity&quot;: 0.6, &quot;fillRule&quot;: &quot;evenodd&quot;, &quot;lineCap&quot;: &quot;round&quot;, &quot;lineJoin&quot;: &quot;round&quot;, &quot;opacity&quot;: 1.0, &quot;radius&quot;: 1.21, &quot;stroke&quot;: true, &quot;weight&quot;: 3}
            ).addTo(map_34d1d2e521e73e888c60d7167befa42b);


        var popup_32f61bfd6ab70605cea5a295193d4307 = L.popup({
  &quot;maxWidth&quot;: &quot;100%&quot;,
});



                var html_01bbea9a328eae8d4fb0dce2441cbe56 = $(`&lt;div id=&quot;html_01bbea9a328eae8d4fb0dce2441cbe56&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Mpumalanga: 121 Diabetic Cases&lt;/div&gt;`)[0];
                popup_32f61bfd6ab70605cea5a295193d4307.setContent(html_01bbea9a328eae8d4fb0dce2441cbe56);



        circle_marker_cdc4079da1aab620709e8c469f5865d5.bindPopup(popup_32f61bfd6ab70605cea5a295193d4307)
        ;




            var circle_marker_2045b0b89d4412ad79ade249016931db = L.circleMarker(
                [-25.5, 31.0],
                {&quot;bubblingMouseEvents&quot;: true, &quot;color&quot;: &quot;blue&quot;, &quot;dashArray&quot;: null, &quot;dashOffset&quot;: null, &quot;fill&quot;: true, &quot;fillColor&quot;: &quot;blue&quot;, &quot;fillOpacity&quot;: 0.6, &quot;fillRule&quot;: &quot;evenodd&quot;, &quot;lineCap&quot;: &quot;round&quot;, &quot;lineJoin&quot;: &quot;round&quot;, &quot;opacity&quot;: 1.0, &quot;radius&quot;: 4.64, &quot;stroke&quot;: true, &quot;weight&quot;: 3}
            ).addTo(map_34d1d2e521e73e888c60d7167befa42b);


        var popup_d29d5ab3bf034f6fea9231e2fcdd4ec6 = L.popup({
  &quot;maxWidth&quot;: &quot;100%&quot;,
});



                var html_582392c23c95f2b735ede4bfd106d47b = $(`&lt;div id=&quot;html_582392c23c95f2b735ede4bfd106d47b&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Mpumalanga: 464 Hypertension Cases&lt;/div&gt;`)[0];
                popup_d29d5ab3bf034f6fea9231e2fcdd4ec6.setContent(html_582392c23c95f2b735ede4bfd106d47b);



        circle_marker_2045b0b89d4412ad79ade249016931db.bindPopup(popup_d29d5ab3bf034f6fea9231e2fcdd4ec6)
        ;




            var circle_marker_d98b9d6e39138c2dba11f9384db221f3 = L.circleMarker(
                [-26.5, 25.5],
                {&quot;bubblingMouseEvents&quot;: true, &quot;color&quot;: &quot;red&quot;, &quot;dashArray&quot;: null, &quot;dashOffset&quot;: null, &quot;fill&quot;: true, &quot;fillColor&quot;: &quot;red&quot;, &quot;fillOpacity&quot;: 0.6, &quot;fillRule&quot;: &quot;evenodd&quot;, &quot;lineCap&quot;: &quot;round&quot;, &quot;lineJoin&quot;: &quot;round&quot;, &quot;opacity&quot;: 1.0, &quot;radius&quot;: 1.09, &quot;stroke&quot;: true, &quot;weight&quot;: 3}
            ).addTo(map_34d1d2e521e73e888c60d7167befa42b);


        var popup_542a34b1816425bf2fcf451935750827 = L.popup({
  &quot;maxWidth&quot;: &quot;100%&quot;,
});



                var html_d8ce9891da5c5d85db69a7ecfdc1709f = $(`&lt;div id=&quot;html_d8ce9891da5c5d85db69a7ecfdc1709f&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;North West: 109 Diabetic Cases&lt;/div&gt;`)[0];
                popup_542a34b1816425bf2fcf451935750827.setContent(html_d8ce9891da5c5d85db69a7ecfdc1709f);



        circle_marker_d98b9d6e39138c2dba11f9384db221f3.bindPopup(popup_542a34b1816425bf2fcf451935750827)
        ;




            var circle_marker_4dd7f3318f427e2bf43295f814fb1837 = L.circleMarker(
                [-26.5, 25.5],
                {&quot;bubblingMouseEvents&quot;: true, &quot;color&quot;: &quot;blue&quot;, &quot;dashArray&quot;: null, &quot;dashOffset&quot;: null, &quot;fill&quot;: true, &quot;fillColor&quot;: &quot;blue&quot;, &quot;fillOpacity&quot;: 0.6, &quot;fillRule&quot;: &quot;evenodd&quot;, &quot;lineCap&quot;: &quot;round&quot;, &quot;lineJoin&quot;: &quot;round&quot;, &quot;opacity&quot;: 1.0, &quot;radius&quot;: 5.29, &quot;stroke&quot;: true, &quot;weight&quot;: 3}
            ).addTo(map_34d1d2e521e73e888c60d7167befa42b);


        var popup_a15476d753cc387759dd7aa8e8604cf3 = L.popup({
  &quot;maxWidth&quot;: &quot;100%&quot;,
});



                var html_6be50844a03c84f5cd7d795024e8cc24 = $(`&lt;div id=&quot;html_6be50844a03c84f5cd7d795024e8cc24&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;North West: 529 Hypertension Cases&lt;/div&gt;`)[0];
                popup_a15476d753cc387759dd7aa8e8604cf3.setContent(html_6be50844a03c84f5cd7d795024e8cc24);



        circle_marker_4dd7f3318f427e2bf43295f814fb1837.bindPopup(popup_a15476d753cc387759dd7aa8e8604cf3)
        ;




            var circle_marker_784776a258a5683cf7c8df51413fdaa9 = L.circleMarker(
                [-29.5, 21.5],
                {&quot;bubblingMouseEvents&quot;: true, &quot;color&quot;: &quot;red&quot;, &quot;dashArray&quot;: null, &quot;dashOffset&quot;: null, &quot;fill&quot;: true, &quot;fillColor&quot;: &quot;red&quot;, &quot;fillOpacity&quot;: 0.6, &quot;fillRule&quot;: &quot;evenodd&quot;, &quot;lineCap&quot;: &quot;round&quot;, &quot;lineJoin&quot;: &quot;round&quot;, &quot;opacity&quot;: 1.0, &quot;radius&quot;: 0.99, &quot;stroke&quot;: true, &quot;weight&quot;: 3}
            ).addTo(map_34d1d2e521e73e888c60d7167befa42b);


        var popup_aaf366be56e455b67b701788d556fd23 = L.popup({
  &quot;maxWidth&quot;: &quot;100%&quot;,
});



                var html_2690b3fcad25728c60b2e334d021dd13 = $(`&lt;div id=&quot;html_2690b3fcad25728c60b2e334d021dd13&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Northern Cape: 99 Diabetic Cases&lt;/div&gt;`)[0];
                popup_aaf366be56e455b67b701788d556fd23.setContent(html_2690b3fcad25728c60b2e334d021dd13);



        circle_marker_784776a258a5683cf7c8df51413fdaa9.bindPopup(popup_aaf366be56e455b67b701788d556fd23)
        ;




            var circle_marker_0721c2d54e4c0201efc526eefa99e97c = L.circleMarker(
                [-29.5, 21.5],
                {&quot;bubblingMouseEvents&quot;: true, &quot;color&quot;: &quot;blue&quot;, &quot;dashArray&quot;: null, &quot;dashOffset&quot;: null, &quot;fill&quot;: true, &quot;fillColor&quot;: &quot;blue&quot;, &quot;fillOpacity&quot;: 0.6, &quot;fillRule&quot;: &quot;evenodd&quot;, &quot;lineCap&quot;: &quot;round&quot;, &quot;lineJoin&quot;: &quot;round&quot;, &quot;opacity&quot;: 1.0, &quot;radius&quot;: 4.27, &quot;stroke&quot;: true, &quot;weight&quot;: 3}
            ).addTo(map_34d1d2e521e73e888c60d7167befa42b);


        var popup_1572952b98f68cc7bd209751c1616d76 = L.popup({
  &quot;maxWidth&quot;: &quot;100%&quot;,
});



                var html_09df4080f8033bf83f1213adf63af9f5 = $(`&lt;div id=&quot;html_09df4080f8033bf83f1213adf63af9f5&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Northern Cape: 427 Hypertension Cases&lt;/div&gt;`)[0];
                popup_1572952b98f68cc7bd209751c1616d76.setContent(html_09df4080f8033bf83f1213adf63af9f5);



        circle_marker_0721c2d54e4c0201efc526eefa99e97c.bindPopup(popup_1572952b98f68cc7bd209751c1616d76)
        ;




            var circle_marker_b3fceaeebf5f9db76678a54fb8e69afb = L.circleMarker(
                [-33.0, 19.0],
                {&quot;bubblingMouseEvents&quot;: true, &quot;color&quot;: &quot;red&quot;, &quot;dashArray&quot;: null, &quot;dashOffset&quot;: null, &quot;fill&quot;: true, &quot;fillColor&quot;: &quot;red&quot;, &quot;fillOpacity&quot;: 0.6, &quot;fillRule&quot;: &quot;evenodd&quot;, &quot;lineCap&quot;: &quot;round&quot;, &quot;lineJoin&quot;: &quot;round&quot;, &quot;opacity&quot;: 1.0, &quot;radius&quot;: 3.49, &quot;stroke&quot;: true, &quot;weight&quot;: 3}
            ).addTo(map_34d1d2e521e73e888c60d7167befa42b);


        var popup_05d50f7dfc43a49e6c790c0ddac5a524 = L.popup({
  &quot;maxWidth&quot;: &quot;100%&quot;,
});



                var html_7eb53dca90789030dfe5b74d2513a00a = $(`&lt;div id=&quot;html_7eb53dca90789030dfe5b74d2513a00a&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Western Cape: 349 Diabetic Cases&lt;/div&gt;`)[0];
                popup_05d50f7dfc43a49e6c790c0ddac5a524.setContent(html_7eb53dca90789030dfe5b74d2513a00a);



        circle_marker_b3fceaeebf5f9db76678a54fb8e69afb.bindPopup(popup_05d50f7dfc43a49e6c790c0ddac5a524)
        ;




            var circle_marker_a8bc01cadf28431b3362bba618a26a37 = L.circleMarker(
                [-33.0, 19.0],
                {&quot;bubblingMouseEvents&quot;: true, &quot;color&quot;: &quot;blue&quot;, &quot;dashArray&quot;: null, &quot;dashOffset&quot;: null, &quot;fill&quot;: true, &quot;fillColor&quot;: &quot;blue&quot;, &quot;fillOpacity&quot;: 0.6, &quot;fillRule&quot;: &quot;evenodd&quot;, &quot;lineCap&quot;: &quot;round&quot;, &quot;lineJoin&quot;: &quot;round&quot;, &quot;opacity&quot;: 1.0, &quot;radius&quot;: 8.26, &quot;stroke&quot;: true, &quot;weight&quot;: 3}
            ).addTo(map_34d1d2e521e73e888c60d7167befa42b);


        var popup_d54cbd7ebe2b460f27a0584ab56d5f46 = L.popup({
  &quot;maxWidth&quot;: &quot;100%&quot;,
});



                var html_872e81ef4474e952bcb804503400be06 = $(`&lt;div id=&quot;html_872e81ef4474e952bcb804503400be06&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Western Cape: 826 Hypertension Cases&lt;/div&gt;`)[0];
                popup_d54cbd7ebe2b460f27a0584ab56d5f46.setContent(html_872e81ef4474e952bcb804503400be06);



        circle_marker_a8bc01cadf28431b3362bba618a26a37.bindPopup(popup_d54cbd7ebe2b460f27a0584ab56d5f46)
        ;



&lt;/script&gt;
&lt;/html&gt;" style="position:absolute;width:100%;height:100%;left:0;top:0;border:none !important;" allowfullscreen webkitallowfullscreen mozallowfullscreen></iframe></div></div>



# 6.4. Aggregate District_ranks #


```python
District_ranks.columns = District_ranks.columns.str.strip()
```


```python
# Melt the DataFrame to long format
df_long = District_ranks.melt(
    id_vars=['ind_dhbA', 'ind_name', 'data_period', '(blank)'],
    var_name='District',
    value_name='Value'
)

# Convert the 'Value' column to numeric
df_long['Value'] = pd.to_numeric(df_long['Value'], errors='coerce')

# Check the result
df_long.head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ind_dhbA</th>
      <th>ind_name</th>
      <th>data_period</th>
      <th>(blank)</th>
      <th>District</th>
      <th>Value</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>3_2_Diabetes management</td>
      <td>Percentage of adults overweight or obese</td>
      <td>2012</td>
      <td>4.6</td>
      <td>Ekurhuleni Metro</td>
      <td>37.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>NaN</td>
      <td>Percentage of adults overweight or obese</td>
      <td>2017</td>
      <td>4.5</td>
      <td>Ekurhuleni Metro</td>
      <td>27.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>NaN</td>
      <td>Percentage of adults overweight or obese</td>
      <td>2018</td>
      <td>1</td>
      <td>Ekurhuleni Metro</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>NaN</td>
      <td>Percentage of adults overweight or obese</td>
      <td>2019</td>
      <td>1</td>
      <td>Ekurhuleni Metro</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>NaN</td>
      <td>Percentage of adults overweight or obese</td>
      <td>2020</td>
      <td>1</td>
      <td>Ekurhuleni Metro</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Filter for overweight/obese percentages and diabetes prevalence
overweight_df = df_long[df_long['ind_name'].str.contains('overweight or obese', na=False)]
diabetes_df = df_long[df_long['ind_name'].str.contains('Diabetes prevalence', na=False)]

```


```python
# Pivot overweight and diabetes data to wide format
overweight_pivot = overweight_df.pivot_table(
    index='District', values='Value', aggfunc='mean'
).reset_index()
overweight_pivot.rename(columns={'Value': 'Overweight_Percentage'}, inplace=True)

diabetes_pivot = diabetes_df.pivot_table(
    index='District', values='Value', aggfunc='mean'
).reset_index()
diabetes_pivot.rename(columns={'Value': 'Diabetes_Prevalence'}, inplace=True)

# Merge into one dataframe
dis_comparison = pd.merge(overweight_pivot, diabetes_pivot, on='District', how='inner')

# Check merged result
print(dis_comparison.head(60))

```

                   District  Overweight_Percentage  Diabetes_Prevalence
    0              Amathole              43.200000            34.615385
    1    Buffalo City Metro              32.600000            43.192308
    2       Cape Town Metro              24.600000            34.057692
    3        Cape Winelands              26.600000            19.230769
    4             Capricorn              31.400000            30.923077
    5       City of Tshwane              31.800000            38.538462
    6          Eastern Cape              22.600000            42.846154
    7                  Eden              15.000000            31.230769
    8             Ehlanzeni              38.000000            28.576923
    9      Ekurhuleni Metro              27.400000            29.826923
    10        Frances Baard              45.200000            22.730769
    11            Joe Gqabi              44.800000            47.730769
    12   Johannesburg Metro              30.533333            28.910256
    13  John Taolo Gaetsewe               3.800000            11.500000
    14       Mangaung Metro              30.800000            14.961538
    15               Mopani              23.900000            20.903846
    16              Namakwa              38.400000            41.500000
    17             Overberg              47.800000            27.230769
    18       Pixley Ka Seme              28.200000            40.653846
    19           Sekhukhune              26.200000            12.615385
    20        Tshwane Metro              22.560000            26.041026
    21                  Ugu              18.800000             3.769231
    22               Vhembe              32.000000            24.980769
    23            Waterberg              13.200000            10.564103
    24            West Rand              42.600000            35.923077
    25            ZF Mgcawu               8.400000             7.269231
    


```python
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import pearsonr

# Drop rows with NaNs
dis_clean = dis_comparison.dropna(subset=['Overweight_Percentage', 'Diabetes_Prevalence'])

# Compute correlation
corr, p_value = pearsonr(dis_clean['Overweight_Percentage'], dis_clean['Diabetes_Prevalence'])
print(f"Pearson correlation: {corr:.2f} (p-value={p_value:.3f})")

# Scatter plot with trend line
plt.figure(figsize=(10,6))
sns.regplot(
    data=dis_clean,
    x='Overweight_Percentage',
    y='Diabetes_Prevalence',
    scatter=True,
    fit_reg=True,
    ci=None,
    color='teal'
)

# Annotate districts
for i, row in dis_clean.iterrows():
    plt.text(
        row['Overweight_Percentage'] + 0.3,
        row['Diabetes_Prevalence'] + 0.3,
        row['District'],
        fontsize=9
    )

plt.title('Overweight vs Diabetes Prevalence per District')
plt.xlabel('Average % of Adults Overweight or Obese')
plt.ylabel('Average Diabetes Prevalence (%)')
plt.grid(alpha=0.3)
plt.text(
    0.95*dis_clean['Overweight_Percentage'].max(),
    0.95*dis_clean['Diabetes_Prevalence'].max(),
    f'Correlation: {corr:.2f}',
    fontsize=12,
    color='red'
)
plt.show()

```

    Pearson correlation: 0.56 (p-value=0.003)
    


    
![png](output_125_1.png)
    


| Diabetes Prevalence Distribution per District |
|-----------------------------------------------|


```python
import seaborn as sns
import matplotlib.pyplot as plt

# Filter for diabetes prevalence only
diabetes_data = df_long[df_long['ind_name'] == 'Diabetes prevalence'].dropna(subset=['Value'])

plt.figure(figsize=(12,6))
sns.boxplot(
    data=diabetes_data,
    x='District',
    y='Value',
    palette='Set2'
)

plt.xticks(rotation=45, ha='right')
plt.title('Diabetes Prevalence Distribution per District')
plt.ylabel('Diabetes Prevalence (%)')
plt.xlabel('District')
plt.show()

```

    C:\Users\cash\AppData\Local\Temp\ipykernel_2824\894764620.py:8: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `x` variable to `hue` and set `legend=False` for the same effect.
    
      sns.boxplot(
    


    
![png](output_127_1.png)
    


| Overweight Percentage Distribution per District |
|-----------------------------------------------|


```python
overweight_data = df_long[df_long['ind_name'] == 'Percentage of adults overweight or obese'].dropna(subset=['Value'])

plt.figure(figsize=(12,6))
sns.boxplot(
    data=overweight_data,
    x='District',
    y='Value',
    palette='Set3'
)

plt.xticks(rotation=45, ha='right')
plt.title('Overweight Percentage Distribution per District')
plt.ylabel('Overweight / Obese (%)')
plt.xlabel('District')
plt.show()

```

    C:\Users\cash\AppData\Local\Temp\ipykernel_2824\3560977880.py:4: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `x` variable to `hue` and set `legend=False` for the same effect.
    
      sns.boxplot(
    


    
![png](output_129_1.png)
    


# 6.5. Data Vitualization of District_ranks #

| Overweight/Obesity vs Diabetes Prevalence by District |
|-------------------------------------------------------|


```python
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Load your dataset (replace with your actual CSV file)
# df = pd.read_csv("your_data.csv")

# Example dataset structure
data = {
    'District': [
        'Ekurhuleni Metro', 'Johannesburg Metro', 'Tshwane Metro', 'Cape Town Metro',
        'Nelson Mandela Bay Metro', 'eThekwini Metro', 'Buffalo City Metro', 'Mangaung Metro',
        'Overberg', 'Garden Route'
    ] * 2,  # repeated for two indicators
    'ind_name': [
        'Percentage of adults overweight or obese']*10 + ['Diabetes prevalence']*10,
    'Value': [37, 35, 33, 31, 34, 36, 32, 30, 28, 29, 12, 11, 13, 10, 14, 15, 12, 11, 9, 10]
}

df_long = pd.DataFrame(data)

# Drop missing values if any
df_long = df_long.dropna(subset=['Value'])

# Optional: shorten indicator names for clarity
df_long['Indicator'] = df_long['ind_name'].replace({
    'Percentage of adults overweight or obese': 'Overweight/Obese',
    'Diabetes prevalence': 'Diabetes'
})

# Ensure all districts are included and ordered
district_order = df_long['District'].unique()
df_long['District'] = pd.Categorical(df_long['District'], categories=district_order, ordered=True)

# Plot grouped bar chart
plt.figure(figsize=(14,6))
sns.barplot(data=df_long, x='District', y='Value', hue='Indicator')
plt.xticks(rotation=45, ha='right')
plt.ylabel('Percentage (%)')
plt.title('Overweight/Obesity vs Diabetes Prevalence by District')
plt.legend(title='')
plt.tight_layout()
plt.show()

```


    
![png](output_132_0.png)
    



```python
import pandas as pd
import matplotlib.pyplot as plt

# Sample dataset
data = {
    'District': [
        'Ekurhuleni Metro', 'Johannesburg Metro', 'Tshwane Metro', 'Cape Town Metro',
        'Nelson Mandela Bay Metro', 'eThekwini Metro', 'Buffalo City Metro', 'Mangaung Metro',
        'Overberg', 'Garden Route'
    ],
    'Overweight_Obese': [37, 35, 33, 31, 34, 36, 32, 30, 28, 29],
    'Diabetes_Prevalence': [12, 11, 13, 10, 14, 15, 12, 11, 9, 10]
}

df = pd.DataFrame(data)

# Pie chart for Overweight/Obese
plt.figure(figsize=(8,8))
plt.pie(df['Overweight_Obese'], labels=df['District'], autopct='%1.1f%%', startangle=140)
plt.title('Distribution of Overweight/Obese Adults by District')
plt.tight_layout()
plt.show()

# Pie chart for Diabetes Prevalence
plt.figure(figsize=(8,8))
plt.pie(df['Diabetes_Prevalence'], labels=df['District'], autopct='%1.1f%%', startangle=140)
plt.title('Distribution of Diabetes Prevalence by District')
plt.tight_layout()
plt.show()

```


    
![png](output_133_0.png)
    



    
![png](output_133_1.png)
    


# 6.6. Male_Female_Total_vs_Provinces_Total_Expenditure #


```python
Male_Female_Total_vs_Provinces_Total_Expenditure.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Category</th>
      <th>Male</th>
      <th>Female</th>
      <th>Total_by_Gender</th>
      <th>Total_by_Province</th>
      <th>Province</th>
      <th>Value</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Alcohol production services</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>Western Cape</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Alcoholic beverages, tobacco and narcotics</td>
      <td>1.7</td>
      <td>1.0</td>
      <td>1.4</td>
      <td>1.4</td>
      <td>Western Cape</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Beer</td>
      <td>1.4</td>
      <td>1.3</td>
      <td>0.5</td>
      <td>0.5</td>
      <td>Western Cape</td>
      <td>0.3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Cereal and cereal products</td>
      <td>10.9</td>
      <td>10.1</td>
      <td>3.9</td>
      <td>3.9</td>
      <td>Western Cape</td>
      <td>2.3</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Cocoa drinks</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>Western Cape</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Group by Province and Category
df_grouped_prov = Male_Female_Total_vs_Provinces_Total_Expenditure.groupby(['Province','Category'])['Value'].sum().reset_index()

df_grouped_prov.head(5)

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Province</th>
      <th>Category</th>
      <th>Value</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Eastern Cape</td>
      <td>Alcohol production services</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Eastern Cape</td>
      <td>Alcoholic beverages, tobacco and narcotics</td>
      <td>1.4</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Eastern Cape</td>
      <td>Beer</td>
      <td>0.4</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Eastern Cape</td>
      <td>Cereal and cereal products</td>
      <td>5.4</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Eastern Cape</td>
      <td>Cocoa drinks</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
import seaborn as sns

plt.figure(figsize=(14,6))
sns.barplot(data= df_grouped_prov, x='Category', y='Value', hue='Province')
plt.xticks(rotation=90)
plt.title('Value per Category by Province')
plt.ylabel('Value')
plt.tight_layout()
plt.show()

```

    C:\Users\cash\AppData\Local\Temp\ipykernel_2824\562868793.py:8: UserWarning: Tight layout not applied. The bottom and top margins cannot be made large enough to accommodate all Axes decorations.
      plt.tight_layout()
    


    
![png](output_137_1.png)
    



```python
# Aggregate repeating categories
import pandas as pd

# Group by Category and sum Value
df_grouped = df_grouped_prov.groupby('Category')['Value'].sum().reset_index()

# Sort descending by Value
df_grouped = df_grouped.sort_values(by='Value', ascending=False)

print(df_grouped.head(10))  # Top 10 most important categories

```

                                                 Category  Value
    7                    Food and non-alcoholic beverages  165.5
    10  Live animals, meat and other parts of slaughte...   45.0
    3                          Cereal and cereal products   39.7
    23  Vegetables, tubers, plantains, cooking bananas...   15.7
    11                Milk, other dairy products and eggs   15.0
    1          Alcoholic beverages, tobacco and narcotics   13.9
    16     Ready-made food and other food products n.e.c.   12.9
    20                  Sugar, confectionery and desserts    8.8
    13                                      Oils and fats    7.7
    18                                        Soft drinks    5.7
    


```python
# Highlight the top categories in a histogram
# Select top N categories (e.g., top 10)
top_n = 10
df_top = df_grouped.head(top_n)

plt.figure(figsize=(10,6))
plt.bar(df_top['Category'], df_top['Value'], color='orange')
plt.xticks(rotation=45, ha='right')
plt.ylabel('Value')
plt.title(f'Top {top_n} Most Important Categories')
plt.tight_layout()
plt.show()

```


    
![png](output_139_0.png)
    



```python
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Assuming your DataFrame is df
plt.figure(figsize=(10,8))

sns.scatterplot(data=Male_Female_Total_vs_Provinces_Total_Expenditure, x='Male', y='Female', hue='Category', s=100)
plt.xlabel('Male Value')
plt.ylabel('Female Value')
plt.title('Comparison of Male vs Female Values per Category')
plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
plt.tight_layout()
plt.show()

```


    
![png](output_140_0.png)
    


# 7. Model Development #

## 7.1. Aggregating tables / datasets ##

### 7.1.1. Aggregate features per province ###


```python

# Aggregate Male + Female per province from df_grouped_prov
df_exp_agg = df_grouped_prov.groupby('Province')['Value'].sum().reset_index()
df_exp_agg.rename(columns={'Value':'Total_Expenditure'}, inplace=True)

# include Male/Female separately 
df_mf_agg = Male_Female_Total_vs_Provinces_Total_Expenditure.groupby('Province')[['Male','Female']].sum().reset_index()

```


```python
# Merge summary with expenditure data
df_model = summary.merge(df_exp_agg, left_on='prov_x', right_on='Province', how='left')
df_model = df_model.merge(df_mf_agg, on='Province', how='left')

# Drop duplicate column if any
df_model.rename(columns={'prov_x':'Province'}, inplace=True)

df_model.head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Province</th>
      <th>Population</th>
      <th>Avg_Income</th>
      <th>Diabetic_Cases</th>
      <th>Hypertension_Cases</th>
      <th>Diabetes_%</th>
      <th>Hypertension_%</th>
      <th>Province</th>
      <th>Total_Expenditure</th>
      <th>Male</th>
      <th>Female</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Eastern Cape</td>
      <td>9677</td>
      <td>9224.617687</td>
      <td>401</td>
      <td>1156</td>
      <td>4.14</td>
      <td>11.95</td>
      <td>Eastern Cape</td>
      <td>43.0</td>
      <td>51.7</td>
      <td>54.2</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Free State</td>
      <td>4192</td>
      <td>9537.846934</td>
      <td>133</td>
      <td>502</td>
      <td>3.17</td>
      <td>11.98</td>
      <td>Free State</td>
      <td>41.6</td>
      <td>51.7</td>
      <td>54.2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Gauteng</td>
      <td>16443</td>
      <td>15950.324468</td>
      <td>409</td>
      <td>1325</td>
      <td>2.49</td>
      <td>8.06</td>
      <td>Gauteng</td>
      <td>29.8</td>
      <td>51.7</td>
      <td>54.2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>KwaZulu-Natal</td>
      <td>13162</td>
      <td>12345.190583</td>
      <td>414</td>
      <td>951</td>
      <td>3.15</td>
      <td>7.23</td>
      <td>KwaZulu-Natal</td>
      <td>41.7</td>
      <td>51.7</td>
      <td>54.2</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Limpopo</td>
      <td>8265</td>
      <td>10094.563032</td>
      <td>123</td>
      <td>481</td>
      <td>1.49</td>
      <td>5.82</td>
      <td>Limpopo</td>
      <td>45.5</td>
      <td>51.7</td>
      <td>54.2</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Aggregate district-level overweight data per province (mean or last available year)
df_overweight = df_long.groupby('District')['Value'].mean().reset_index()

```

    C:\Users\cash\AppData\Local\Temp\ipykernel_2824\833422427.py:2: FutureWarning: The default of observed=False is deprecated and will be changed to True in a future version of pandas. Pass observed=False to retain current behavior or observed=True to adopt the future default and silence this warning.
      df_overweight = df_long.groupby('District')['Value'].mean().reset_index()
    


```python
districts = df_long['District'].unique()
```


```python
district_list = districts.tolist()
print(district_list)
```

    ['Ekurhuleni Metro', 'Johannesburg Metro', 'Tshwane Metro', 'Cape Town Metro', 'Nelson Mandela Bay Metro', 'eThekwini Metro', 'Buffalo City Metro', 'Mangaung Metro', 'Overberg', 'Garden Route']
    


```python
district_to_province = {
    'Ekurhuleni Metro': 'Gauteng',
    'Johannesburg Metro': 'Gauteng',
    'Tshwane Metro': 'Gauteng',
    'Cape Town Metro': 'Western Cape',
    'Nelson Mandela Bay Metro': 'Eastern Cape',
    'eThekwini Metro': 'KwaZulu-Natal',
    'Buffalo City Metro': 'Eastern Cape',
    'Mangaung Metro': 'Free State',
    'Overberg': 'Western Cape',
    'Garden Route': 'Western Cape'
}
# Map Province to each district in df_long
df_long['Province'] = df_long['District'].map(district_to_province)

```


```python
# Aggregate overweight/obesity per province
df_overweight = df_long.groupby('Province')['Value'].mean().reset_index()
df_overweight.rename(columns={'Value':'Overweight_Percentage'}, inplace=True)

```


```python
# If df_model has duplicate Province columns, drop or rename the extra one
df_model = df_model.loc[:,~df_model.columns.duplicated()]

```


```python
df_model = df_model.merge(df_overweight, on='Province', how='left')

```


```python
df_model.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Province</th>
      <th>Population</th>
      <th>Avg_Income</th>
      <th>Diabetic_Cases</th>
      <th>Hypertension_Cases</th>
      <th>Diabetes_%</th>
      <th>Hypertension_%</th>
      <th>Total_Expenditure</th>
      <th>Male</th>
      <th>Female</th>
      <th>Overweight_Percentage</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Eastern Cape</td>
      <td>9677</td>
      <td>9224.617687</td>
      <td>401</td>
      <td>1156</td>
      <td>4.14</td>
      <td>11.95</td>
      <td>43.0</td>
      <td>51.7</td>
      <td>54.2</td>
      <td>23.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Free State</td>
      <td>4192</td>
      <td>9537.846934</td>
      <td>133</td>
      <td>502</td>
      <td>3.17</td>
      <td>11.98</td>
      <td>41.6</td>
      <td>51.7</td>
      <td>54.2</td>
      <td>20.5</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Gauteng</td>
      <td>16443</td>
      <td>15950.324468</td>
      <td>409</td>
      <td>1325</td>
      <td>2.49</td>
      <td>8.06</td>
      <td>29.8</td>
      <td>51.7</td>
      <td>54.2</td>
      <td>23.5</td>
    </tr>
    <tr>
      <th>3</th>
      <td>KwaZulu-Natal</td>
      <td>13162</td>
      <td>12345.190583</td>
      <td>414</td>
      <td>951</td>
      <td>3.15</td>
      <td>7.23</td>
      <td>41.7</td>
      <td>51.7</td>
      <td>54.2</td>
      <td>25.5</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Limpopo</td>
      <td>8265</td>
      <td>10094.563032</td>
      <td>123</td>
      <td>481</td>
      <td>1.49</td>
      <td>5.82</td>
      <td>45.5</td>
      <td>51.7</td>
      <td>54.2</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Mpumalanga</td>
      <td>5817</td>
      <td>9497.779465</td>
      <td>121</td>
      <td>464</td>
      <td>2.08</td>
      <td>7.98</td>
      <td>39.3</td>
      <td>51.7</td>
      <td>54.2</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>6</th>
      <td>North West</td>
      <td>4285</td>
      <td>9076.246056</td>
      <td>109</td>
      <td>529</td>
      <td>2.54</td>
      <td>12.35</td>
      <td>45.2</td>
      <td>51.7</td>
      <td>54.2</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Northern Cape</td>
      <td>3160</td>
      <td>11414.289726</td>
      <td>99</td>
      <td>427</td>
      <td>3.13</td>
      <td>13.51</td>
      <td>43.3</td>
      <td>51.7</td>
      <td>54.2</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Western Cape</td>
      <td>6173</td>
      <td>21596.026835</td>
      <td>349</td>
      <td>826</td>
      <td>5.65</td>
      <td>13.38</td>
      <td>28.7</td>
      <td>51.7</td>
      <td>54.2</td>
      <td>19.5</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Filter for Diabetes prevalence
df_diabetes = df_long[df_long['ind_name'] == 'Diabetes prevalence']

```


```python
# Aggregate to Province
df_diabetes_prov = df_diabetes.groupby('Province')['Value'].mean().reset_index()
df_diabetes_prov.rename(columns={'Value':'Diabetes_Prevalence'}, inplace=True)

```


```python
# Remove duplicate columns if any
df_model = df_model.loc[:, ~df_model.columns.duplicated()]

# Merge main model table
df_model = df_model.merge(df_diabetes_prov, on='Province', how='left')

```


```python
df_model.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Province</th>
      <th>Population</th>
      <th>Avg_Income</th>
      <th>Diabetic_Cases</th>
      <th>Hypertension_Cases</th>
      <th>Diabetes_%</th>
      <th>Hypertension_%</th>
      <th>Total_Expenditure</th>
      <th>Male</th>
      <th>Female</th>
      <th>Overweight_Percentage</th>
      <th>Diabetes_Prevalence</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Eastern Cape</td>
      <td>9677</td>
      <td>9224.617687</td>
      <td>401</td>
      <td>1156</td>
      <td>4.14</td>
      <td>11.95</td>
      <td>43.0</td>
      <td>51.7</td>
      <td>54.2</td>
      <td>23.0</td>
      <td>13.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Free State</td>
      <td>4192</td>
      <td>9537.846934</td>
      <td>133</td>
      <td>502</td>
      <td>3.17</td>
      <td>11.98</td>
      <td>41.6</td>
      <td>51.7</td>
      <td>54.2</td>
      <td>20.5</td>
      <td>11.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Gauteng</td>
      <td>16443</td>
      <td>15950.324468</td>
      <td>409</td>
      <td>1325</td>
      <td>2.49</td>
      <td>8.06</td>
      <td>29.8</td>
      <td>51.7</td>
      <td>54.2</td>
      <td>23.5</td>
      <td>12.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>KwaZulu-Natal</td>
      <td>13162</td>
      <td>12345.190583</td>
      <td>414</td>
      <td>951</td>
      <td>3.15</td>
      <td>7.23</td>
      <td>41.7</td>
      <td>51.7</td>
      <td>54.2</td>
      <td>25.5</td>
      <td>15.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Limpopo</td>
      <td>8265</td>
      <td>10094.563032</td>
      <td>123</td>
      <td>481</td>
      <td>1.49</td>
      <td>5.82</td>
      <td>45.5</td>
      <td>51.7</td>
      <td>54.2</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>



## 7.1.2. merge df_grouped_prov with df_model but only for categories that may influence diabetes, such as sugary foods, drinks, processed foods, and alcohol. ##


```python
# Define categories influencing diabetes
diabetes_related = [
    'Sugar, confectionery and desserts',
    'Ready-made food and other food products n.e.c.',
    'Soft drinks',
    'Other non-alcoholic beverages',
    'Fruit and vegetable juices',
    'Alcoholic beverages, tobacco and narcotics',
    'Beer',
    'Wine',
    'Spirits and liquors',
    'Oils and fats'
]

df_diabetes_related = df_grouped_prov[df_grouped_prov['Category'].isin(diabetes_related)]

```


```python
df_pivot = df_diabetes_related.pivot_table(
    index='Province',
    columns='Category',
    values='Value',
    fill_value=0
).reset_index()

```


```python
df_merged = df_model.merge(df_pivot, on='Province', how='left')

```


```python
df_merged.head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Province</th>
      <th>Population</th>
      <th>Avg_Income</th>
      <th>Diabetic_Cases</th>
      <th>Hypertension_Cases</th>
      <th>Diabetes_%</th>
      <th>Hypertension_%</th>
      <th>Total_Expenditure</th>
      <th>Male</th>
      <th>Female</th>
      <th>...</th>
      <th>Alcoholic beverages, tobacco and narcotics</th>
      <th>Beer</th>
      <th>Fruit and vegetable juices</th>
      <th>Oils and fats</th>
      <th>Other non-alcoholic beverages</th>
      <th>Ready-made food and other food products n.e.c.</th>
      <th>Soft drinks</th>
      <th>Spirits and liquors</th>
      <th>Sugar, confectionery and desserts</th>
      <th>Wine</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Eastern Cape</td>
      <td>9677</td>
      <td>9224.617687</td>
      <td>401</td>
      <td>1156</td>
      <td>4.14</td>
      <td>11.95</td>
      <td>43.0</td>
      <td>51.7</td>
      <td>54.2</td>
      <td>...</td>
      <td>1.4</td>
      <td>0.4</td>
      <td>0.2</td>
      <td>1.1</td>
      <td>0.0</td>
      <td>1.9</td>
      <td>0.4</td>
      <td>0.4</td>
      <td>1.3</td>
      <td>0.3</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Free State</td>
      <td>4192</td>
      <td>9537.846934</td>
      <td>133</td>
      <td>502</td>
      <td>3.17</td>
      <td>11.98</td>
      <td>41.6</td>
      <td>51.7</td>
      <td>54.2</td>
      <td>...</td>
      <td>2.1</td>
      <td>0.9</td>
      <td>0.2</td>
      <td>0.8</td>
      <td>0.0</td>
      <td>1.9</td>
      <td>0.6</td>
      <td>0.1</td>
      <td>0.9</td>
      <td>0.3</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Gauteng</td>
      <td>16443</td>
      <td>15950.324468</td>
      <td>409</td>
      <td>1325</td>
      <td>2.49</td>
      <td>8.06</td>
      <td>29.8</td>
      <td>51.7</td>
      <td>54.2</td>
      <td>...</td>
      <td>1.5</td>
      <td>0.6</td>
      <td>0.2</td>
      <td>0.6</td>
      <td>0.1</td>
      <td>0.8</td>
      <td>0.5</td>
      <td>0.2</td>
      <td>0.6</td>
      <td>0.3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>KwaZulu-Natal</td>
      <td>13162</td>
      <td>12345.190583</td>
      <td>414</td>
      <td>951</td>
      <td>3.15</td>
      <td>7.23</td>
      <td>41.7</td>
      <td>51.7</td>
      <td>54.2</td>
      <td>...</td>
      <td>1.3</td>
      <td>0.5</td>
      <td>0.3</td>
      <td>1.2</td>
      <td>0.1</td>
      <td>1.2</td>
      <td>0.5</td>
      <td>0.3</td>
      <td>1.0</td>
      <td>0.3</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Limpopo</td>
      <td>8265</td>
      <td>10094.563032</td>
      <td>123</td>
      <td>481</td>
      <td>1.49</td>
      <td>5.82</td>
      <td>45.5</td>
      <td>51.7</td>
      <td>54.2</td>
      <td>...</td>
      <td>1.2</td>
      <td>0.6</td>
      <td>0.3</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>0.1</td>
      <td>1.0</td>
      <td>0.1</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 22 columns</p>
</div>




```python

```

## 7.1.3. Data wrangling for model table ##


```python
df_merged.columns
```




    Index(['Province', 'Population', 'Avg_Income', 'Diabetic_Cases',
           'Hypertension_Cases', 'Diabetes_%', 'Hypertension_%',
           'Total_Expenditure', 'Male', 'Female', 'Overweight_Percentage',
           'Diabetes_Prevalence', 'Alcoholic beverages, tobacco and narcotics',
           'Beer', 'Fruit and vegetable juices', 'Oils and fats',
           'Other non-alcoholic beverages',
           'Ready-made food and other food products n.e.c.', 'Soft drinks',
           'Spirits and liquors', 'Sugar, confectionery and desserts', 'Wine'],
          dtype='object')




```python
df_merged.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 9 entries, 0 to 8
    Data columns (total 22 columns):
     #   Column                                          Non-Null Count  Dtype  
    ---  ------                                          --------------  -----  
     0   Province                                        9 non-null      object 
     1   Population                                      9 non-null      int64  
     2   Avg_Income                                      9 non-null      float64
     3   Diabetic_Cases                                  9 non-null      int64  
     4   Hypertension_Cases                              9 non-null      int64  
     5   Diabetes_%                                      9 non-null      float64
     6   Hypertension_%                                  9 non-null      float64
     7   Total_Expenditure                               9 non-null      float64
     8   Male                                            9 non-null      float64
     9   Female                                          9 non-null      float64
     10  Overweight_Percentage                           5 non-null      float64
     11  Diabetes_Prevalence                             5 non-null      float64
     12  Alcoholic beverages, tobacco and narcotics      9 non-null      float64
     13  Beer                                            9 non-null      float64
     14  Fruit and vegetable juices                      9 non-null      float64
     15  Oils and fats                                   9 non-null      float64
     16  Other non-alcoholic beverages                   9 non-null      float64
     17  Ready-made food and other food products n.e.c.  9 non-null      float64
     18  Soft drinks                                     9 non-null      float64
     19  Spirits and liquors                             9 non-null      float64
     20  Sugar, confectionery and desserts               9 non-null      float64
     21  Wine                                            9 non-null      float64
    dtypes: float64(18), int64(3), object(1)
    memory usage: 1.7+ KB
    


```python
df_merged.describe()


```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Population</th>
      <th>Avg_Income</th>
      <th>Diabetic_Cases</th>
      <th>Hypertension_Cases</th>
      <th>Diabetes_%</th>
      <th>Hypertension_%</th>
      <th>Total_Expenditure</th>
      <th>Male</th>
      <th>Female</th>
      <th>Overweight_Percentage</th>
      <th>...</th>
      <th>Alcoholic beverages, tobacco and narcotics</th>
      <th>Beer</th>
      <th>Fruit and vegetable juices</th>
      <th>Oils and fats</th>
      <th>Other non-alcoholic beverages</th>
      <th>Ready-made food and other food products n.e.c.</th>
      <th>Soft drinks</th>
      <th>Spirits and liquors</th>
      <th>Sugar, confectionery and desserts</th>
      <th>Wine</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>9.000000</td>
      <td>9.000000</td>
      <td>9.000000</td>
      <td>9.000000</td>
      <td>9.000000</td>
      <td>9.000000</td>
      <td>9.000000</td>
      <td>9.0</td>
      <td>9.000000e+00</td>
      <td>5.000000</td>
      <td>...</td>
      <td>9.000000</td>
      <td>9.000000</td>
      <td>9.000000</td>
      <td>9.000000</td>
      <td>9.000000</td>
      <td>9.000000</td>
      <td>9.000000</td>
      <td>9.000000</td>
      <td>9.000000</td>
      <td>9.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>7908.222222</td>
      <td>12081.876087</td>
      <td>239.777778</td>
      <td>740.111111</td>
      <td>3.093333</td>
      <td>10.251111</td>
      <td>39.788889</td>
      <td>51.7</td>
      <td>5.420000e+01</td>
      <td>22.400000</td>
      <td>...</td>
      <td>1.544444</td>
      <td>0.611111</td>
      <td>0.233333</td>
      <td>0.855556</td>
      <td>0.055556</td>
      <td>1.433333</td>
      <td>0.633333</td>
      <td>0.233333</td>
      <td>0.977778</td>
      <td>0.266667</td>
    </tr>
    <tr>
      <th>std</th>
      <td>4480.071785</td>
      <td>4187.716468</td>
      <td>147.045722</td>
      <td>337.192247</td>
      <td>1.220154</td>
      <td>2.945583</td>
      <td>6.269459</td>
      <td>0.0</td>
      <td>7.536444e-15</td>
      <td>2.408319</td>
      <td>...</td>
      <td>0.421637</td>
      <td>0.214735</td>
      <td>0.050000</td>
      <td>0.235112</td>
      <td>0.052705</td>
      <td>0.572276</td>
      <td>0.217945</td>
      <td>0.111803</td>
      <td>0.227913</td>
      <td>0.086603</td>
    </tr>
    <tr>
      <th>min</th>
      <td>3160.000000</td>
      <td>9076.246056</td>
      <td>99.000000</td>
      <td>427.000000</td>
      <td>1.490000</td>
      <td>5.820000</td>
      <td>28.700000</td>
      <td>51.7</td>
      <td>5.420000e+01</td>
      <td>19.500000</td>
      <td>...</td>
      <td>1.000000</td>
      <td>0.300000</td>
      <td>0.200000</td>
      <td>0.500000</td>
      <td>0.000000</td>
      <td>0.800000</td>
      <td>0.400000</td>
      <td>0.100000</td>
      <td>0.600000</td>
      <td>0.100000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>4285.000000</td>
      <td>9497.779465</td>
      <td>121.000000</td>
      <td>481.000000</td>
      <td>2.490000</td>
      <td>7.980000</td>
      <td>39.300000</td>
      <td>51.7</td>
      <td>5.420000e+01</td>
      <td>20.500000</td>
      <td>...</td>
      <td>1.300000</td>
      <td>0.500000</td>
      <td>0.200000</td>
      <td>0.700000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.500000</td>
      <td>0.200000</td>
      <td>0.800000</td>
      <td>0.200000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>6173.000000</td>
      <td>10094.563032</td>
      <td>133.000000</td>
      <td>529.000000</td>
      <td>3.130000</td>
      <td>11.950000</td>
      <td>41.700000</td>
      <td>51.7</td>
      <td>5.420000e+01</td>
      <td>23.000000</td>
      <td>...</td>
      <td>1.400000</td>
      <td>0.600000</td>
      <td>0.200000</td>
      <td>0.800000</td>
      <td>0.100000</td>
      <td>1.200000</td>
      <td>0.600000</td>
      <td>0.200000</td>
      <td>1.000000</td>
      <td>0.300000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>9677.000000</td>
      <td>12345.190583</td>
      <td>401.000000</td>
      <td>951.000000</td>
      <td>3.170000</td>
      <td>12.350000</td>
      <td>43.300000</td>
      <td>51.7</td>
      <td>5.420000e+01</td>
      <td>23.500000</td>
      <td>...</td>
      <td>1.900000</td>
      <td>0.800000</td>
      <td>0.300000</td>
      <td>1.000000</td>
      <td>0.100000</td>
      <td>1.900000</td>
      <td>0.800000</td>
      <td>0.300000</td>
      <td>1.200000</td>
      <td>0.300000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>16443.000000</td>
      <td>21596.026835</td>
      <td>414.000000</td>
      <td>1325.000000</td>
      <td>5.650000</td>
      <td>13.510000</td>
      <td>45.500000</td>
      <td>51.7</td>
      <td>5.420000e+01</td>
      <td>25.500000</td>
      <td>...</td>
      <td>2.200000</td>
      <td>0.900000</td>
      <td>0.300000</td>
      <td>1.200000</td>
      <td>0.100000</td>
      <td>2.500000</td>
      <td>1.000000</td>
      <td>0.400000</td>
      <td>1.300000</td>
      <td>0.400000</td>
    </tr>
  </tbody>
</table>
<p>8 rows × 21 columns</p>
</div>




```python
df_merged.shape
```




    (9, 22)




```python
df_merged.corr
```




    <bound method DataFrame.corr of         Province  Population    Avg_Income  Diabetic_Cases  \
    0   Eastern Cape        9677   9224.617687             401   
    1     Free State        4192   9537.846934             133   
    2        Gauteng       16443  15950.324468             409   
    3  KwaZulu-Natal       13162  12345.190583             414   
    4        Limpopo        8265  10094.563032             123   
    5     Mpumalanga        5817   9497.779465             121   
    6     North West        4285   9076.246056             109   
    7  Northern Cape        3160  11414.289726              99   
    8   Western Cape        6173  21596.026835             349   
    
       Hypertension_Cases  Diabetes_%  Hypertension_%  Total_Expenditure  Male  \
    0                1156        4.14           11.95               43.0  51.7   
    1                 502        3.17           11.98               41.6  51.7   
    2                1325        2.49            8.06               29.8  51.7   
    3                 951        3.15            7.23               41.7  51.7   
    4                 481        1.49            5.82               45.5  51.7   
    5                 464        2.08            7.98               39.3  51.7   
    6                 529        2.54           12.35               45.2  51.7   
    7                 427        3.13           13.51               43.3  51.7   
    8                 826        5.65           13.38               28.7  51.7   
    
       Female  ...  Alcoholic beverages, tobacco and narcotics  Beer  \
    0    54.2  ...                                         1.4   0.4   
    1    54.2  ...                                         2.1   0.9   
    2    54.2  ...                                         1.5   0.6   
    3    54.2  ...                                         1.3   0.5   
    4    54.2  ...                                         1.2   0.6   
    5    54.2  ...                                         1.3   0.5   
    6    54.2  ...                                         1.9   0.9   
    7    54.2  ...                                         2.2   0.8   
    8    54.2  ...                                         1.0   0.3   
    
       Fruit and vegetable juices  Oils and fats  Other non-alcoholic beverages  \
    0                         0.2            1.1                            0.0   
    1                         0.2            0.8                            0.0   
    2                         0.2            0.6                            0.1   
    3                         0.3            1.2                            0.1   
    4                         0.3            1.0                            0.0   
    5                         0.2            0.8                            0.1   
    6                         0.3            1.0                            0.0   
    7                         0.2            0.7                            0.1   
    8                         0.2            0.5                            0.1   
    
       Ready-made food and other food products n.e.c.  Soft drinks  \
    0                                             1.9          0.4   
    1                                             1.9          0.6   
    2                                             0.8          0.5   
    3                                             1.2          0.5   
    4                                             1.0          1.0   
    5                                             1.0          0.6   
    6                                             1.6          0.9   
    7                                             2.5          0.8   
    8                                             1.0          0.4   
    
       Spirits and liquors  Sugar, confectionery and desserts  Wine  
    0                  0.4                                1.3   0.3  
    1                  0.1                                0.9   0.3  
    2                  0.2                                0.6   0.3  
    3                  0.3                                1.0   0.3  
    4                  0.1                                1.0   0.1  
    5                  0.2                                0.8   0.2  
    6                  0.2                                1.2   0.4  
    7                  0.4                                1.2   0.3  
    8                  0.2                                0.8   0.2  
    
    [9 rows x 22 columns]>



# 8. Feature engineering #

## 8.1. Import needed libraries ##


```python
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, r2_score
import warnings
warnings.filterwarnings('ignore')
```

## 8.2. Detect outliers ##


```python
# All numeric columns
numeric_cols = [
    'Population', 'Avg_Income', 'Diabetic_Cases', 'Hypertension_Cases', 
    'Diabetes_%', 'Hypertension_%', 'Total_Expenditure', 'Male', 'Female', 
    'Overweight_Percentage', 'Diabetes_Prevalence', 
    'Alcoholic beverages, tobacco and narcotics', 'Beer', 'Fruit and vegetable juices', 
    'Oils and fats', 'Other non-alcoholic beverages', 'Ready-made food and other food products n.e.c.', 
    'Soft drinks', 'Spirits and liquors', 'Sugar, confectionery and desserts', 'Wine'
]

# Set plot style
sns.set(style="whitegrid", palette="muted", font_scale=1.1)

# Create a figure with subplots
fig, axes = plt.subplots(len(numeric_cols)//3 + 1, 3, figsize=(7, 2*(len(numeric_cols)//3 + 1)))
axes = axes.flatten()

for i, col in enumerate(numeric_cols):
    sns.boxplot(y=df_merged[col], ax=axes[i])
    axes[i].set_title(col, fontsize=12)
    axes[i].set_ylabel('')
    axes[i].set_xlabel('')

# Remove empty subplots
for j in range(i+1, len(axes)):
    fig.delaxes(axes[j])

plt.tight_layout()
plt.show()

```


    
![png](output_174_0.png)
    


## 8.3. Encode categorical variables ##


```python
import pandas as pd

# Suppose df_model has province-level features (Overweight_Percentage, Diabetes_Prevalence, etc.)
# province_age_summary has age-level rows per province

# Merge on province
df_full = province_age_summary.merge(
    df_model, 
    left_on='prov_x',   # province column in age data
    right_on='Province',  # province column in main data
    how='left'
)

# Optional: drop duplicate province column
df_full.drop(columns=['Province'], inplace=True)

df_full.head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>prov_x</th>
      <th>age_grp1</th>
      <th>Population_x</th>
      <th>Diabetic_Cases_x</th>
      <th>Hypertension_Cases_x</th>
      <th>Population_y</th>
      <th>Avg_Income</th>
      <th>Diabetic_Cases_y</th>
      <th>Hypertension_Cases_y</th>
      <th>Diabetes_%</th>
      <th>Hypertension_%</th>
      <th>Total_Expenditure</th>
      <th>Male</th>
      <th>Female</th>
      <th>Overweight_Percentage</th>
      <th>Diabetes_Prevalence</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Eastern Cape</td>
      <td>00-04</td>
      <td>930</td>
      <td>0</td>
      <td>0</td>
      <td>9677</td>
      <td>9224.617687</td>
      <td>401</td>
      <td>1156</td>
      <td>4.14</td>
      <td>11.95</td>
      <td>43.0</td>
      <td>51.7</td>
      <td>54.2</td>
      <td>23.0</td>
      <td>13.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Eastern Cape</td>
      <td>05-09</td>
      <td>950</td>
      <td>1</td>
      <td>0</td>
      <td>9677</td>
      <td>9224.617687</td>
      <td>401</td>
      <td>1156</td>
      <td>4.14</td>
      <td>11.95</td>
      <td>43.0</td>
      <td>51.7</td>
      <td>54.2</td>
      <td>23.0</td>
      <td>13.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Eastern Cape</td>
      <td>10-14</td>
      <td>1128</td>
      <td>0</td>
      <td>0</td>
      <td>9677</td>
      <td>9224.617687</td>
      <td>401</td>
      <td>1156</td>
      <td>4.14</td>
      <td>11.95</td>
      <td>43.0</td>
      <td>51.7</td>
      <td>54.2</td>
      <td>23.0</td>
      <td>13.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Eastern Cape</td>
      <td>15-19</td>
      <td>995</td>
      <td>0</td>
      <td>2</td>
      <td>9677</td>
      <td>9224.617687</td>
      <td>401</td>
      <td>1156</td>
      <td>4.14</td>
      <td>11.95</td>
      <td>43.0</td>
      <td>51.7</td>
      <td>54.2</td>
      <td>23.0</td>
      <td>13.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Eastern Cape</td>
      <td>20-24</td>
      <td>617</td>
      <td>0</td>
      <td>4</td>
      <td>9677</td>
      <td>9224.617687</td>
      <td>401</td>
      <td>1156</td>
      <td>4.14</td>
      <td>11.95</td>
      <td>43.0</td>
      <td>51.7</td>
      <td>54.2</td>
      <td>23.0</td>
      <td>13.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
from sklearn.preprocessing import LabelEncoder

le = LabelEncoder()
df_full['prov_x_encoded'] = le.fit_transform(df_full['prov_x'])

```


```python
df_full.fillna(df_full.mode(), inplace=True)
```


```python
import pandas as pd
from sklearn.preprocessing import MinMaxScaler, LabelEncoder
from sklearn.impute import SimpleImputer

# Select numeric columns for scaling
numeric_cols = ['Population_x', 'Diabetic_Cases_x', 'Hypertension_Cases_x',
                'Population_y', 'Avg_Income', 'Diabetic_Cases_y',
                'Hypertension_Cases_y', 'Diabetes_%', 'Hypertension_%',
                'Total_Expenditure', 'Male', 'Female',
                'Overweight_Percentage', 'Diabetes_Prevalence', 'prov_x_encoded']

X_numeric = df_full[numeric_cols]

# Impute missing numeric values
imputer = SimpleImputer(strategy='mean')
X_numeric_imputed = pd.DataFrame(imputer.fit_transform(X_numeric), columns=numeric_cols)

# Scale numeric columns Normalization
scaler = MinMaxScaler()
X_numeric_scaled = pd.DataFrame(scaler.fit_transform(X_numeric_imputed), columns=numeric_cols)

# Encode 'age_grp1'
le = LabelEncoder()
df_full['age_grp1_encoded'] = le.fit_transform(df_full['age_grp1'])

# Add encoded age group to scaled numeric DataFrame
X_final = pd.concat([X_numeric_scaled, df_full['age_grp1_encoded']], axis=1)

X_final.head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Population_x</th>
      <th>Diabetic_Cases_x</th>
      <th>Hypertension_Cases_x</th>
      <th>Population_y</th>
      <th>Avg_Income</th>
      <th>Diabetic_Cases_y</th>
      <th>Hypertension_Cases_y</th>
      <th>Diabetes_%</th>
      <th>Hypertension_%</th>
      <th>Total_Expenditure</th>
      <th>Male</th>
      <th>Female</th>
      <th>Overweight_Percentage</th>
      <th>Diabetes_Prevalence</th>
      <th>prov_x_encoded</th>
      <th>age_grp1_encoded</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.603851</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.490627</td>
      <td>0.011851</td>
      <td>0.95873</td>
      <td>0.811804</td>
      <td>0.637019</td>
      <td>0.797139</td>
      <td>0.85119</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.583333</td>
      <td>0.625</td>
      <td>0.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.617607</td>
      <td>0.012195</td>
      <td>0.000000</td>
      <td>0.490627</td>
      <td>0.011851</td>
      <td>0.95873</td>
      <td>0.811804</td>
      <td>0.637019</td>
      <td>0.797139</td>
      <td>0.85119</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.583333</td>
      <td>0.625</td>
      <td>0.0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.740028</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.490627</td>
      <td>0.011851</td>
      <td>0.95873</td>
      <td>0.811804</td>
      <td>0.637019</td>
      <td>0.797139</td>
      <td>0.85119</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.583333</td>
      <td>0.625</td>
      <td>0.0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.648556</td>
      <td>0.000000</td>
      <td>0.009302</td>
      <td>0.490627</td>
      <td>0.011851</td>
      <td>0.95873</td>
      <td>0.811804</td>
      <td>0.637019</td>
      <td>0.797139</td>
      <td>0.85119</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.583333</td>
      <td>0.625</td>
      <td>0.0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.388583</td>
      <td>0.000000</td>
      <td>0.018605</td>
      <td>0.490627</td>
      <td>0.011851</td>
      <td>0.95873</td>
      <td>0.811804</td>
      <td>0.637019</td>
      <td>0.797139</td>
      <td>0.85119</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.583333</td>
      <td>0.625</td>
      <td>0.0</td>
      <td>4</td>
    </tr>
  </tbody>
</table>
</div>




```python
X_scaled = X_final  # if you followed my last preprocessing step

```

## 8.4. Feature selection ##


```python
X = X_final.drop('Diabetes_Prevalence', axis=1)
y = X_final['Diabetes_Prevalence']
```


```python
print("X shape:", X.shape)
print("y shape:", y.shape)
```

    X shape: (144, 15)
    y shape: (144,)
    


```python
# Fill missing values
X.fillna(X.mean(), inplace=True)
y.fillna(y.mean(), inplace=True)
```


```python
# Drop features derived from the target
X = X_final.drop(columns=['Diabetic_Cases_y', 'Diabetes_%'])

```

## 8.5. Split dataset into training and testing sets ##


```python
from sklearn.model_selection import train_test_split

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

```

## 8.6. Impute and scale after splitting ##


```python
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler

imp = SimpleImputer(strategy='median')
X_train_imp = imp.fit_transform(X_train)
X_test_imp = imp.transform(X_test)

scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train_imp)
X_test_scaled = scaler.transform(X_test_imp)

```

# 9. Model Selection,Training & Evaluation  #


```python
X_final.columns
```




    Index(['Population_x', 'Diabetic_Cases_x', 'Hypertension_Cases_x',
           'Population_y', 'Avg_Income', 'Diabetic_Cases_y',
           'Hypertension_Cases_y', 'Diabetes_%', 'Hypertension_%',
           'Total_Expenditure', 'Male', 'Female', 'Overweight_Percentage',
           'Diabetes_Prevalence', 'prov_x_encoded', 'age_grp1_encoded'],
          dtype='object')



## 9.1. Linear Regression ##


```python
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LinearRegression

# Correct feature names
X = X_final[['Population_x', 'Diabetic_Cases_x', 'Hypertension_Cases_x',
       'Population_y', 'Avg_Income', 'Diabetic_Cases_y',
       'Hypertension_Cases_y',
       'Total_Expenditure', 'Male', 'Female', 'Overweight_Percentage', 'prov_x_encoded', 'age_grp1_encoded']]

y = X_final['Diabetes_Prevalence']

# Handle missing values
imputer = SimpleImputer(strategy='mean')
X_imputed = imputer.fit_transform(X)

# Train Linear Regression
lr = LinearRegression()
lr.fit(X_imputed, y)

# Create DataFrame for feature importance
feature_importance = pd.DataFrame({
    'Feature': X.columns,
    'Coefficient': lr.coef_,
    'Abs_Coefficient': abs(lr.coef_)
})


# Check results
print("Intercept:", lr.intercept_)
print("Coefficients:", lr.coef_)


```

    Intercept: 0.05949824630195655
    Coefficients: [-1.36174184e-15 -3.48633589e-16 -3.25840487e-16 -1.40707086e-01
     -1.01383095e-01  3.90846832e-01 -3.78381988e-01  7.34448017e-02
      5.55111512e-17  5.55111512e-16  8.70237455e-01 -6.83907595e-02
      1.76080980e-17]
    

### 9.2. Linear Regression Evaluation ###


```python
from sklearn.metrics import mean_squared_error, r2_score
lr = LinearRegression()
lr.fit(X_train_scaled, y_train)
y_pred = lr.predict(X_test_scaled)

print("MSE:", mean_squared_error(y_test, y_pred))
print("R2 Score:", r2_score(y_test, y_pred))
```

    MSE: 3.068205635541045e-32
    R2 Score: 1.0
    

### 9.3. Cross-validation for Linear Regression ###


```python
from sklearn.model_selection import cross_val_predict

# Cross-validated predictions
yhat = cross_val_predict(lr, X_scaled, y, cv=4)

# Plot Actual vs Predicted
import matplotlib.pyplot as plt
import seaborn as sns

plt.figure(figsize=(8,6))
sns.scatterplot(x=y, y=yhat)
plt.plot([y.min(), y.max()], [y.min(), y.max()], 'r--')  # perfect prediction line
plt.xlabel('Actual Diabetes Prevalence')
plt.ylabel('Predicted Diabetes Prevalence')
plt.title('Linear Regression: Actual vs Predicted')
plt.tight_layout()
plt.show()

```


    
![png](output_197_0.png)
    


## 9.4. Preprocessing ##


```python
import pandas as pd
import numpy as np

df = X_final.copy()
df = df[~df['Diabetes_Prevalence'].isna()].reset_index(drop=True)


# 0.2: features list (edit to your variables)
features = [
    'Overweight_Percentage','Hypertension_%','Total_Expenditure',
    'Sugar', 'Soft_drinks', 'Oils_and_fats',  # from your pivot table
    'Population','Avg_Income'
]
features = [f for f in features if f in df.columns]  # keep only existing columns
X = df[features]
y = df['Diabetes_Prevalence']


# 0.3: impute numeric missing values (median recommended)
from sklearn.impute import SimpleImputer
imp = SimpleImputer(strategy='median')
X_imp = pd.DataFrame(imp.fit_transform(X), columns=X.columns)


# 0.4: optionally scale (needed for KNN / linear regression interpretation)
from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
X_scaled = pd.DataFrame(scaler.fit_transform(X_imp), columns=X_imp.columns)


groups = df['prov_x_encoded']  # for GroupKFold or clustered SE later

```

## 9.5. Baseline OLS with clustered SEs ##


```python
import statsmodels.api as sm

# Add constant
X_const = sm.add_constant(X_scaled)

# OLS
ols = sm.OLS(y, X_const, missing='drop').fit()
print(ols.summary())

# Clustered SEs by province (if you have repeated measures per province)
ols_cluster = ols.get_robustcov_results(cov_type='cluster', groups=groups)
print(ols_cluster.summary())

```

                                 OLS Regression Results                            
    ===============================================================================
    Dep. Variable:     Diabetes_Prevalence   R-squared:                       0.956
    Model:                             OLS   Adj. R-squared:                  0.955
    Method:                  Least Squares   F-statistic:                     762.1
    Date:                 Fri, 05 Sep 2025   Prob (F-statistic):           1.91e-93
    Time:                         22:29:21   Log-Likelihood:                 219.25
    No. Observations:                  144   AIC:                            -428.5
    Df Residuals:                      139   BIC:                            -413.7
    Df Model:                            4                                         
    Covariance Type:             nonrobust                                         
    =========================================================================================
                                coef    std err          t      P>|t|      [0.025      0.975]
    -----------------------------------------------------------------------------------------
    const                     0.4625      0.004    103.303      0.000       0.454       0.471
    Overweight_Percentage     0.2331      0.006     40.393      0.000       0.222       0.245
    Hypertension_%            0.0118      0.006      2.101      0.037       0.001       0.023
    Total_Expenditure         0.0734      0.010      7.433      0.000       0.054       0.093
    Avg_Income                0.0218      0.010      2.193      0.030       0.002       0.041
    ==============================================================================
    Omnibus:                     1649.153   Durbin-Watson:                   0.175
    Prob(Omnibus):                  0.000   Jarque-Bera (JB):               16.741
    Skew:                          -0.113   Prob(JB):                     0.000232
    Kurtosis:                       1.345   Cond. No.                         4.54
    ==============================================================================
    
    Notes:
    [1] Standard Errors assume that the covariance matrix of the errors is correctly specified.
                                 OLS Regression Results                            
    ===============================================================================
    Dep. Variable:     Diabetes_Prevalence   R-squared:                       0.956
    Model:                             OLS   Adj. R-squared:                  0.955
    Method:                  Least Squares   F-statistic:                     56.72
    Date:                 Fri, 05 Sep 2025   Prob (F-statistic):           6.54e-06
    Time:                         22:29:21   Log-Likelihood:                 219.25
    No. Observations:                  144   AIC:                            -428.5
    Df Residuals:                      139   BIC:                            -413.7
    Df Model:                            4                                         
    Covariance Type:               cluster                                         
    =========================================================================================
                                coef    std err          t      P>|t|      [0.025      0.975]
    -----------------------------------------------------------------------------------------
    const                     0.4625      0.019     24.434      0.000       0.419       0.506
    Overweight_Percentage     0.2331      0.026      8.857      0.000       0.172       0.294
    Hypertension_%            0.0118      0.020      0.582      0.577      -0.035       0.058
    Total_Expenditure         0.0734      0.044      1.660      0.135      -0.029       0.175
    Avg_Income                0.0218      0.038      0.568      0.585      -0.067       0.110
    ==============================================================================
    Omnibus:                     1649.153   Durbin-Watson:                   0.175
    Prob(Omnibus):                  0.000   Jarque-Bera (JB):               16.741
    Skew:                          -0.113   Prob(JB):                     0.000232
    Kurtosis:                       1.345   Cond. No.                         4.54
    ==============================================================================
    
    Notes:
    [1] Standard Errors are robust to cluster correlation (cluster)
    

## 9.6. Machine learning — Random Forest / XGBoost with GroupKFold ##


```python
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import GroupKFold, cross_val_score
from sklearn.metrics import make_scorer, mean_absolute_error

gkf = GroupKFold(n_splits=min(5, df['prov_x_encoded'].nunique()))
rf = RandomForestRegressor(n_estimators=500, max_depth=4, random_state=42)

# MAE scorer (use neg because scikit expects higher is better)
neg_mae = make_scorer(mean_absolute_error, greater_is_better=False)

scores = cross_val_score(rf, X_scaled, y, groups=groups, cv=gkf, scoring=neg_mae, n_jobs=-1)
print("MAE (GroupKFold):", -scores.mean(), "±", scores.std())

```

    MAE (GroupKFold): 0.2328949999999999 ± 0.12298765756164204
    

## 9.7. Hyperparameter tuning (GridSearch with groups) ##


```python
from sklearn.model_selection import GridSearchCV

param_grid = {
    'n_estimators': [100,300],
    'max_depth': [2,4,6],
    'min_samples_leaf': [1,2,4]
}
grid = GridSearchCV(rf, param_grid, cv=gkf, scoring='neg_mean_absolute_error', n_jobs=-1)
grid.fit(X_scaled, y, groups=groups)
print(grid.best_params_, -grid.best_score_)
best_rf = grid.best_estimator_

```

    {'max_depth': 2, 'min_samples_leaf': 4, 'n_estimators': 300} 0.21949362516684143
    

## 9.8. Feature importance + permutation importance ##


```python
importances = pd.Series(best_rf.feature_importances_, index=X_scaled.columns).sort_values(ascending=False)
print(importances)

# permutation importance (safer)
from sklearn.inspection import permutation_importance
perm = permutation_importance(best_rf, X_scaled, y, n_repeats=30, random_state=42, n_jobs=-1)
perm_imp = pd.Series(perm.importances_mean, index=X_scaled.columns).sort_values(ascending=False)
print(perm_imp)

```

    Overweight_Percentage    0.984734
    Total_Expenditure        0.006178
    Avg_Income               0.004973
    Hypertension_%           0.004115
    dtype: float64
    Overweight_Percentage    1.778942
    Total_Expenditure        0.007998
    Avg_Income               0.006735
    Hypertension_%           0.005221
    dtype: float64
    

## 9.9. Feature importance + permutation importance plots  ##


```python
import pandas as pd
import matplotlib.pyplot as plt

# Convert X_scaled to DataFrame with column names
X_scaled_df = pd.DataFrame(X_scaled, columns=X.columns)

# 1️⃣ Random Forest built-in importance
importances = pd.Series(best_rf.feature_importances_, index=X_scaled_df.columns).sort_values(ascending=False)

plt.figure(figsize=(10, 6))
importances.plot(kind='bar', color='skyblue', edgecolor='black')
plt.title('Feature Importance (Random Forest)', fontsize=14)
plt.ylabel('Importance Score', fontsize=12)
plt.xlabel('Features', fontsize=12)
plt.xticks(rotation=45, ha='right')
plt.tight_layout()
plt.show()

# 2️⃣ Permutation importance
from sklearn.inspection import permutation_importance

perm = permutation_importance(best_rf, X_scaled, y, n_repeats=30, random_state=42, n_jobs=-1)
perm_imp = pd.Series(perm.importances_mean, index=X_scaled_df.columns).sort_values(ascending=False)

plt.figure(figsize=(10, 6))
perm_imp.plot(kind='bar', color='orange', edgecolor='black')
plt.title('Permutation Feature Importance', fontsize=14)
plt.ylabel('Importance Score', fontsize=12)
plt.xlabel('Features', fontsize=12)
plt.xticks(rotation=45, ha='right')
plt.tight_layout()
plt.show()

```


    
![png](output_209_0.png)
    



    
![png](output_209_1.png)
    


## 9.10. Evaluating Random Forest / XGBoost with GroupKFold ##



```python
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import numpy as np

best_rf.fit(X_scaled, y)
yhat = best_rf.predict(X_scaled)

mse = mean_squared_error(y, yhat)
rmse = np.sqrt(mse)
mae = mean_absolute_error(y, yhat)
r2 = r2_score(y, yhat)

print("RMSE:", rmse)
print("MAE:", mae)
print("R2:", r2)

```

    RMSE: 0.06421314526095667
    MAE: 0.048999917349746736
    R2: 0.9354609526630565
    

# 10. RESULTS  #

<div style = "fon-size:18px">
The predictive modeling using Random Forest to explore the relationship between food consumption patterns and diabetes prevalence in South Africa produced strong performance metrics:

Root Mean Squared Error (RMSE): 0.064</br>

Mean Absolute Error (MAE): 0.049</br>

R-squared (R²): 0.935</br>

These results indicate that the model explains approximately 93.5% of the variance in diabetes prevalence across provinces, demonstrating high predictive accuracy.

Feature importance analysis revealed the most influential variables contributing to diabetes prevalence, with the top predictors identified by both Random Forest’s built-in importance and permutation importance methods. This suggests that certain dietary factors are significantly associated with the observed differences in provincial diabetes prevalence. The feature importance plots provide a visual ranking of these factors, guiding further investigation into specific food consumption patterns.
</div>

# 11. CONCLUSION #

<div style="font-size:18px; text-align:justify;">
This study highlights the strong relationship between provincial food consumption patterns and diabetes prevalence in South Africa. The Random Forest model performed exceptionally well, capturing the majority of the variance in diabetes prevalence, and feature importance analysis identified key dietary drivers.

The findings suggest that targeted nutritional interventions focusing on the most influential dietary factors could help reduce diabetes prevalence at the provincial level. Moreover, the methodology demonstrates the utility of machine learning models, such as Random Forest, combined with feature importance analyses, in public health research for identifying critical lifestyle-related risk factors.

Future research could extend this approach by integrating additional sociodemographic variables or exploring temporal trends in food consumption to improve predictive power and guide policy interventions.
</div>


```python

```
